# -*- coding: utf-8 -*-
import random
import re
import time
import traceback
import execjs, requests
from loguru import logger
import friut_drission


# from config.config import Settings

def get_fy_token(pre_url):
    url = 'http://121.62.23.121:1001'
    # url = 'http://154.201.80.146:1001/'
    trace = requests.get(url).json()
    print(trace)
    # trace = [[91.0, 59.0, 1249668.822639326], [108.0, 59.0, 1437524.9083104525], [125.0, 59.0, 1619864.7319522067], [142.0, 59.0, 1799324.0281247161], [159.0, 58.0, 1975294.9598896557], [176.0, 58.0, 2147075.700304024], [192.0, 58.0, 2313995.839696577], [208.0, 58.0, 2476466.2461657543], [224.0, 58.0, 2634681.3577156607], [240.0, 58.0, 2788523.3595772027], [255.0, 58.0, 2937891.716480753], [270.0, 58.0, 3082714.168701268], [284.0, 58.0, 3223048.140029905], [298.0, 58.0, 3358913.877152909], [312.0, 58.0, 3490296.369595996], [325.0, 58.0, 3617200.504490327], [338.0, 58.0, 3739648.6230069315], [350.0, 58.0, 3857701.4652045416], [361.0, 58.0, 3971426.4036770393], [372.0, 58.0, 4080906.170573388], [383.0, 58.0, 4186246.886455972], [392.0, 58.0, 4287581.202027772], [401.0, 58.0, 4385070.392617145], [409.0, 58.0, 4478901.565531453], [416.0, 58.0, 4569287.660057059], [423.0, 58.0, 4656472.6836712845], [428.0, 58.0, 4740731.712042416], [433.0, 58.0, 4822371.587191292], [436.0, 57.0, 4901731.615652904], [439.0, 57.0, 4979186.361122769], [440.0, 57.0, 5055146.342618532], [440.0, 57.0, 5130061.176207133], [439.0, 57.0, 5204423.065812787], [436.0, 57.0, 5278773.086671333], [432.0, 57.0, 5353708.166946177], [427.0, 57.0, 5429888.069344249], [421.0, 56.0, 5508036.4383583795], [412.0, 56.0, 5588937.30945934], [403.0, 56.0, 5673409.975278428], [392.0, 56.0, 5762263.605103821], [381.0, 56.0, 5856249.071730542], [368.0, 56.0, 5956069.772965183], [354.0, 56.0, 6062433.2955839], [339.0, 55.0, 6176036.753938932], [324.0, 55.0, 6298357.457964516], [310.0, 55.0, 6431325.12630821], [296.0, 55.0, 6574777.087318466], [283.0, 55.0, 6725390.091804843], [270.0, 55.0, 6884096.883657768], [258.0, 55.0, 7050123.899830391], [246.0, 54.0, 7225341.515234725], [236.0, 54.0, 7407954.756410975], [226.0, 54.0, 7593266.392150472], [219.0, 54.0, 7780483.310881714], [218.0, 54.0, 7963770.976158379], [224.0, 53.0, 8139585.519726121], [230.0, 53.0, 8307434.039499134], [237.0, 53.0, 8468209.484156948], [245.0, 53.0, 8621349.833615886], [252.0, 53.0, 8775861.372446679], [260.0, 52.0, 8934212.101886341], [267.0, 52.0, 9086228.411177926], [276.0, 52.0, 9231862.825332996], [284.0, 52.0, 9370838.872360077], [294.0, 51.0, 9506761.85873384], [303.0, 51.0, 9640415.121763462], [313.0, 51.0, 9767615.277173916], [324.0, 50.0, 9888642.287764652], [335.0, 50.0, 10003963.921804069], [346.0, 50.0, 10115132.192517031], [358.0, 49.0, 10222524.107164638], [370.0, 49.0, 10324957.678167181], [382.0, 48.0, 10423004.00170907], [395.0, 48.0, 10517316.557042874], [408.0, 47.0, 10608226.970926048], [421.0, 47.0, 10695708.713217992], [434.0, 46.0, 10779596.31962078], [448.0, 46.0, 10859960.30445547], [462.0, 45.0, 10936814.630953955], [475.0, 45.0, 11018856.996262135], [489.0, 44.0, 11108638.48284679], [503.0, 44.0, 11198988.272969475], [517.0, 43.0, 11291959.659879996], [530.0, 43.0, 11399809.568533681], [543.0, 42.0, 11526619.451612737], [556.0, 42.0, 11665993.450748758], [568.0, 41.0, 11810600.171036532], [580.0, 41.0, 11961273.217420047], [592.0, 40.0, 12118187.828459557], [603.0, 40.0, 12280224.152957274], [613.0, 40.0, 12447140.627001455], [624.0, 39.0, 12619553.029118564], [636.0, 39.0, 12798058.985633606], [647.0, 39.0, 12981552.608580686], [659.0, 38.0, 13168863.779127203], [670.0, 38.0, 13359499.59518735], [682.0, 37.0, 13553224.07814214], [693.0, 37.0, 13749914.35155092], [705.0, 37.0, 13949205.97506129], [716.0, 36.0, 14150770.812723778], [728.0, 36.0, 14354452.476341184], [740.0, 36.0, 14560097.37036269], [751.0, 35.0, 14767582.618347641], [763.0, 35.0, 14976785.343855381], [774.0, 35.0, 15187591.048384393], [786.0, 34.0, 15399931.312098403], [798.0, 34.0, 15613737.715161135], [809.0, 33.0, 15828957.197291398], [821.0, 33.0, 16045543.67982395], [833.0, 33.0, 16263455.273063106], [845.0, 32.0, 16482664.050545087], [857.0, 32.0, 16703143.482129296], [869.0, 32.0, 16924876.81193746], [881.0, 31.0, 17147845.887768116], [893.0, 31.0, 17372036.746389378], [905.0, 30.0, 17597438.217215728], [917.0, 30.0, 17824048.903923977], [930.0, 30.0, 18051857.635928612], [942.0, 29.0, 18280863.016906444], [954.0, 29.0, 18511063.650534283], [967.0, 29.0, 18742456.74416575], [979.0, 28.0, 18975046.48677041], [992.0, 28.0, 19208830.08570189], [1004.0, 27.0, 19443811.729929756], [1017.0, 27.0, 19679994.212100387], [1030.0, 27.0, 19917378.92853697], [1043.0, 26.0, 20155971.464532264], [1055.0, 26.0, 20395776.009055834], [1068.0, 25.0, 20636793.95843087], [1081.0, 25.0, 20879032.294273324], [1095.0, 25.0, 21122496.601875946], [1108.0, 24.0, 21367191.070208307], [1121.0, 24.0, 21613119.888239972], [1134.0, 23.0, 21860290.03758689], [1147.0, 23.0, 22108707.10354182], [1161.0, 23.0, 22358376.671397515], [1174.0, 22.0, 22609304.326446734], [1188.0, 22.0, 22861497.050305422], [1201.0, 21.0, 23114960.42826634], [1215.0, 21.0, 23369698.649299048], [1229.0, 20.0, 23625720.091342688], [1243.0, 20.0, 23883028.943366826], [1257.0, 20.0, 24141633.5833106], [1271.0, 19.0, 24401542.38911314], [1285.0, 19.0, 24662758.15342083], [1299.0, 18.0, 24925286.461526424], [1313.0, 18.0, 25189135.691369057], [1327.0, 17.0, 25454314.220887866], [1341.0, 17.0, 25720824.84272923], [1356.0, 17.0, 25988678.72747866], [1370.0, 16.0, 26257878.66778254], [1385.0, 16.0, 26528433.041580003], [1399.0, 15.0, 26800350.226810183], [1414.0, 15.0, 27073635.80876584], [1429.0, 14.0, 27348295.372739725], [1443.0, 14.0, 27624334.504024602], [1458.0, 13.0, 27901767.16585236], [1473.0, 13.0, 28180593.358223002], [1488.0, 12.0, 28460818.66642928], [1504.0, 12.0, 28742457.053703092], [1519.0, 11.0, 29025511.312690813], [1534.0, 11.0, 29309989.82133158], [1549.0, 11.0, 29595898.164918147], [1565.0, 10.0, 29883244.721389655], [1580.0, 10.0, 30172037.868685234], [1596.0, 9.0, 30462285.984744024], [1611.0, 9.0, 30753989.069566023], [1627.0, 8.0, 31047161.086383123], [1643.0, 8.0, 31341810.413134463], [1659.0, 7.0, 31637939.842466418], [1675.0, 7.0, 31935560.5449645], [1691.0, 6.0, 32234678.105921473], [1707.0, 6.0, 32535298.110630088], [1723.0, 5.0, 32837431.729675863], [1740.0, 5.0, 33141081.755705174], [1756.0, 4.0, 33446262.151949912], [1772.0, 4.0, 33752978.50370284], [1789.0, 3.0, 34061233.60361033], [1806.0, 3.0, 34371041.41490428], [1822.0, 2.0, 34682407.52287744], [1839.0, 2.0, 34995343.09811533], [1856.0, 1.0, 35309850.93326433], [1873.0, 1.0, 35625942.19890995], [1890.0, 0.0, 35943622.48034495]]

    # print(trace)
    with open('./JS/227.js', 'r', encoding='utf-8') as f:
        jstext = f.read()
        ctx = execjs.compile(jstext)
        token = ctx.call('get_227_wg', pre_url, trace)

    return token, trace


def check_do(cookies):
    headers = {
        "authority": "zhaoshang.alitrip.com",
        "accept": "*/*",
        "accept-language": "zh-CN,zh;q=0.9",
        "bx-v": "2.5.8",
        "referer": "https://zhaoshang.alitrip.com/join/joinNewPage.htm",
        "sec-ch-ua": "^\\^Not_A",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "^\\^Windows^^",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    url = "https://zhaoshang.alitrip.com/entryprocess/ajax/sendCaptchaCode.do"
    params = {
        "mobile": "1736130" + str(random.randint(1900, 1999))
    }
    response = requests.get(url, headers=headers, cookies=cookies, params=params, timeout=3)

    print(response.text)


def login():
    headers = {
        "authority": "login.taobao.com",
        "accept": "application/json, text/plain, */*",
        "accept-language": "zh-CN,zh;q=0.9",
        "bx-v": "2.5.3",
        "content-type": "application/x-www-form-urlencoded",
        "origin": "https://login.taobao.com",
        "referer": "https://login.taobao.com/",
        "sec-ch-ua": "^\\^Not_A",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "^\\^Windows^^",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }

    url = "https://login.taobao.com/newlogin/login.do"
    params = {
        "appName": "taobao",
        "fromSite": "0",
        "_bx-v": "2.5.3"
    }
    data = {
        "loginId": str(int(time.time() * 2000)),
        "password2": "6a99f89c642036d1822dce2a949e4adea04a155f30cd6910af2797213d5be69efcddb9dc834dfaf2b43657f3072a4352396cf0d5ce167b15108933d6ff5580a996222e35db66c726680129fdca8bce3968247bc586a1dfde8542b38bc28d48ed5e5670217a0fef129e869f774d8be31bef57ad31801ae910e91dce2fede2bbd6",
        "keepLogin": "false",
        "ua": "",
        "umidGetStatusVal": "255",
        "screenPixel": "1920x1080",
        "navlanguage": "zh-CN",
        "navUserAgent": "Mozilla^%^2F5.0^%^20^%^28Windows^%^20NT^%^2010.0^%^3B^%^20Win64^%^3B^%^20x64^%^29^%^20AppleWebKit^%^2F537.36^%^20^%^28KHTML^%^2C^%^20like^%^20Gecko^%^29^%^20Chrome^%^2F120.0.0.0^%^20Safari^%^2F537.36",
        "navPlatform": "Win32",
        "appName": "taobao",
        "appEntrance": "taobao_pc",
        "_csrf_token": "VkjJ4e5KHxt4hgk2rZkccC",
        "umidToken": "beed80b0675f887bad341345bf7068466db08eb1",
        "hsiz": "1752af328739b1f6f960d4b1b5e40dcs",
        "bizParams": "",
        "style": "default",
        "appkey": "00000000",
        "from": "tb",
        "isMobile": "false",
        "lang": "zh_CN",
        "returnUrl": "",
        "fromSite": "0",
        "umidTag": "SERVER",
        "weiBoMpBridge": "",
        "deviceId": "",
        "pageTraceId": "213d3ed417027274733147532ac6ba",
        'bx-ua': '',
        "bx-umidtoken": "G8198384D4ADDEB9D2D5C503B907B83FA1F8909440C99A01F12"
    }
    response = requests.post(url, headers=headers, params=params, data=data, timeout=5)
    # print(response.json()['data']['url'])
    return response.json()['data']['url']


def get_config(url):
    headers = {
        "authority": "login.taobao.com",
        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "accept-language": "zh-CN,zh;q=0.9",
        "referer": "https://login.taobao.com/",
        "sec-ch-ua": "^\\^Not_A",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "^\\^Windows^^",
        "sec-fetch-dest": "iframe",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "same-origin",
        "sec-fetch-user": "?1",
        "upgrade-insecure-requests": "1",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    url = url
    response = requests.get(url, headers=headers, timeout=3)
    NCTOKENSTR = re.findall('"NCTOKENSTR": "(.*?)",', response.text)[0]
    SECDATA = re.findall('"SECDATA": "(.*?)",', response.text)[0]
    NCAPPKEY = re.findall('"NCAPPKEY": "(.*?)",', response.text)[0]
    # print(NCTOKENSTR)
    return NCTOKENSTR, SECDATA, NCAPPKEY


def get_umidToken():
    headers = {
        "authority": "ynuf.aliapp.org",
        "accept": "*/*",
        "accept-language": "zh-CN,zh;q=0.9",
        "referer": "https://login.taobao.com/",
        "sec-ch-ua": "^\\^Not_A",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "^\\^Windows^^",
        "sec-fetch-dest": "script",
        "sec-fetch-mode": "no-cors",
        "sec-fetch-site": "cross-site",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    url = "https://ynuf.aliapp.org/w/wu.json"
    response = requests.get(url, headers=headers, timeout=5)
    # print(response.text)
    # print(re.findall('mx.wu\(\'(.*?)\'\);}c',response.text)[0])

    return re.findall('mx.wu\(\'(.*?)\'\);}c', response.text)[0]


def writer(strr):
    FilePath = "data.txt"
    with open(FilePath, "a") as filewrite:  # ”a"代表着每次运行都追加txt的内容
        filewrite.write(strr)


def skip(yz_url):
    proxy = ''
    try:
        # yz_url这里要换一下，直接吧验证链接给这个参数，然后后面加上true，这么改是错的，还是会返回哪一个错误，这里的这个链接要每次都换一下，这个第一次没问题，但是后面在调用就会错了，为啥
        yz_url = f'{yz_url}true'
        print(yz_url)
        if ('kcapslidev2' in yz_url):

            return 3
        NCTOKENSTR, SECDATA, NCAPPKEY = get_config(yz_url)
        pre_url = 'https://login.taobao.com//newlogin/login.do/_____tmd_____/punish?x5secdata=' + SECDATA[0:53]
        token, trace = get_fy_token(pre_url)
        print(token)
        SECDATA_2 = SECDATA
        token_2 = token
        umidToken = get_umidToken()
        ts = str(int(time.time() * 1000))
        aa = f'/newlogin/login.do/_____tmd_____/slide?slidedata=%7B%22a%22%3A%22{NCAPPKEY}%22%2C%22t%22%3A%22{NCTOKENSTR}%22%2C%22n%22%3A%22{token_2}%22%2C%22p%22%3A%22%7B%5C%22ncbtn%5C%22%3A%5C%220%7C0%7C42%7C34%7C0%7C34%7C0%7C42%5C%22%2C%5C%22umidToken%5C%22%3A%5C%22{umidToken}%5C%22%2C%5C%22ncSessionID%5C%22%3A%5C%22b15890839%5C%22%2C%5C%22et%5C%22%3A%5C%221%5C%22%7D%22%2C%22scene%22%3A%22register%22%2C%22asyn%22%3A0%2C%22lang%22%3A%22cn%22%2C%22v%22%3A1%7D&x5secdata={SECDATA_2}&landscape=1&ts={ts}&v=07506175215339281'
        with open('./JS/get_et.js', 'r', encoding='utf-8') as f:
            jstext = f.read()
            ctx = execjs.compile(jstext)
            bx_et = ctx.call('get_bx_et', aa)
        headers = {
            "authority": "login.taobao.com",
            "accept": "*/*",
            "accept-language": "zh-CN,zh;q=0.9",
            "bx_et": bx_et,
            "referer": f"https://login.taobao.com//newlogin/account/check.do/_____tmd_____/punish?x5secdata={SECDATA}&x5step=2&action=captcha&pureCaptcha=true&ncLanguage=zh_CN",
            "sec-ch-ua": "Not_A",
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "Windows",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
        if proxy is not None:
            url = 'https://login.taobao.com/newlogin/login.do/_____tmd_____/slide?' + aa[39:]
            response = requests.get(url, headers=headers, timeout=5)
            code = re.findall('"code":(.*?),"dt":"success"', response.text)[0]
            if code == '0':
                resptext = str(trace) + "\n"
                writer(resptext)
            logger.info(response.text)
        else:  # 多尝试几次
            url = 'https://login.taobao.com/newlogin/login.do/_____tmd_____/slide?' + aa[39:]

            response = requests.get(url, headers=headers, timeout=5)
            code = re.findall('"code":(.*?),"dt":"success"', response.text)[0]
            if code == '0':
                resptext = str(trace) + "\n"
                writer(resptext)

            logger.info(response.text)
        if response.cookies.get('x5sec') != None:
            print(response.cookies)
            cookie_jar = response.cookies
            x5sec_value = cookie_jar.get("x5sec")
            return True, x5sec_value
        else:
            return 2, None

    except Exception as e:
        # 打印堆栈
        traceback.print_exc()
        logger.info(e)
        return 0, None


def get_x5sec(url):
    code, x5sec = skip(url)
    if x5sec is not None:
        return x5sec
    else:
        return None
