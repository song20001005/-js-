import json
import re, base64
import time, execjs
import concurrent.futures
import requests, random
from DrissionPage import ChromiumPage
from DrissionPage import WebPage, ChromiumOptions
from DrissionPage.common import Actions
from yzm import yz
import pyautogui



def download_yzm(name, b64_data):
    # if (len(b64_data) % 3 == 1):
    #     b64_data += "=="
    # elif (len(b64_data) % 3 == 2):
    #     b64_data += "="
    #b64_data = b64_data.replace(' ', '+')
    binary_data = base64.urlsafe_b64decode(b64_data)
    with open(name + '.png', 'wb') as fp:
        fp.write(binary_data)



def gradual_move_to(x, y, initial_duration=0.01, final_duration=0.1, steps=10):
    # 计算每一步的目标位置
    start_x, start_y = pyautogui.position()
    step_x = (x - start_x) / steps
    step_y = (y - start_y) / steps

    # 计算每步的时间增量
    duration_increment = (final_duration - initial_duration) / steps

    for i in range(steps):
        # 计算这一步的目标位置
        end_x = start_x + step_x * (i + 1)
        end_y = start_y + step_y * (i + 1)

        # 计算这一步的持续时间
        step_duration = initial_duration + duration_increment * i

        # 移动鼠标
        pyautogui.moveTo(end_x, end_y, duration=step_duration)

        # 稍微暂停，确保动作被完全执行
        time.sleep(step_duration)





def gradual_move(distance, direction='right', initial_duration=0.03, final_duration=0.1, steps=10):
    # 根据方向计算x和y方向上的移动距离
    if direction == 'right':
        dx = distance / steps
        dy = 0
    elif direction == 'left':
        dx = -distance / steps
        dy = 2
    elif direction == 'up':
        dx = 0
        dy = -distance / steps
    elif direction == 'down':
        dx = 0
        dy = distance / steps
    else:
        raise ValueError("Direction should be 'right', 'left', 'up', or 'down'.")

    # 计算每步的时间增量
    duration_increment = (final_duration - initial_duration) / steps

    for i in range(steps):
        # 计算这一步的持续时间
        step_duration = initial_duration + duration_increment * i

        # 移动鼠标
        dy1 = random.uniform(-5,5)
        pyautogui.move(dx, dy1, duration=step_duration)

        # 稍微暂停，确保动作被完全执行
        time.sleep(step_duration)




def yanzheng_sldia(page):
    try:
        page.listen.start('newslidecaptcha')#‘newslidevalidate’
        page.refresh()
        res = page.listen.wait()
        response_body = res.response.body
        #print(response_body)
        imagedata = response_body['data']['imageData'][23:]
        ques = response_body['data']['ques'][22:]
        download_yzm("ques", ques)
        download_yzm("bg", imagedata)

        try:
            distances = int(yz()['data']['recognition'])
            print('打码成功')
        except:
            distances = random.randint(100, 255)
        print(distances)
        # page.listen.stop()
        offf = random.randint(1, 9)
        # 使用自定义函数移动鼠标到(500, 500)的位置，速度先快后慢
        gradual_move_to(822, 722)
        page.listen.start('newslidevalidate')
        pyautogui.mouseDown()
        gradual_move(distances + offf - 24, 'right')
        gradual_move(offf, 'left')
        time.sleep(3)
        pyautogui.mouseUp()
        print('已经移动完了')
        res1 = page.listen.wait()
        response_body1 = res1.response.headers
        print(response_body1)
        bx_x5sec = response_body1['bx-x5sec']
        write_x5sec(bx_x5sec)
        time.sleep(10)
        page_text = "".join(str(page.html).split())
        if '验证码拦截' in page_text:
            print('重试')
            yanzheng_sldia(page)
            page.refresh()
        else:
            print('验证成功')

    except:
        yanzheng_sldia(page)



def write_x5sec(url):
    print('x5sec:' + url)
    filepath = './x5sec.txt'
    with open(filepath, 'w') as f:
        f.write(str(url))




def pass_verfiy(url):
    co = ChromiumOptions()
    co.set_argument('--start-maximized')
    co.headless(False)
    #co.set_proxy('http://{:}'.format(agentip.agentip()['http']))
    co.incognito()
    page = WebPage(chromium_options=co)
    # co.set_proxy('http://{:}'.format(agentip.agentip()['http']))
    ac = Actions(page)

    page.get(url)
    #input('5656565656')
    #page.set.cookies(cookies1)
    page_text = "".join(str(page.html).split())
    # print(page_text)
    # input('nnnn')
    if '验证码拦截' in page_text:
        yanzheng_sldia(page)
    print('程序现在执行到这里')
    # print(res_x5sec_respose)
    # x5sec_text = re.findall('x5sec=(.*?); Max-Age=',str(res_x5sec_respose))
    # for x5sec in x5sec_text:
    #     print(x5sec)
    #input('85865656565')
    time.sleep(3)
    # cookies_list = page.get_cookies(as_dict=False)
    # new_cookie_dict = {cookie['name']: cookie['value'] for cookie in cookies_list}
    #print(new_cookie_dict)
    #input('nnnn')

    page.quit()


def get_x5sec_r():
    #print('被调用啦')
    file_path = './x5sec.txt'  # 将 'your_file.txt' 替换为你的文件路径
    with open(file_path, 'r', encoding='utf-8') as file:
        content= file.read()
        content_line = content.strip()# strip()用于移除行尾的换行符和空格
    #print(content_line)
    new_x5sec_ = re.findall('x5sec=(.*?);Max-Age', "".join(str(content_line).split()))[0]
    return new_x5sec_


def diaoyong(yz_url):
    # if ('kcapslidev2' not in yz_url):
    #     print('滑块')
    # else:
    print(yz_url)
    pass_verfiy(yz_url)
    new_x5sec_ = get_x5sec_r()
    return new_x5sec_






# #
# def login():
#     headers = {
#         "authority": "login.taobao.com",
#         "accept": "application/json, text/plain, */*",
#         "accept-language": "zh-CN,zh;q=0.9",
#         "bx-v": "2.5.3",
#         "content-type": "application/x-www-form-urlencoded",
#         "origin": "https://login.taobao.com",
#         "referer": "https://login.taobao.com/",
#         "sec-ch-ua": "^\\^Not_A",
#         "sec-ch-ua-mobile": "?0",
#         "sec-ch-ua-platform": "^\\^Windows^^",
#         "sec-fetch-dest": "empty",
#         "sec-fetch-mode": "cors",
#         "sec-fetch-site": "same-origin",
#         "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
#     }
#     url = "https://login.taobao.com/newlogin/login.do"
#     params = {
#         "appName": "taobao",
#         "fromSite": "0",
#         "_bx-v": "2.5.3"
#     }
#     data = {
#         "loginId": "csdcsdscdscs",
#         "password2": "6a99f89c642036d1822dce2a949e4adea04a155f30cd6910af2797213d5be69efcddb9dc834dfaf2b43657f3072a4352396cf0d5ce167b15108933d6ff5580a996222e35db66c726680129fdca8bce3968247bc586a1dfde8542b38bc28d48ed5e5670217a0fef129e869f774d8be31bef57ad31801ae910e91dce2fede2bbd6",
#         "keepLogin": "false",
#         "ua": "",
#         "umidGetStatusVal": "255",
#         "screenPixel": "1920x1080",
#         "navlanguage": "zh-CN",
#         "navUserAgent": "Mozilla^%^2F5.0^%^20^%^28Windows^%^20NT^%^2010.0^%^3B^%^20Win64^%^3B^%^20x64^%^29^%^20AppleWebKit^%^2F537.36^%^20^%^28KHTML^%^2C^%^20like^%^20Gecko^%^29^%^20Chrome^%^2F120.0.0.0^%^20Safari^%^2F537.36",
#         "navPlatform": "Win32",
#         "appName": "taobao",
#         "appEntrance": "taobao_pc",
#         "_csrf_token": "VkjJ4e5KHxt4hgk2rZkDwC",
#         "umidToken": "beed80b0675f887bad341345bf7068466db08eb1",
#         "hsiz": "1752af328739b1f6f960d4b1b5e40d26",
#         "bizParams": "",
#         "style": "default",
#         "appkey": "00000000",
#         "from": "tb",
#         "isMobile": "false",
#         "lang": "zh_CN",
#         "returnUrl": "",
#         "fromSite": "0",
#         "umidTag": "SERVER",
#         "weiBoMpBridge": "",
#         "deviceId": "",
#         "pageTraceId": "213d3ed417027274733147532d06ba",
#         "bx-ua": "227^!SSiSphLOqIwxvpiGvSf36ludZ P4JL9j4lPPOXwFJyaWntR3SCcTpsrUVgiE9O3aPEMwCSPE8mJMtS3Oe8xcJPWY6 o1wHRenHEueEHU8n zntkk VnL3SIb  TfrYvCnX7eOsvHaUSFFoo2DwGbWlbNqYuHmpUinHEVOmv3ehuoXr y9En13DmWqmgHmppinHPkqfvHaRbgh70Ke8lnODlzqKiHDppinXPPOfnhHdFu4tR8mxnD3Xlz6mVXXpcGssj4OfOaa7mWnoE8xsnI3DXWFmfXDpMmnHPB5kvHaRKWnoR8mxnIfXlzFmwHiZMqjHPPOJnXOEHWnoR8mpSw3DBx5EfCy0viu3Bv7YZLXWaSCKkCosOLcnOx5V Gy0xQWA9xgf3AN4lQ5Q9igsODf 7DZ2GaMQHHT4wa8J3rN8UhJh8yPNGep7jT66SIhvY/9IpFniydEw5wmka52qZMGesN BGCINCvTFyTlfKvhGWd2sD0acGnhgf/a4ADE7AYVTY3FmGwMS2j2qNZbDJUVrN69mixpnH0Vkhx a5b2fZhYIQa51HvMtziHI0 lUxC/e 84aQKV4oIQ/mJWTKDMRgMD0afuFLwQzinX9JOTKg0D9Erl56k5FSThAqAiOKGZhngxVIOoEMv fDeUkNS zmtgw5HtTzRV FUnCoiTCMi0KPnKY7Sa/V8CZ8IoStioLklc63rTYnLtj2P1 kGFjuyQgIl910fHTnMPMn3Yma5K/wd4X/EPz61xyfYig61KMXOFhYqK6JvWmwDaReNIvkwgd3tUGapYu35ca/pC/s3dJzkExOmvOBQn78NFPMpaaig7C0BmnS1Maxl8E7nFOSI42DsexNkELoVGOCGOyG/kuDcng36XQhBHfG9ZJvfz1jL0ulPUyZniK 06mg62VWUGN8j92vOLHZggsJ9FDwJHWlvv wnMKcDqqUatM8dO8pbnktGw7I4YvzE8iIQOfJYGZTwkhlXjWenV96rXktCZ1EhQW1JNiggsWGfhTy52mvIiyg 6Z6JPD69BWWZjoiT93OVu3GfdlT8HuA7g6ue32nQwq0 HkulFnu2084MeVQyBlI1CkT6mxlGV8aQViJRpUgtBz3WiYObJJR6yoZa xitZtw3Yq7WZM8ZXGsCIcAsu9 HBSTsU6ABVlnMSKVg4rkaTYxb//NIqJbunh1cgGf0ptFX//WjEu1XfsyJVlET/NQ9V4f2JMzD7uszJhPyNIaXOTiJSi==",
#         "bx-umidtoken": "G8198384D4ADDEB9D2D5C503B907B83FA1F8909440C99A01F00"
#     }
#     response = requests.post(url, headers=headers, params=params, data=data)
#     # print('*/*/*/*/***/**')
#     # print(response.json()['data']['url'])
#     return response.json()['data']['url']
# if __name__ == '__main__':
#     for i in range(0, 1000):
#
#         # try:
#         cookies1 = ''
#         yz_url = login()
#
#         if ('kcapslidev2' not in yz_url):
#             print('滑块')
#             continue
#         else:
#             print(yz_url)
#             cookie = diaoyong(yz_url,cookies1)
#
#             # input('iuh')
#
#             print(cookie)