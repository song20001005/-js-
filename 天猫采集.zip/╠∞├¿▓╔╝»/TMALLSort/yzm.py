# 需安装第三方requests
# img_url，图片存放路径
# 读取图片，并获取图片的base64数据
import base64, requests, json


def yz():
    api_post_url = "http://www.bingtop.com/ocr/upload/"
    with open('bg.png', 'rb') as pic_file:
        img64 = base64.b64encode(pic_file.read())
    with open('ques.png', 'rb') as pic_file:
        subCaptchaData = base64.b64encode(pic_file.read())
    params = {
        "username": "ZL7900",  # 自己的用户名和密码，下面还有一个
        "password": "ZL790035520",
        "captchaData": img64,
        'subCaptchaData': subCaptchaData,
        "captchaType": 1358,
        "soft_id": "fba0823497b4efeb8a679f841425aba2"
    }
    response = requests.post(api_post_url, data=params)
    dictdata = json.loads(response.text)
    # print(dictdata)
    # dictdata: {"code":0, "message":"", "data":{"captchaId":"1001-158201918112812","recognition":"RESULT"}}
    return dictdata


# k = yz()
# print(k)

def zizhiyz():
    api_post_url = "http://www.bingtop.com/ocr/upload/"
    with open('output.jpg', 'rb') as pic_file:
        img64 = base64.b64encode(pic_file.read())
    params = {
        "username": "lxl",  # 这里也要改
        "password": "qq787270445",
        "captchaData": img64,
        "captchaType": 1000
    }
    response = requests.post(api_post_url, data=params)
    dictdata = json.loads(response.text)
    # print(dictdata)
    # dictdata: {"code":0, "message":"", "data":{"captchaId":"1001-158201918112812","recognition":"RESULT"}}
    print(dictdata)
    return dictdata
