import json
import re, base64
import time, execjs
import concurrent.futures
import requests, random
from DrissionPage import ChromiumPage
from DrissionPage import WebPage, ChromiumOptions
from DrissionPage.common import Actions
from yzm import yz
import pyautogui


def write_x5sec(url):
    filepath = './x5sec.txt'
    with open(filepath, 'w') as f:
        f.write(str(url))


def gradual_move_to(x, y, initial_duration=0.01, final_duration=0.1, steps=10):
    # 计算每一步的目标位置
    start_x, start_y = pyautogui.position()
    step_x = (x - start_x) / steps
    step_y = (y - start_y) / steps

    # 计算每步的时间增量
    duration_increment = (final_duration - initial_duration) / steps

    for i in range(steps):
        # 计算这一步的目标位置
        end_x = start_x + step_x * (i + 1)
        end_y = start_y + step_y * (i + 1)

        # 计算这一步的持续时间
        step_duration = initial_duration + duration_increment * i

        # 移动鼠标
        pyautogui.moveTo(end_x, end_y, duration=step_duration)

        # 稍微暂停，确保动作被完全执行
        time.sleep(step_duration)


def gradual_move(distance, direction='right', initial_duration=0.03, final_duration=0.1, steps=15):
    # 根据方向计算x和y方向上的移动距离
    if direction == 'right':
        dx = distance / steps
        dy = 0
    elif direction == 'left':
        dx = -distance / steps
        dy = 2
    elif direction == 'up':
        dx = 0
        dy = -distance / steps
    elif direction == 'down':
        dx = 0
        dy = distance / steps
    else:
        raise ValueError("Direction should be 'right', 'left', 'up', or 'down'.")

    # 计算每步的时间增量
    duration_increment = (final_duration - initial_duration) / steps

    for i in range(steps):
        # 计算这一步的持续时间
        step_duration = initial_duration + duration_increment * i

        # 移动鼠标
        dy1 = random.uniform(-5, 5)
        pyautogui.move(dx, dy1, duration=step_duration)

        # 稍微暂停，确保动作被完全执行
        time.sleep(step_duration)


def yidong(page):
    # 验证失败，点击框体重试(error:A1m2K7)

    # page.refresh()
    # ‘newslidevalidate’
    # input("ffffff")
    # print(len(page.listen.steps()))

    page.wait.ele_loaded('#nc_1_n1z')
    page.wait.ele_loaded('#nc_1__scale_text')
    time.sleep(3)
    ele = page.ele('#nc_1_n1z')
    ele1 = page.ele('#nc_1__scale_text')
    locat = ele.rect.viewport_midpoint
    print(locat)
    x = locat[0]
    # y = locat[1]
    if x > 800:
        y = 730
    else:
        y = 135
    print("x:" + str(x))
    print("y:" + str(y))
    size = ele1.rect.size
    print("size:" + str(size))
    distances = size[0] - 12
    print("distances:" + str(distances))

    gradual_move_to(20, 30)
    print('都会闹')
    # 使用自定义函数移动鼠标到(500, 500)的位置，速度先快后慢
    gradual_move_to(1090, 1030)
    time.sleep(1)
    print('到这')
    pyautogui.mouseDown()
    gradual_move(random.randint(420, 630), 'right')
    time.sleep(1)
    print('你好')

    # input('抬起鼠标')
    # pyautogui.mouseUp()
    res = page.listen.wait()
    print('到没到这？')
    # input('抬起鼠标')

    response_body1 = res.response.headers
    print(response_body1)
    bx_x5sec = response_body1['bx-x5sec']
    print(bx_x5sec)
    write_x5sec(bx_x5sec)
    page_text = "".join(str(page.html).split())
    # print(page_text)
    if '验证码拦截' in page_text:
        print('重试')

        page.refresh()
        time.sleep(2)
        yidong(page)
    elif 'Denyfromx5' in page_text:
        page.quit()

    else:
        print('验证成功')


def pass_verfiy(url):
    # page = ChromiumPage()
    co = ChromiumOptions()
    co.set_argument('--start-maximized')
    # co.headless()
    co.headless(False)
    # co.set_proxy('http://{:}'.format(agentip.agentip()['http']))
    co.incognito()
    page = WebPage(chromium_options=co)
    # page.set.cookies(cookies1)
    # co.set_proxy('http://{:}'.format(agentip.agentip()['http']))
    ac = Actions(page)
    # page.listen.start('newslidecaptcha')
    page.listen.start('slide')
    page.get(url)
    # page.set.cookies(cookies)
    try:
        yidong(page)
        # print("x5sec" + str(x5sec))
        # new_x5sec_ = re.findall('x5sec=(.*?);Max-Age',"".join(str(x5sec).split()))[0]
        # print('没到这吗？')
        # print(new_x5sec_)
        time.sleep(10)
        # cookies_list = page.get_cookies(as_dict=False)
        # new_cookie_dict = {cookie['name']: cookie['value'] for cookie in cookies_list}
        # print(new_cookie_dict)
        # input('2326')
        page.quit()
    except:
        print('dd')


# /slide?slidedata


def get_x5sec_r():
    # print('被调用啦')
    file_path = './x5sec.txt'  # 将 'your_file.txt' 替换为你的文件路径
    with open(file_path, 'r', encoding='utf-8') as file:
        content = file.read()
        content_line = content.strip()  # strip()用于移除行尾的换行符和空格
    # print(content_line)
    new_x5sec_ = re.findall('x5sec=(.*?);Max-Age', "".join(str(content_line).split()))[0]
    return new_x5sec_


def diaoyong(yz_url):
    # if ('kcapslidev2' in yz_url):
    #     print('水果')
    # else:
    print(yz_url)

    pass_verfiy(yz_url)
    x5sec_r = get_x5sec_r()
    return x5sec_r
    # input('iuh')
