import time
from DrissionPage import ChromiumOptions, WebPage
from DrissionPage._functions.by import By


def login():
    chromium_options = ChromiumOptions()
    chromium_options.set_argument('--start-maximized')
    chromium_options.headless(False)
    chromium_options.incognito(True)
    page = WebPage(chromium_options=chromium_options)
    page.get(
        "https://pages-fast.m.taobao.com/wow/z/rank/default/ryQdhdPWh6cnTGfKwcct?x-ssr=true&x-preload=true&pha_manifest=default&disableProgress=true&disableNav=YES&status_bar_transparent=true&uplusRankId=91243743&tagId=91243743&rankType=9&channel=1&launchPoolId=1866&cat2Id=201195701&ind2Id=2904&wh_key=uplusRankId%3A91243743%2CtagId%3A91243743%2CrankType%3A9%2Cchannel%3A1%2ClaunchPoolId%3A1866%2Ccat2Id%3A201195701%2Cind2Id%3A2904&spm=a1zru5.26048814%2Funknown000Wap000CSR000unknown.3850741580.d_0&_isNotMiniApp=true")
    time.sleep(2)
    username = "790035520@qq.com"
    password = "ZL790035520"

    username_input = page.ele('#fm-login-id')
    password_input = page.ele("#fm-login-password")
    page.wait.ele_loaded('#fm-login-id')
    loc2 = By.XPATH, '//button[@type="submit"]'
    username_input.input(username)
    time.sleep(1)
    submit_button = page.ele("#fm-login-password")
    submit_button.click()
    password_input.input(password)
    time.sleep(1)
    submit_button = page.ele(loc2)
    submit_button.click()
    time.sleep(1)
    try:
        print('检查是否有滑块...')
        if page.wait.ele_loaded('#nc_1_n1z', timeout=2):
            print('有滑块！')
        else:
            print('没有滑块！')
    except:
        pass
    try:
        print('检查是否有手机验证码...')
        if page.wait.ele_loaded('.login-check-right', timeout=8):
            input('请输入手机校验码：')
        else:
            print('没有手机验证码！')
    except:
        pass
    input('请输入手机校验码：')
    page.refresh()
    cookies_list = page.get_cookies(as_dict=False)
    new_cookie_dict = {cookie['name']: cookie['value'] for cookie in cookies_list}
    page.quit()
    return new_cookie_dict


def get_m5():
    chromium_options = ChromiumOptions()
    chromium_options.set_argument('--start-maximized')
    chromium_options.headless(False)
    chromium_options.incognito()
    page = WebPage(chromium_options=chromium_options)
    page.get("https://www.tmall.com/")
    time.sleep(2)
    cookies_list = page.get_cookies(as_dict=False)
    new_cookie_dict = {cookie['name']: cookie['value'] for cookie in cookies_list}
    page.quit()
    return new_cookie_dict


if __name__ == '__main__':
    login()
