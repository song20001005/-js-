import json
import time
import sqlite3
import requests
import TM_sign
import threading
import DrissionLogin
from datetime import datetime


class TMALLSort:
    def __init__(self):
        self.cookies = None
        self.url = "https://h5api.m.taobao.com/h5/mtop.tmall.kangaroo.core.service.route.aldlampservice/1.0/"
        self.headers = {
            "authority": "h5api.m.tmall.com",
            "accept": "*/*",
            "accept-language": "zh-CN,zh;q=0.9",
            "referer": "https://pages.tmall.com/",
            "sec-fetch-dest": "script",
            "sec-fetch-mode": "no-cors",
            "sec-fetch-site": "same-site",
            "user-agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
            # "cookie": "t=9b76d071206ee1b8fc13638107ccab5c; xlly_s=1; thw=cn; _m_h5_tk=6dcc3c3c7142e1670939e7d35c1a7c11_1709088948350; _m_h5_tk_enc=523ae42a2ed6161ab389bc5cdeb5a159; _tb_token_=53576eeb56e8; cookie2=293c8d32825530cb570d9d350f1ea939; _samesite_flag_=true; 3PcFlag=1709081764809; sgcookie=E100B69pw%2BnIR0fjEklm8zPiuP65x6AhBJ4IfEe7cTtEeaa1C%2B0TF2xNb8Uws%2F0fIpCDPIzg0utpxvPvI50e6iGLIVwoku0c%2FXs920Tjn2lrx9wS%2FSTTiaUYoVA%2Bm6cHDes0; unb=2433649102; uc3=lg2=WqG3DMC9VAQiUQ%3D%3D&id2=UUwTo7YtaSUbfg%3D%3D&vt3=F8dD3er%2Bu7ST46RSp0g%3D&nk2=3AADR%2F0x4s6%2B; csg=6ea59f0e; lgc=%5Cu770B%5Cu6DE1l%5Cu4FD7%5Cu4E16; cancelledSubSites=empty; cookie17=UUwTo7YtaSUbfg%3D%3D; dnk=%5Cu770B%5Cu6DE1l%5Cu4FD7%5Cu4E16; skt=d9d96222c6b19a34; existShop=MTcwOTA4MTg0NA%3D%3D; uc4=id4=0%40U27M0V%2FRzOccppo9BF7FhGJuqF6X&nk4=0%403nQ0ar%2Bic8AZleiVnMmQyc2rm2g%3D; tracknick=%5Cu770B%5Cu6DE1l%5Cu4FD7%5Cu4E16; _cc_=UIHiLt3xSw%3D%3D; _l_g_=Ug%3D%3D; sg=%E4%B8%9623; _nk_=%5Cu770B%5Cu6DE1l%5Cu4FD7%5Cu4E16; cookie1=BxUAJpIUCQ3eWgRTQ5X9hx5447h2YgE8NmdwZs4WUO4%3D; mt=ci=0_1; ariaDefaultTheme=undefined; uc1=cookie16=VT5L2FSpNgq6fDudInPRgavC%2BQ%3D%3D&cookie15=WqG3DMC9VAQiUQ%3D%3D&cookie14=UoYenM29%2BM7egA%3D%3D&cookie21=URm48syIZJwcbRltXU8A0w%3D%3D&pas=0&existShop=false; isg=BDg4V9XfqUUmGcXKbnjQN6nqCebKoZwrGax5bHKphHMmjdh3GrFsu07mQYM93VQD; tfstk=eUv6zDqXAP41NI77pVieAHP3HAXjzEMrHosvqneaDOB9DtTJPR5tmfbADwTCM-lGQs6XJwJN7hWTkEtR-o7OgfAjlwLJ_IlGbmsAJnrNjqvVcHRJWSpw0ZqMtU-8QdlG3-6Gnt3rzYkyAhXcHaJXaAKghq8gB4krUhKGnt3rzcqumdsU2uwgHV-Zn-24H7dHGoUVIOJCf1h9XweAxps11aK9C-exvG11yhQC4G2PPT7uGSbThM_rADN0ikcP2zZQP-qc6MjE3DiQgt1OxM_rADN0i1IhYxoIASWf"
        }

    def timestamp(self):
        timestamp_milliseconds = int(datetime.now().timestamp() * 1000)
        return timestamp_milliseconds

    def merge_dicts(self, a, b):
        try:
            result = b.copy()
            result.update(a)
            return result
        except:
            return b

    def get_cookie(self):
        cookie1 = DrissionLogin.get_m5()
        time.sleep(2)
        cookie2 = DrissionLogin.login()
        cookies = self.merge_dicts(cookie2, cookie1)
        return cookies

    def sql_insert_data(self, sql):
        try:
            db = sqlite3.connect("db.sqlite3")
            cursor = db.cursor()
        except:
            return False
        try:
            cursor.execute(sql)
            db.commit()
            cursor.close()
            db.close()
            return True
        except Exception as e:
            print(e)
            db.rollback()
            cursor.close()
            db.close()
            return False

    def sql_update_data(self, sql):
        try:
            db = sqlite3.connect("db.sqlite3")
            cursor = db.cursor()
        except:
            return False
        try:
            cursor.execute(sql)
            db.commit()
            cursor.close()
            db.close()
            return True
        except Exception as e:
            print(e)
            db.rollback()
            cursor.close()
            db.close()
            return False

    def get_rank_info_response(self, rank_info):
        data = r'{"curPageUrl":"<<detailUrl>>","appId":"16361998","tagId":"<<tagId>>","itemId":"","bizDate":"","channel":"1","rankType":"18","bizId":1111,"backupParams":"tagId","resId":"16361998","pvuuid":"v1-8a642871-a0b3-4c14-927f-e7c5255ae2db-1709049716084","__pvuuid":"v1-8a642871-a0b3-4c14-927f-e7c5255ae2db-1709049716084","_pvuuid":"v1-8a642871-a0b3-4c14-927f-e7c5255ae2db-1709049716084"}'.replace(
            "<<tagId>>", rank_info['tagId']).replace("<<detailUrl>>", rank_info['detailUrl'])
        _m_h5_tk_value = self.headers['cookie'].split("_m_h5_tk=")[1].split("_")[0]
        timestamp = self.timestamp()
        tm_sign = TM_sign._generate_sign_2(_m_h5_tk_value, str(timestamp), "12574478", data)
        params = {
            "jsv": "2.7.2",
            "appKey": "12574478",
            "t": str(timestamp),
            "sign": tm_sign,
            "timeout": "3000",
            "api": "mtop.tmall.kangaroo.core.service.route.AldLampService",
            "params": "[object Object]",
            "dataType": "jsonp",
            "v": "1.0",
            "preventFallback": "true",
            "type": "jsonp",
            "callback": "mtopjsonp4",
            "data": data
        }
        try:
            response = requests.get(self.url, headers=self.headers, params=params)
            resultValue = json.loads(response.text.split('mtopjsonp4(')[1][:-1])['data']['resultValue']
            for k, v in resultValue.items():
                resId = k
            data_list = resultValue[resId]['data']
            for data in data_list:
                item_list = data['itemList']
                for i, item in enumerate(item_list):
                    item_id = item['itemId']
                    price = item['wapFinalPrice']
                    sort = item['index']
                    item_url = "https:" + item['url']
                    item_name = item['title']
                    tag = rank_info["tag"]
                    rank_type = rank_info["rank_type"]
                    category = [rank_info['tabId_title'], rank_info['groupTitle'], rank_info['title']]
                    sql = f"insert into item_info(item_id,price,sort,item_url,item_name,tag,rank_type,category) values('{item_id}','{price}','{sort}','{item_url}','{item_name}','{tag}','{rank_type}','{json.dumps(category, ensure_ascii=False)}')"
                    if self.sql_insert_data(sql):
                        print(item_id, item_name, rank_info['tagId'], "写入数据库成功！")
                    else:
                        print(item_id, item_name, rank_info['tagId'], "写入数据库失败！")
                    if i == 9:
                        break
        except Exception as e:
            print(e)
            with open("error.txt", "a") as f:
                f.write(rank_info['tagId'] + "\n")

    def get_rank_type_list(self, rank_info, rank_class):
        data = r'{"curPageUrl":"<<detailUrl>>","appId":"16354966","resId":"16354966","tagId":"<<tagId>>","bizId":1111,"extParam":"{\"rankOrder\":\"32,18,20,9,5\",\"launchPoolId\":\"1866,2120,2184\",\"disablePriceZone\":false}","backupParams":"tagId","pvuuid":"v1-d7175652-f6f3-49f7-b31d-3d9296ab5448-1709098326026","__pvuuid":"v1-d7175652-f6f3-49f7-b31d-3d9296ab5448-1709098326026","_pvuuid":"v1-d7175652-f6f3-49f7-b31d-3d9296ab5448-1709098326026"}'.replace(
            "<<tagId>>", rank_info['rankId']).replace("<<detailUrl>>", rank_info['detailUrl'])
        _m_h5_tk_value = self.headers['cookie'].split("_m_h5_tk=")[1].split("_")[0]
        timestamp = self.timestamp()
        tm_sign = TM_sign._generate_sign_2(_m_h5_tk_value, str(timestamp), "12574478", data)
        params = {
            "jsv": "2.7.2",
            "appKey": "12574478",
            "t": str(timestamp),
            "sign": tm_sign,
            "timeout": "3000",
            "api": "mtop.tmall.kangaroo.core.service.route.AldLampService",
            "params": "[object Object]",
            "dataType": "jsonp",
            "v": "1.0",
            "preventFallback": "true",
            "type": "jsonp",
            "callback": "mtopjsonp4",
            "data": data
        }
        tabId_title = rank_class['tabId_title']
        groupTitle = rank_class['groupTitle']
        title = rank_class['title']
        try:
            response = requests.get(self.url, headers=self.headers, params=params, verify=False)
            # print(response.text)
            resultValue = json.loads(response.text.split('mtopjsonp4(')[1][:-1])['data']['resultValue']
            for k, v in resultValue.items():
                resId = k
            data_list = resultValue[resId]['data']
            for data in data_list:
                tag = data['title']
                rank_type_list = data['children']
                for rank in rank_type_list:
                    tagId = rank['rankId']
                    rank_type = rank['title']
                    detailUrl = rank['detailUrl']
                    rank_info = {
                        "tabId_title": tabId_title,
                        "groupTitle": groupTitle,
                        "title": title,
                        "tag": tag,
                        "tagId": tagId,
                        "rank_type": rank_type,
                        "detailUrl": detailUrl,
                    }
                    sql = "INSERT INTO rank_list_info(data) values ('%s')" % json.dumps(rank_info)
                    if self.sql_insert_data(sql):
                        print(rank_info['tagId'], "写入数据库成功！")
                    else:
                        print(rank_info['tagId'], "写入数据库失败！")
        except Exception as e:
            print(e, rank_info['rankId'])
            with open("error.txt", "a") as f:
                f.write(rank_info['tagId'] + "\n")

    def get_BD_response(self, BD):
        tabId = BD['tabId']
        categoryId = BD['categoryId']
        _m_h5_tk_value = self.cookies['_m_h5_tk'].split('_')[0]
        timestamp = self.timestamp()
        data = r'{"curPageUrl":"https%3A%2F%2Fpages.tmall.com%2Fwow%2Fz%2Frank%2Fdefault%2FfMZG235a36aPN3FfEkPc","appId":"16881273","resId":"16881273","ind2Id":"<<tabId>>","categoryId":"<<categoryId>>","bizType":"tmallTab","page":0,"pageSize":5,"extParam":"{\"distinctId\":\"17065214017750001\",\"dataSetId\":38047370,\"currentAldResId\":\"33062754\",\"contentId\":\"17065214017750001\",\"launchPoolId\":\"1866,2094,2120,2184,1907,2185\",\"id\":\"17065214017750001\",\"rankOrder\":\"18,32,5,20,9\",\"importLaunchPoolIds\":\"1907,2185\",\"__pos__\":1,\"__track__\":\"33062754.33062754.42554935.2.1\"}","backupParams":"ind2Id,categoryId","bizId":1111,"pvuuid":"v1-7f8b863b-a61b-4e7d-9fc0-d93ea562aad5-1709005582660","__pvuuid":"v1-7f8b863b-a61b-4e7d-9fc0-d93ea562aad5-1709005582660","_pvuuid":"v1-7f8b863b-a61b-4e7d-9fc0-d93ea562aad5-1709005582660"}'.replace(
            "<<tabId>>", tabId).replace("<<categoryId>>", categoryId)
        tm_sign = TM_sign._generate_sign_2(_m_h5_tk_value, str(timestamp), "12574478", data)
        params = {
            "jsv": "2.7.2",
            "appKey": "12574478",
            "t": str(timestamp),
            "sign": tm_sign,
            "timeout": "3000",
            "api": "mtop.tmall.kangaroo.core.service.route.AldLampService",
            "params": "[object Object]",
            "dataType": "jsonp",
            "v": "1.0",
            "preventFallback": "true",
            "type": "jsonp",
            "callback": "mtopjsonp4",
            "data": data
        }

        try:
            response = requests.get(self.url, headers=self.headers, cookies=self.cookies, params=params)
            """这里更新cookie，保证账号不掉线"""
            resultValue = json.loads(response.text.split('mtopjsonp4(')[1][:-1])['data']['resultValue']
            for k, v in resultValue.items():
                resID = k
            data_list = resultValue[resID]['data']
            for data in data_list:
                rank_list = data['rankList']
                for rank_info in rank_list:
                    sql = "INSERT INTO rank_info(rank_list, rank_type) VALUES ('%s', '%s')" % (
                        json.dumps(rank_info, ensure_ascii=False), json.dumps(BD, ensure_ascii=False))
                    if self.sql_insert_data(sql):
                        print(rank_info['title'], "写入数据库成功！")
                    else:
                        print(rank_info['title'], "写入数据库失败！")
        except Exception as e:
            print(e)
            with open("error.txt", "a") as f:
                f.write(tabId + "  " + categoryId + "\n")

    def get_proxy(self, num):
        url = (f"http://route.xiongmaodaili.com/xiongmao-web/api/gbip?secret=25ee5a20bd1690318b0349a9cf1615"
               f"58&orderNo=GB20240228213905EmM3V1kk&count={num}&isTxt=1&proxyType=1&returnAccount=1")
        try:
            proxy = requests.get(url, headers=self.headers).text
            proxy_list = proxy.split("\r\n")
            new_proxy_list = []
            for proxy in proxy_list:
                if proxy.strip() != "":
                    new_proxy_list.append(proxy.strip())
            return new_proxy_list
        except Exception as e:
            print(e)
            return False

    def get_item_info(self, item_id, proxy):
        proxies = {
            "http": proxy,
            "https": proxy,
        }
        token = ""
        headers = self.headers
        url = "https://h5api.m.taobao.com/h5/mtop.taobao.detail.data.get/1.0/"
        for i in range(2):
            timestamp = self.timestamp()
            data = r'{"id":"%s","detail_v":"3.5.0","exParams":"{\"id\":\"%s\",\"fromNormal\":\"true\",\"detail_v\":\"3.5.0\",\"appReqFrom\":\"detail\",\"container_type\":\"xdetail\",\"dinamic_v3\":\"true\",\"supportV7\":\"true\",\"ultron2\":\"true\",\"itemNumId\":\"%s\",\"pageCode\":\"miniAppDetail\",\"_from_\":\"miniapp\",\"openFrom\":\"pagedetail\",\"pageSource\":\"1\",\"h5resist\":\"true\",\"_ultron2_\":\"true\"}"}' % (
                item_id, item_id, item_id)
            sign = TM_sign._generate_sign_2(token, str(timestamp), "12574478", data)
            params = {
                "jsv": "2.7.0",
                "appKey": "12574478",
                "t": str(timestamp),
                "sign": sign,
                "api": "mtop.taobao.detail.data.get",
                "v": "1.0",
                "ttid": "201200@taobao_h5_10.2.10",
                "isSec": "0",
                "ecode": "0",
                "AntiFlood": "true",
                "AntiCreep": "true",
                "H5Request": "true",
                "type": "jsonp",
                "dataType": "jsonp",
                "safariGoLogin": "true",
                "mainDomain": "taobao.com",
                "subDomain": "m",
                "prefix": "h5api",
                "getJSONP": "true",
                "token": token,
                "callback": "mtopjsonp4",
                "data": data
            }
            try:
                response = requests.get(url, headers=headers, params=params, proxies=proxies, verify=False)
                if i == 0:
                    token_ = response.headers['set-cookie'].split("_m_h5_tk=")[1].split(";")[0]
                    token = token_.split("_")[0]
                    token_enc = response.headers['set-cookie'].split("_m_h5_tk_enc=")[1].split(";")[0]
                    headers['Cookie'] = f"_m_h5_tk={token_}; _m_h5_tk_enc={token_enc};"
                    continue
                print(response.text)
                exit()
                data = json.loads(response.text.split('mtopjsonp4(')[1][:-1])['data']
                images = data['item']['images']
                img1 = {}
                for i, img in enumerate(images):
                    extension = img.split(".")[-1]
                    url_path = f"https:{img}"
                    file_path = f"img/{item_id}/img1/img000{str(i + 1)}.{extension}"
                    img1[f'img000{str(i + 1)}'] = {
                        "img_url": url_path,
                        "img_path": file_path
                    }
                groupProps = data['props']['groupProps']
                item_info = []
                for group in groupProps:
                    for k, v in group.items():
                        for item in v:
                            for key, value in item.items():
                                item_info.append({
                                    "key": key,
                                    "value": value
                                })
                sql = f"update item_info set item_info='{json.dumps(item_info, ensure_ascii=False)}',img1='{json.dumps(img1, ensure_ascii=False)}' where item_id='{item_id}'"
                if self.sql_insert_data(sql):
                    print(item_id, "写入数据库成功！")
                else:
                    print(item_id, "写入数据库失败！")
            except Exception as e:
                print(e)
                with open("error.txt", "a") as f:
                    f.write(item_id + "\n")

    def run(self):
        self.cookies = self.get_cookie()
        with open("BD_info.json", mode="r", encoding="utf-8") as f:
            BD_list = json.loads(f.read())
        t_list = []
        for BD in BD_list:
            t = threading.Thread(target=self.get_BD_response, args=(BD,))
            t_list.append(t)
            t.start()
            time.sleep(0.1)
        for t in t_list:
            t.join()

    def run_spider_BD_LIST(self):
        db = sqlite3.connect("db.sqlite3")
        cursor = db.cursor()
        self.headers['cookie'] = open("cookie", mode="r", encoding="utf-8").read()
        sql = "SELECT * FROM rank_info where id>3195"
        result_list = cursor.execute(sql).fetchall()
        t_list = []
        for result in result_list:
            t = threading.Thread(target=self.get_rank_type_list, args=(json.loads(result[1]), json.loads(result[2])))
            t_list.append(t)
            t.start()
            time.sleep(0.5)
        for t in t_list:
            t.join()

    def run_spider_item(self):
        db = sqlite3.connect("db.sqlite3")
        cursor = db.cursor()
        self.headers['cookie'] = open("cookie", mode="r", encoding="utf-8").read()
        sql = "SELECT DISTINCT data FROM rank_list_info ORDER BY id;"
        result_list = cursor.execute(sql).fetchall()
        t_list = []
        for result in result_list:
            t = threading.Thread(target=self.get_rank_info_response, args=(json.loads(result[0]),))
            t_list.append(t)
            t.start()
            time.sleep(0.2)
        for t in t_list:
            t.join()

    def run_spider_item_info(self):
        db = sqlite3.connect("db.sqlite3")
        cursor = db.cursor()
        self.headers['cookie'] = open("cookie", mode="r", encoding="utf-8").read()
        sql = "SELECT distinct item_id FROM item_info ORDER BY id;"
        result_list = cursor.execute(sql).fetchall()
        t_list = []
        for i, result in enumerate(result_list):
            if i % 10 == 0:
                while True:
                    proxy_list = self.get_proxy(10)
                    if proxy_list:
                        break
            # t = threading.Thread(target=self.get_item_info, args=(result[0], proxy_list[i]))
            t = threading.Thread(target=self.get_item_info, args=("608204185495", "60.184.109.96:11099"))
            t_list.append(t)
            t.start()
            time.sleep(0.2)
            break
        for t in t_list:
            t.join()


if __name__ == '__main__':
    spider = TMALLSort()
    spider.run_spider_item_info()
