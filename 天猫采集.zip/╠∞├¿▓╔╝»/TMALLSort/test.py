import requests

headers = {
    "authority": "h5api.m.tmall.com",
    "accept": "*/*",
    "accept-language": "zh-CN,zh;q=0.9",
    "referer": "https://pages.tmall.com/",
    "sec-fetch-dest": "script",
    "sec-fetch-mode": "no-cors",
    "sec-fetch-site": "same-site",
    "user-agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
    "cookie": "t=9b76d071206ee1b8fc13638107ccab5c; xlly_s=1; thw=cn; _tb_token_=7eede3ebe383b; mtop_partitioned_detect=1; _m_h5_tk=92d8a1e3c24035224ceef482ac192b0b_1709055837998; _m_h5_tk_enc=1d98fcb2345eedade295b22b32e28a71; cookie2=2b797d15568ff65edfc38413998f0d5b; _samesite_flag_=true; mt=ci=0_0; 3PcFlag=1709045768288; sgcookie=E1002W%2FVF73MZr7v%2B7TeevsJV4zWNkYNV2Eau2qbALG0kkvmzNPV37WT5TmQ9JlrkEAKygDJWK88B2dUxq2LZI2GQ42KGJRVsbuipbCkENE48SRKb2%2F5G4kdcWxCGL3kdyIj; unb=2433649102; uc3=vt3=F8dD3er%2BvwW6hHm7wTA%3D&id2=UUwTo7YtaSUbfg%3D%3D&nk2=3AADR%2F0x4s6%2B&lg2=VT5L2FSpMGV7TQ%3D%3D; csg=c69a6166; lgc=%5Cu770B%5Cu6DE1l%5Cu4FD7%5Cu4E16; cancelledSubSites=empty; cookie17=UUwTo7YtaSUbfg%3D%3D; dnk=%5Cu770B%5Cu6DE1l%5Cu4FD7%5Cu4E16; skt=ef7655a69059d8d5; existShop=MTcwOTA0NTc3OQ%3D%3D; uc4=id4=0%40U27M0V%2FRzOccppo9BF7FhG5P7Jl5&nk4=0%403nQ0ar%2Bic8AZleiVnMmQxQgStXI%3D; tracknick=%5Cu770B%5Cu6DE1l%5Cu4FD7%5Cu4E16; _cc_=URm48syIZQ%3D%3D; _l_g_=Ug%3D%3D; sg=%E4%B8%9623; _nk_=%5Cu770B%5Cu6DE1l%5Cu4FD7%5Cu4E16; cookie1=BxUAJpIUCQ3eWgRTQ5X9hx5447h2YgE8NmdwZs4WUO4%3D; uc1=cookie16=U%2BGCWk%2F74Mx5tgzv3dWpnhjPaQ%3D%3D&cookie15=VT5L2FSpMGV7TQ%3D%3D&cookie14=UoYenM2xPY60tA%3D%3D&cookie21=UtASsssmfavZrexPkAwn7A%3D%3D&pas=0&existShop=false; isg=BJ2drJnspOG3J0DFg_Ot8OxRrHmXutEMN8HGpl9i1fQjFrxIJw6Z3LyNRAoQ1unE; tfstk=evKBzHwWCWVCqxz31XMwCC5_T9IWVBiq286JnLEUeMIpegOvGk7KE2fRe1O1yuuhYasW61-FTpSLwQ9As85dz2YSN1dv8UuhLY6R6LyFKbxPFd8v9zKeU_2HSIJYYHuh4ushqghqgmo2Cpjl26kgg3p3VbR3vjoq0p3dKgJtgv2MvmIno0qqe4vn0lZT2zWFE3m0BRK1Bbfvd_6GQh6dRsQO1upWf9_CMpIzXo5f0s47CZq5CsksCz4uHaEwwRNbq8bdIOorCAaPVwBGCsksCz4lJOXZ4AM_zg1.."
}
params = {
    "jsv": "2.7.2",
    "appKey": "12574478",
    "t": "1709047175322",
    "sign": "c0f874085f688ae31b41fb1bccf92676",
    "timeout": "3000",
    "api": "mtop.tmall.kangaroo.core.service.route.AldLampService",
    "params": "[object Object]",
    "dataType": "jsonp",
    "v": "1.0",
    "preventFallback": "true",
    "type": "jsonp",
    "callback": "mtopjsonp1",
    "data": r'{"curPageUrl":"https%3A%2F%2Fpages-fast.m.taobao.com%2Fwow%2Fz%2Frank%2Fdefault%2FryQdhdPWh6cnTGfKwcct%3Fx-ssr%3Dtrue%26x-preload%3Dtrue%26pha_manifest%3Ddefault%26disableProgress%3Dtrue%26disableNav%3DYES%26status_bar_transparent%3Dtrue%26uplusRankId%3D94859054%26tagId%3D94859054%26rankType%3D18%26channel%3D1%26launchPoolId%3D1866%26cat2Id%3D201294501%26ind2Id%3D3509%26wh_key%3DuplusRankId%253A94859054%252CtagId%253A94859054%252CrankType%253A18%252Cchannel%253A1%252ClaunchPoolId%253A1866%252Ccat2Id%253A201294501%252Cind2Id%253A3509%26_isNotMiniApp%3Dtrue%26spm%3Da1zru5.26048814.tmall_rank_feeds.d_0","appId":"16361998","tagId":"94859054","itemId":"","bizDate":"","channel":"1","rankType":"18","bizId":1111,"backupParams":"tagId","resId":"16361998","pvuuid":"v1-5c25e953-96dd-4ee0-91c2-63cf00cb5161-1709047175316","__pvuuid":"v1-5c25e953-96dd-4ee0-91c2-63cf00cb5161-1709047175316","_pvuuid":"v1-5c25e953-96dd-4ee0-91c2-63cf00cb5161-1709047175316"}'
}
url = "https://h5api.m.taobao.com/h5/mtop.tmall.kangaroo.core.service.route.aldlampservice/1.0/"
res = requests.get(url, headers=headers, params=params)
print(res.text)
