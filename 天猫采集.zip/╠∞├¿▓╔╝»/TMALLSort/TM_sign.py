import hashlib


def _md5_hash(string):
    m_object = hashlib.md5()
    m_object.update(string.encode())
    hashresult = m_object.hexdigest()
    # print(hashresult)
    return hashresult


def _handle_string(json_string, ind2Id):
    # first step:find page
    page_start = json_string.find(r'"ind2Id":') + len(r'"ind2Id":')
    page_end = json_string.find(',', page_start) if json_string.find(',', page_start) != -1 else json_string.find('}',
                                                                                                                  page_start)
    # Update the value of "page" to str(page)
    updated_json_string_page = json_string[:page_start] + str(ind2Id) + json_string[page_end:]
    return updated_json_string_page


def _generate_sign_(a, b, c, data_encr, page):
    # print(data_encr)
    k = _handle_string(data_encr, page)
    # a is token,b is timesteamp,c is appkey
    srtt = a + "&" + b + "&" + c + "&" + k
    sign_value = _md5_hash(srtt)
    return k, sign_value


def _handle_string2(json_string, ind2Id, categoryId):
    # first step:find page
    page_start = json_string.find(r'"ind2Id":') + len(r'"ind2Id":')
    page_end = json_string.find(',', page_start) if json_string.find(',', page_start) != -1 else json_string.find('}',
                                                                                                                  page_start)
    # Update the value of "page" to str(page)
    updated_json_string_page = json_string[:page_start] + str(ind2Id) + json_string[page_end:]

    # Now is a new json_string

    # secend step:find pageSize
    pageSize_start = updated_json_string_page.find(r'"categoryId":"') + len(r'"categoryId":"')
    pageSize_end = updated_json_string_page.find(r'",', pageSize_start) if updated_json_string_page.find(r'",',
                                                                                                         pageSize_start) != -1 else updated_json_string_page.find(
        '}', pageSize_start)
    # Update the value of "page" to str(page)
    updated_json_string_page_pageSize = updated_json_string_page[:pageSize_start] + str(
        categoryId) + updated_json_string_page[pageSize_end:]
    return updated_json_string_page_pageSize


def _generate_sign_2(a, b, c, d):
    # k = _handle_string2(data_encr, page, pagesize)
    srtt = a + "&" + b + "&" + c + "&" + d
    sign_value = _md5_hash(srtt)
    return sign_value


def _handle_string3(json_string, ind2Id, categoryId, rankId):
    # first step:find page
    page_start = json_string.find(r'"curPageUrl":"') + len(r'"curPageUrl":"')
    page_end = json_string.find('",', page_start) if json_string.find('",', page_start) != -1 else json_string.find('}',
                                                                                                                    page_start)
    # Update the value of "page" to str(page)
    updated_json_string_page_pageSize_sourceS = json_string[:page_start] + str(ind2Id) + json_string[page_end:]

    #     # secend step:find pageSize
    #     pageSize_start = updated_json_string_page.find(r'"appId":"') + len(r'"appId":"')
    #     pageSize_end = updated_json_string_page.find(r'",', pageSize_start) if updated_json_string_page.find(r'",',pageSize_start) != -1 else updated_json_string_page.find('}', pageSize_start)
    #     # Update the value of "page" to str(page)
    #     updated_json_string_page_pageSize = updated_json_string_page[:pageSize_start] + str(categoryId) + updated_json_string_page[pageSize_end:]
    #
    # #third step:find sourceS
    #     sourceS_start = updated_json_string_page_pageSize.find(r'"resId":"') + len(r'"resId":"')
    #     sourceS_end = updated_json_string_page_pageSize.find(r'"}', sourceS_start) if updated_json_string_page_pageSize.find(r'"}', sourceS_start) != -1 else updated_json_string_page_pageSize.find('}',sourceS_start)
    #     # Update the value of "page" to str(page)
    #     updated_json_string_page_pageSize_sourceS = updated_json_string_page_pageSize[:sourceS_start] + str(categoryId) + updated_json_string_page_pageSize[sourceS_end:]

    bcoffset_start = updated_json_string_page_pageSize_sourceS.find(r'"tagId":"') + len(r'"tagId":"')
    bcoffset_end = updated_json_string_page_pageSize_sourceS.find(r'",',
                                                                  bcoffset_start) if updated_json_string_page_pageSize_sourceS.find(
        r'",', bcoffset_start) != -1 else updated_json_string_page_pageSize_sourceS.find('}', bcoffset_start)
    # Update the value of "page" to str(page)
    updated_json_string_page_pageSize_sourceS_bcoffset1 = updated_json_string_page_pageSize_sourceS[
                                                          :bcoffset_start] + str(
        rankId) + updated_json_string_page_pageSize_sourceS[bcoffset_end:]

    return updated_json_string_page_pageSize_sourceS_bcoffset1


def _generate_sign_3(a, b, c, data_encr, page, resId, rankId):
    # print(data_encr)
    k = _handle_string3(data_encr, page, resId, rankId)
    # a is token,b is timesteamp,c is appkey
    srtt = a + "&" + b + "&" + c + "&" + k
    sign_value = _md5_hash(srtt)
    return k, sign_value


def _handle_string4(json_string):
    return str(json_string)


def _generate_sign_4(a, b, c, data_encr):
    # print(data_encr)
    k = _handle_string4(data_encr)
    # a is token,b is timesteamp,c is appkey
    srtt = a + "&" + b + "&" + c + "&" + k
    sign_value = _md5_hash(srtt)
    return k, sign_value


def _handle_string5(json_string, id_value, skuId_value):
    page_start = json_string.find(r'"id":"') + len(r'"id":"')
    page_end = json_string.find('",', page_start) if json_string.find('",', page_start) != -1 else json_string.find('}',
                                                                                                                    page_start)
    # Update the value of "page" to str(page)
    updated_json_string_page_pageSize_sourceS = json_string[:page_start] + str(id_value) + json_string[page_end:]
    bcoffset_start = updated_json_string_page_pageSize_sourceS.find(r'"skuId":"') + len(r'"skuId":"')
    bcoffset_end = updated_json_string_page_pageSize_sourceS.find(r'",',
                                                                  bcoffset_start) if updated_json_string_page_pageSize_sourceS.find(
        r'",', bcoffset_start) != -1 else updated_json_string_page_pageSize_sourceS.find('}', bcoffset_start)
    # Update the value of "page" to str(page)
    updated_json_string_page_pageSize_sourceS_bcoffset1 = updated_json_string_page_pageSize_sourceS[
                                                          :bcoffset_start] + str(
        skuId_value) + updated_json_string_page_pageSize_sourceS[bcoffset_end:]

    return updated_json_string_page_pageSize_sourceS_bcoffset1


def _generate_sign_5(a, b, c, data_encr, id_value, skuId_value):
    # print(data_encr)
    k = _handle_string5(data_encr, id_value, skuId_value)
    # a is token,b is timesteamp,c is appkey
    srtt = a + "&" + b + "&" + c + "&" + k
    sign_value = _md5_hash(srtt)
    return k, sign_value


def _handle_string6(json_string, id_value, skuId_value, url_):
    page_start = json_string.find(r'"id":"') + len(r'"id":"')
    page_end = json_string.find('",', page_start) if json_string.find('",', page_start) != -1 else json_string.find('}',
                                                                                                                    page_start)
    # Update the value of "page" to str(page)
    updated_json_string_page_pageSize_sourceS = json_string[:page_start] + str(id_value) + json_string[page_end:]

    bcoffset_start = updated_json_string_page_pageSize_sourceS.find(r'\"id\":\"') + len(r'\"id\":\"')
    bcoffset_end = updated_json_string_page_pageSize_sourceS.find(r'\",',
                                                                  bcoffset_start) if updated_json_string_page_pageSize_sourceS.find(
        r'\",', bcoffset_start) != -1 else updated_json_string_page_pageSize_sourceS.find('}', bcoffset_start)
    # Update the value of "page" to str(page)
    updated_json_string_page_pageSize_sourceS1 = updated_json_string_page_pageSize_sourceS[:bcoffset_start] + str(
        id_value) + updated_json_string_page_pageSize_sourceS[bcoffset_end:]

    bcoffset_start = updated_json_string_page_pageSize_sourceS1.find(r'\"skuId\":\"') + len(r'\"skuId\":\"')
    bcoffset_end = updated_json_string_page_pageSize_sourceS1.find(r'\",',
                                                                   bcoffset_start) if updated_json_string_page_pageSize_sourceS1.find(
        r'\",', bcoffset_start) != -1 else updated_json_string_page_pageSize_sourceS1.find('}', bcoffset_start)
    # Update the value of "page" to str(page)
    updated_json_string_page_pageSize_sourceS11 = updated_json_string_page_pageSize_sourceS1[:bcoffset_start] + str(
        skuId_value) + updated_json_string_page_pageSize_sourceS1[bcoffset_end:]

    bcoffset_start = updated_json_string_page_pageSize_sourceS11.find(r'\"queryParams\":\"') + len(
        r'\"queryParams\":\"')
    bcoffset_end = updated_json_string_page_pageSize_sourceS11.find(r'\",',
                                                                    bcoffset_start) if updated_json_string_page_pageSize_sourceS11.find(
        r'\",', bcoffset_start) != -1 else updated_json_string_page_pageSize_sourceS11.find('}', bcoffset_start)
    # Update the value of "page" to str(page)
    updated_json_string_page_pageSize_sourceS_bcoffset11 = updated_json_string_page_pageSize_sourceS11[
                                                           :bcoffset_start] + str(
        url_) + updated_json_string_page_pageSize_sourceS11[bcoffset_end:]

    return updated_json_string_page_pageSize_sourceS_bcoffset11


def _generate_sign_6(a, b, c, data_encr, id_value, skuId_value, url_):
    # print(data_encr)
    k = _handle_string6(data_encr, id_value, skuId_value, url_)
    # a is token,b is timesteamp,c is appkey
    srtt = a + "&" + b + "&" + c + "&" + k
    sign_value = _md5_hash(srtt)
    return k, sign_value


def _handle_string7(json_string, ind2Id, categoryId, ranktype):
    # first step:find page
    page_start = json_string.find(r'"ind2Id":') + len(r'"ind2Id":')
    page_end = json_string.find(',', page_start) if json_string.find(',', page_start) != -1 else json_string.find('}',
                                                                                                                  page_start)
    # Update the value of "page" to str(page)
    updated_json_string_page = json_string[:page_start] + str(ind2Id) + json_string[page_end:]

    # Now is a new json_string

    # secend step:find pageSize
    pageSize_start = updated_json_string_page.find(r'"categoryId":"') + len(r'"categoryId":"')
    pageSize_end = updated_json_string_page.find(r'",', pageSize_start) if updated_json_string_page.find(r'",',
                                                                                                         pageSize_start) != -1 else updated_json_string_page.find(
        '}', pageSize_start)
    # Update the value of "page" to str(page)
    updated_json_string_page_pageSize1 = updated_json_string_page[:pageSize_start] + str(
        categoryId) + updated_json_string_page[pageSize_end:]

    pageSize_start = updated_json_string_page_pageSize1.find(r'"type":"') + len(r'"type":"')
    pageSize_end = updated_json_string_page_pageSize1.find(r'",',
                                                           pageSize_start) if updated_json_string_page_pageSize1.find(
        r'",', pageSize_start) != -1 else updated_json_string_page_pageSize1.find('}', pageSize_start)
    # Update the value of "page" to str(page)
    updated_json_string_page_pageSize = updated_json_string_page_pageSize1[:pageSize_start] + str(
        ranktype) + updated_json_string_page_pageSize1[pageSize_end:]
    return updated_json_string_page_pageSize


def _generate_sign_7(a, b, c, data_encr, page, pagesize, ranktype):
    # print(data_encr)
    k = _handle_string7(data_encr, page, pagesize, ranktype)
    # a is token,b is timesteamp,c is appkey
    srtt = a + "&" + b + "&" + c + "&" + k
    sign_value = _md5_hash(srtt)
    return k, sign_value


def _handle_string8(json_string, resId, rankId, encoded_url):
    page_start = json_string.find(r'"curPageUrl":"') + len(r'"curPageUrl":"')
    page_end = json_string.find('",', page_start) if json_string.find('",', page_start) != -1 else json_string.find('}',
                                                                                                                    page_start)
    # Update the value of "page" to str(page)
    updated_json_string_page = json_string[:page_start] + str(encoded_url) + json_string[page_end:]

    # Now is a new json_string

    # secend step:find pageSize
    pageSize_start = updated_json_string_page.find(r'"tagId":"') + len(r'"tagId":"')
    pageSize_end = updated_json_string_page.find(r'",', pageSize_start) if updated_json_string_page.find(r'",',
                                                                                                         pageSize_start) != -1 else updated_json_string_page.find(
        '}', pageSize_start)
    # Update the value of "page" to str(page)
    updated_json_string_page_pageSize1 = updated_json_string_page[:pageSize_start] + str(
        rankId) + updated_json_string_page[pageSize_end:]
    #
    # pageSize_start = updated_json_string_page_pageSize1.find(r'uplusRankId%3D') + len(r'uplusRankId%3D')
    # pageSize_end = updated_json_string_page_pageSize1.find(r'%26t',pageSize_start) if updated_json_string_page_pageSize1.find(r'%26t', pageSize_start) != -1 else updated_json_string_page_pageSize1.find('",', pageSize_start)
    # # Update the value of "page" to str(page)
    # updated_json_string_page_pageSize11 = updated_json_string_page_pageSize1[:pageSize_start] + str(rankId) + updated_json_string_page_pageSize1[pageSize_end:]
    #
    # pageSize_start = updated_json_string_page_pageSize11.find(r'agId%3D') + len(r'agId%3D')
    # pageSize_end = updated_json_string_page_pageSize11.find(r'%26rankType',pageSize_start) if updated_json_string_page_pageSize11.find(r'%26rankType', pageSize_start) != -1 else updated_json_string_page_pageSize11.find('",', pageSize_start)
    # # Update the value of "page" to str(page)
    # updated_json_string_page_pageSize12 = updated_json_string_page_pageSize11[:pageSize_start] + str(rankId) + updated_json_string_page_pageSize11[pageSize_end:]
    #
    #
    # pageSize_start = updated_json_string_page_pageSize12.find(r'uplusRankId%253A') + len(r'uplusRankId%253A')
    # pageSize_end = updated_json_string_page_pageSize12.find(r'%252Ct',pageSize_start) if updated_json_string_page_pageSize12.find(r'%252Ct', pageSize_start) != -1 else updated_json_string_page_pageSize12.find('",', pageSize_start)
    # # Update the value of "page" to str(page)
    # updated_json_string_page_pageSize122 = updated_json_string_page_pageSize12[:pageSize_start] + str(rankId) + updated_json_string_page_pageSize12[pageSize_end:]
    #
    # pageSize_start = updated_json_string_page_pageSize122.find(r'agId%253A') + len(r'agId%253A')
    # pageSize_end = updated_json_string_page_pageSize122.find(r'%252Crank',pageSize_start) if updated_json_string_page_pageSize122.find(r'%252Crank', pageSize_start) != -1 else updated_json_string_page_pageSize122.find('",', pageSize_start)
    # # Update the value of "page" to str(page)
    # updated_json_string_page_pageSize = updated_json_string_page_pageSize122[:pageSize_start] + str(rankId) + updated_json_string_page_pageSize122[pageSize_end:]

    return updated_json_string_page_pageSize1


def _generate_sign_8(a, b, c, data_encr, resId, rankId, encoded_url):
    # print(data_encr)
    k = _handle_string8(data_encr, resId, rankId, encoded_url)
    # a is token,b is timesteamp,c is appkey
    srtt = a + "&" + b + "&" + c + "&" + k
    sign_value = _md5_hash(srtt)
    return k, sign_value

    # 90f8735bd7fde9bd9981fa850c07a3ee
# Now is a new json_string

# #secend step:find pageSize
# pageSize_start = updated_json_string_page.find(r'"categoryId":"') + len(r'"categoryId":"')
# pageSize_end = updated_json_string_page.find(r'\",', pageSize_start) if updated_json_string_page.find(r'\",',pageSize_start) != -1 else updated_json_string_page.find('}', pageSize_start)
# # Update the value of "page" to str(page)
# updated_json_string_page_pageSize = updated_json_string_page[:pageSize_start] + str(categoryId) + updated_json_string_page[pageSize_end:]
# return updated_json_string_page_pageSize
#
# #third step:find sourceS
# sourceS_start = updated_json_string_page_pageSize.find(r'\"sourceS\":\"') + len(r'\"sourceS\":\"')
# sourceS_end = updated_json_string_page_pageSize.find(r'\",', sourceS_start) if updated_json_string_page_pageSize.find(r'\",', sourceS_start) != -1 else updated_json_string_page_pageSize.find('}',sourceS_start)
# # Update the value of "page" to str(page)
# updated_json_string_page_pageSize_sourceS = updated_json_string_page_pageSize[:sourceS_start] + str(sourceS) + updated_json_string_page_pageSize[sourceS_end:]
# #print(updated_json_string_page_pageSize_sourceS)
#
#
# #forth step:find bcoffset
# bcoffset_start = updated_json_string_page_pageSize_sourceS.find(r'\"bcoffset\":\"') + len(r'\"bcoffset\":\"')
# bcoffset_end = updated_json_string_page_pageSize_sourceS.find(r'\",',bcoffset_start) if updated_json_string_page_pageSize_sourceS.find(r'\",', bcoffset_start) != -1 else updated_json_string_page_pageSize_sourceS.find('}', bcoffset_start)
# # Update the value of "page" to str(page)
# updated_json_string_page_pageSize_sourceS_bcoffset= updated_json_string_page_pageSize_sourceS[:bcoffset_start] + str(bcoffset) + updated_json_string_page_pageSize_sourceS[bcoffset_end:]
# #print(updated_json_string_page_pageSize_sourceS_bcoffset)
#
#
# #fifth step:find ntoffset
# ntoffset_start = updated_json_string_page_pageSize_sourceS_bcoffset.find(r'\"ntoffset\":\"') + len(r'\"ntoffset\":\"')
# ntoffset_end = updated_json_string_page_pageSize_sourceS_bcoffset.find(r'\",',ntoffset_start) if updated_json_string_page_pageSize_sourceS_bcoffset.find(r'\",', ntoffset_start) != -1 else updated_json_string_page_pageSize_sourceS_bcoffset.find('}', ntoffset_start)
# # Update the value of "page" to str(page)
# updated_json_string_page_pageSize_sourceS_bcoffset_ntoffset = updated_json_string_page_pageSize_sourceS_bcoffset[:ntoffset_start] + str(ntoffset) + updated_json_string_page_pageSize_sourceS_bcoffset[ntoffset_end:]
#
#
# #sixth step:find totalResults
# totalResults_start = updated_json_string_page_pageSize_sourceS_bcoffset_ntoffset.find(r'\"totalResults\":\"') + len(r'\"totalResults\":\"')
# totalResults_end = updated_json_string_page_pageSize_sourceS_bcoffset_ntoffset.find(r'\",',totalResults_start) if updated_json_string_page_pageSize_sourceS_bcoffset_ntoffset.find(r'\",', totalResults_start) != -1 else updated_json_string_page_pageSize_sourceS_bcoffset_ntoffset.find('}', totalResults_start)
# # Update the value of "page" to str(page)
# updated_json_string_page_pageSize_sourceS_bcoffset_ntoffset_totalResults = updated_json_string_page_pageSize_sourceS_bcoffset_ntoffset[:totalResults_start] + str(totalResults) + updated_json_string_page_pageSize_sourceS_bcoffset_ntoffset[totalResults_end:]
# #print(updated_json_string_page_pageSize_sourceS_bcoffset_ntoffset_totalResults)
# return updated_json_string_page_pageSize_sourceS_bcoffset_ntoffset_totalResults
