function get_track() {
    var ve = [null,null,null,[[206,9521817,203]],null,null,null,null,null,null,null,null,null,null,null,null,0,null,null,null,null,null,null,null,38068846,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,[0,0,1,141,202,123,248,126],null,null,null,null,null,null,null,null,null,0,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,187,[[991,null,206,null,null,5,null,null,248,null,206,991,1288111,null,251,-896556843,null,248],[806,null,64,null,null,5,null,null,1,null,64,806,1481888,null,2,-896363233,null,1],[990,null,179,null,null,5,null,null,248,null,179,990,1669975,null,251,-896175315,null,248],[806,null,85,null,null,5,null,null,0,null,85,806,1855091,null,3,-895990031,null,0],[806,null,95,null,null,5,null,null,0,null,95,806,2036609,null,3,-895808513,null,0],[861,null,18,null,null,5,null,null,123,null,18,861,2213804,null,120,-895631279,null,123],[806,null,115,null,null,5,null,null,0,null,115,806,2385985,null,3,-895459137,null,0],[862,null,6,null,null,5,null,null,123,null,6,862,2553577,null,120,-895291620,null,123],[805,null,134,null,null,5,null,null,0,null,134,805,2716778,null,3,-895128344,null,0],[804,null,142,null,null,5,null,null,1,null,142,804,2875469,null,2,-894969654,null,1],[805,null,152,null,null,5,null,null,0,null,152,805,3029545,null,3,-894815577,null,0],[804,null,161,null,null,5,null,null,0,null,161,804,3178931,null,3,-894666191,null,0],[937,null,39,null,null,5,null,null,141,null,39,937,3323687,null,142,-894521560,null,141],[1006,null,120,null,null,5,null,null,202,null,120,1006,3463835,null,201,-894381101,null,202],[803,null,187,null,null,5,null,null,0,null,187,803,3599358,null,3,-894245764,null,0],[942,null,79,null,null,5,null,null,141,null,79,942,3730261,null,142,-894114978,null,141],[803,null,203,null,null,5,null,null,1,null,203,803,3856568,null,2,-893988553,null,1],[943,null,92,null,null,5,null,null,141,null,92,943,3978341,null,142,-893866898,null,141],[985,null,32,null,null,5,null,null,248,null,32,985,4095650,null,251,-893749288,null,248],[1003,null,21,null,null,5,null,null,202,null,21,1003,4208579,null,201,-893636469,null,202],[801,null,228,null,null,5,null,null,1,null,228,801,4317238,null,2,-893527883,null,1],[999,null,19,null,null,5,null,null,248,null,19,999,4421766,null,251,-893423108,null,248],[980,null,58,null,null,5,null,null,202,null,58,980,4522326,null,201,-893322978,null,202],[799,null,244,null,null,5,null,null,1,null,244,799,4619113,null,2,-893226010,null,1],[796,null,248,null,null,5,null,null,1,null,248,796,4712346,null,2,-893132775,null,1],[871,null,134,null,null,5,null,null,123,null,134,871,4802278,null,120,-893042913,null,123],[995,null,504,null,null,5,null,null,248,null,504,995,4889191,null,251,-892956131,null,248],[793,null,259,null,null,5,null,null,0,null,259,793,4973402,null,3,-892871720,null,0],[793,null,260,null,null,5,null,null,1,null,260,793,5055262,null,2,-892789859,null,1],[876,null,381,null,null,5,null,null,123,null,381,876,5135156,null,120,-892709943,null,123],[789,null,263,null,null,5,null,null,0,null,263,789,5213509,null,3,-892631613,null,0],[788,null,263,null,null,5,null,null,0,null,263,788,5290783,null,3,-892554339,null,0],[1002,null,511,null,null,5,null,null,248,null,511,1002,5367487,null,251,-892477499,null,248],[874,null,382,null,null,5,null,null,123,null,382,874,5444178,null,120,-892400981,null,123],[1015,null,507,null,null,5,null,null,248,null,507,1015,5521473,null,251,-892323769,null,248],[780,null,257,null,null,5,null,null,1,null,257,780,5600051,null,2,-892245072,null,1],[1011,null,4,null,null,5,null,null,248,null,4,1011,5680660,null,251,-892164502,null,248],[1009,null,15,null,null,5,null,null,248,null,15,1009,5764107,null,251,-892081039,null,248],[906,null,124,null,null,5,null,null,141,null,124,906,5851240,null,142,-891994005,null,141],[904,null,102,null,null,5,null,null,141,null,102,904,5942891,null,142,-891902364,null,141],[969,null,46,null,null,5,null,null,202,null,46,969,6039835,null,201,-891805357,null,202],[1017,null,36,null,null,5,null,null,248,null,36,1017,6142800,null,251,-891702474,null,248],[766,null,212,null,null,5,null,null,0,null,212,766,6252512,null,3,-891592610,null,0],[765,null,202,null,null,5,null,null,1,null,202,765,6369694,null,2,-891475427,null,1],[762,null,194,null,null,5,null,null,0,null,194,762,6495868,null,3,-891349254,null,0],[760,null,185,null,null,5,null,null,0,null,185,760,6633025,null,3,-891212097,null,0],[527,null,73,null,null,5,null,null,248,null,73,527,6780997,null,251,-891064261,null,248],[757,null,169,null,null,5,null,null,0,null,169,757,6936357,null,3,-890908765,null,0],[523,null,89,null,null,5,null,null,248,null,89,523,7100064,null,251,-890744858,null,248],[521,null,98,null,null,5,null,null,248,null,98,521,7271326,null,251,-890573596,null,248],[661,null,232,null,null,5,null,null,123,null,232,661,7452065,null,120,-890392988,null,123],[532,null,117,null,null,5,null,null,248,null,117,532,7640436,null,251,-890204918,null,248],[612,null,10,null,null,5,null,null,141,null,10,612,7831589,null,142,-890013650,null,141],[743,null,131,null,null,5,null,null,0,null,131,743,8024709,null,3,-889820413,null,0],[740,null,130,null,null,5,null,null,0,null,130,740,8213773,null,3,-889631349,null,0],[739,null,134,null,null,5,null,null,0,null,134,739,8395128,null,3,-889449994,null,0],[536,null,114,null,null,5,null,null,248,null,114,536,8568265,null,251,-889276737,null,248],[735,null,143,null,null,5,null,null,1,null,143,735,8734105,null,2,-889111018,null,1],[529,null,88,null,null,5,null,null,202,null,88,529,8892069,null,201,-888952855,null,202],[530,null,93,null,null,5,null,null,202,null,93,530,9051452,null,201,-888793744,null,202],[686,null,224,null,null,5,null,null,123,null,224,686,9214791,null,120,-888630338,null,123],[723,null,161,null,null,5,null,null,1,null,161,723,9371595,null,2,-888473528,null,1],[null,null,40,null,null,3,141,null,null,null,null,579,9521816,null,137,null,141],[715,null,171,null,null,5,null,null,2,null,171,715,9665168,null,2,-888179953,null,1],[587,null,61,null,null,5,null,null,142,null,61,587,9805372,null,142,-888039881,null,141],[706,null,181,null,null,5,null,null,3,null,181,706,9943234,null,3,-887901888,null,0],[631,null,113,null,null,5,null,null,201,null,113,631,10074439,null,201,-887770865,null,202],[626,null,8,null,null,5,null,null,201,null,8,626,10199277,null,201,-887645791,null,202],[691,null,200,null,null,5,null,null,3,null,200,691,10318231,null,3,-887526891,null,0],[544,null,66,null,null,5,null,null,142,null,66,544,10432901,null,142,-887412082,null,141],[549,null,91,null,null,5,null,null,142,null,91,549,10543676,null,142,-887301577,null,141],[729,null,166,null,null,5,null,null,120,null,166,729,10649336,null,120,-887195891,null,123],[598,null,47,null,null,5,null,null,201,null,47,598,10750471,null,201,-887094705,null,202],[660,null,237,null,null,5,null,null,2,null,237,660,10847755,null,2,-886997368,null,1],[581,null,62,null,null,5,null,null,201,null,62,581,10941529,null,201,-886903779,null,202],[755,null,135,null,null,5,null,null,120,null,135,755,11031767,null,120,-886813394,null,123],[640,null,261,null,null,5,null,null,2,null,261,640,11118298,null,2,-886726823,null,1],[642,null,500,null,null,5,null,null,251,null,500,642,11201196,null,251,-886643758,null,248],[627,null,276,null,null,5,null,null,3,null,276,627,11280472,null,3,-886564650,null,0],[620,null,284,null,null,5,null,null,3,null,284,620,11365123,null,3,-886479999,null,0],[744,null,424,null,null,5,null,null,142,null,424,744,11457736,null,142,-886387253,null,141],[607,null,300,null,null,5,null,null,2,null,300,607,11550940,null,2,-886294181,null,1],[669,null,511,null,null,5,null,null,201,null,511,669,11646849,null,201,-886198475,null,202],[593,null,316,null,null,5,null,null,2,null,316,593,11758126,null,2,-886086995,null,1],[561,null,318,null,null,5,null,null,120,null,318,561,11888966,null,120,-885956161,null,123],[655,null,390,null,null,5,null,null,201,null,390,655,12032738,null,201,-885812310,null,202],[575,null,340,null,null,5,null,null,3,null,340,575,12181912,null,3,-885663210,null,0],[570,null,347,null,null,5,null,null,3,null,347,570,12337346,null,3,-885507776,null,0],[716,null,410,null,null,5,null,null,251,null,410,716,12499213,null,251,-885345933,null,248],[727,null,400,null,null,5,null,null,251,null,400,727,12666366,null,251,-885178748,null,248],[593,null,276,null,null,5,null,null,120,null,276,593,12838551,null,120,-885006482,null,123],[750,null,444,null,null,5,null,null,201,null,444,750,13016406,null,201,-884828898,null,202],[542,null,381,null,null,5,null,null,2,null,381,542,13200546,null,2,-884644575,null,1],[609,null,504,null,null,5,null,null,120,null,504,609,13389829,null,120,-884455176,null,123],[735,null,320,null,null,5,null,null,201,null,320,735,13583049,null,201,-884262003,null,202],[529,null,400,null,null,5,null,null,2,null,400,529,13779698,null,2,-884065423,null,1],[523,null,408,null,null,5,null,null,3,null,408,523,13979533,null,3,-883865589,null,0],[519,null,414,null,null,5,null,null,2,null,414,519,14182429,null,2,-883662694,null,1],[512,null,423,null,null,5,null,null,2,null,423,512,14388005,null,2,-883457118,null,1],[509,null,428,null,null,5,null,null,2,null,428,509,14595926,null,2,-883249195,null,1],[504,null,435,null,null,5,null,null,3,null,435,504,14806030,null,3,-883039092,null,0],[499,null,442,null,null,5,null,null,3,null,442,499,15018158,null,3,-882826964,null,0],[278,null,313,null,null,5,null,null,251,null,313,278,15232188,null,251,-882612798,null,248],[489,null,456,null,null,5,null,null,3,null,456,489,15447986,null,3,-882397136,null,0],[415,null,436,null,null,5,null,null,120,null,436,415,15665438,null,120,-882179609,null,123],[479,null,470,null,null,5,null,null,3,null,470,479,15884471,null,3,-881960651,null,0],[475,null,477,null,null,5,null,null,3,null,477,475,16105020,null,3,-881740102,null,0],[470,null,484,null,null,5,null,null,3,null,484,470,16327024,null,3,-881518098,null,0],[348,null,358,null,null,5,null,null,142,null,358,348,16550439,null,142,-881294808,null,141],[460,null,498,null,null,5,null,null,3,null,498,460,16775221,null,3,-881069901,null,0],[319,null,257,null,null,5,null,null,251,null,257,319,17001340,null,251,-880844030,null,248],[450,null,513,null,null,5,null,null,3,null,513,450,17228772,null,3,-880616350,null,0],[445,null,520,null,null,5,null,null,3,null,520,445,17457496,null,3,-880387626,null,0],[370,null,709,null,null,5,null,null,201,null,709,370,17687492,null,201,-880157560,null,202],[377,null,732,null,null,5,null,null,201,null,732,377,17918751,null,201,-879926441,null,202],[430,null,541,null,null,5,null,null,3,null,541,430,18151260,null,3,-879693862,null,0],[292,null,680,null,null,5,null,null,142,null,680,292,18385013,null,142,-879460226,null,141],[366,null,742,null,null,5,null,null,201,null,742,366,18620004,null,201,-879225304,null,202],[359,null,715,null,null,5,null,null,251,null,715,359,18856228,null,251,-878988966,null,248],[336,null,753,null,null,5,null,null,201,null,753,336,19093687,null,201,-878751233,null,202],[404,null,578,null,null,5,null,null,3,null,578,404,19332377,null,3,-878512745,null,0],[500,null,561,null,null,5,null,null,120,null,561,500,19572299,null,120,-878272846,null,123],[395,null,592,null,null,5,null,null,2,null,592,395,19813453,null,2,-878031670,null,1],[264,null,724,null,null,5,null,null,142,null,724,264,20055843,null,142,-877789396,null,141],[437,null,682,null,null,5,null,null,201,null,682,437,20299472,null,201,-877545596,null,202],[386,null,656,null,null,5,null,null,251,null,656,386,20544341,null,251,-877300949,null,248],[373,null,624,null,null,5,null,null,3,null,624,373,20790455,null,3,-877054667,null,0],[267,null,524,null,null,5,null,null,120,null,524,267,21037819,null,120,-876807422,null,123],[363,null,638,null,null,5,null,null,2,null,638,363,21286435,null,2,-876558688,null,1],[286,null,764,null,null,5,null,null,120,null,764,286,21536310,null,120,-876308785,null,123],[423,null,631,null,null,5,null,null,251,null,631,423,21787450,null,251,-876057792,null,248],[347,null,662,null,null,5,null,null,2,null,662,347,22039859,null,2,-875805264,null,1],[414,null,596,null,null,5,null,null,201,null,596,414,22293541,null,201,-875551639,null,202],[439,null,606,null,null,5,null,null,251,null,606,439,22548504,null,251,-875296658,null,248],[433,null,598,null,null,5,null,null,251,null,598,433,22804753,null,251,-875040393,null,248],[457,null,571,null,null,5,null,null,142,null,571,457,23062294,null,142,-874782951,null,141],[319,null,703,null,null,5,null,null,2,null,703,319,23321132,null,2,-874523989,null,1],[322,null,700,null,null,5,null,null,120,null,700,322,23581276,null,120,-874263903,null,123],[306,null,718,null,null,5,null,null,2,null,718,306,23842730,null,2,-874002391,null,1],[342,null,684,null,null,5,null,null,120,null,684,342,24105499,null,120,-873739550,null,123],[297,null,734,null,null,5,null,null,2,null,734,297,24369592,null,2,-873475529,null,1],[488,null,557,null,null,5,null,null,201,null,557,488,24635013,null,201,-873209911,null,202],[484,null,520,null,null,5,null,null,251,null,520,484,24901771,null,251,-872943119,null,248],[279,null,761,null,null,5,null,null,2,null,761,279,25169874,null,2,-872675247,null,1],[272,null,769,null,null,5,null,null,2,null,769,272,25439325,null,2,-872405798,null,1],[368,null,882,null,null,5,null,null,120,null,882,368,25710130,null,120,-872134965,null,123],[382,null,874,null,null,5,null,null,120,null,874,382,25982297,null,120,-871862868,null,123],[132,null,865,null,null,5,null,null,120,null,865,132,26255836,null,120,-871589343,null,123],[249,null,802,null,null,5,null,null,3,null,802,249,26530749,null,3,-871314373,null,0],[243,null,811,null,null,5,null,null,3,null,811,243,26807047,null,3,-871038075,null,0],[150,null,847,null,null,5,null,null,120,null,847,150,27084734,null,120,-870760377,null,123],[31,null,964,null,null,5,null,null,251,null,964,31,27363818,null,251,-870481264,null,248],[25,null,957,null,null,5,null,null,251,null,957,25,27644308,null,251,-870200598,null,248],[17,null,900,null,null,5,null,null,201,null,900,17,27926210,null,201,-869918838,null,202],[31,null,925,null,null,5,null,null,201,null,925,31,28209528,null,201,-869635780,null,202],[207,null,863,null,null,5,null,null,3,null,863,207,28494270,null,3,-869350852,null,0],[179,null,787,null,null,5,null,null,120,null,787,179,28780449,null,120,-869064604,null,123],[58,null,905,null,null,5,null,null,251,null,905,58,29068066,null,251,-868777128,null,248],[188,null,890,null,null,5,null,null,3,null,890,188,29357126,null,3,-868487996,null,0],[124,null,841,null,null,5,null,null,201,null,841,124,29647643,null,201,-868197549,null,202],[212,null,1015,null,null,5,null,null,120,null,1015,212,29939621,null,120,-867905448,null,123],[81,null,878,null,null,5,null,null,251,null,878,81,30233069,null,251,-867612013,null,248],[105,null,853,null,null,5,null,null,201,null,853,105,30527991,null,201,-867317057,null,202],[156,null,936,null,null,5,null,null,3,null,936,156,30824396,null,3,-867020726,null,0],[150,null,945,null,null,5,null,null,3,null,945,150,31122294,null,3,-866722828,null,0],[142,null,954,null,null,5,null,null,2,null,954,142,31421693,null,2,-866423430,null,1],[113,null,828,null,null,5,null,null,251,null,828,113,31722592,null,251,-866122714,null,248],[130,null,973,null,null,5,null,null,3,null,973,130,32025007,null,3,-865820115,null,0],[132,null,815,null,null,5,null,null,251,null,815,132,32328946,null,251,-865516152,null,248],[14,null,923,null,null,5,null,null,120,null,923,14,32634411,null,120,-865210670,null,123],[226,null,871,null,null,5,null,null,142,null,871,226,32941415,null,142,-864903832,null,141],[19,null,904,null,null,5,null,null,120,null,904,19,33249963,null,120,-864595118,null,123],[96,null,1020,null,null,5,null,null,2,null,1020,96,33560060,null,2,-864285061,null,1],[91,null,1031,null,null,5,null,null,3,null,1031,91,33871719,null,3,-863973403,null,0],[84,null,1041,null,null,5,null,null,3,null,1041,84,34184942,null,3,-863660180,null,0],[181,null,1250,null,null,5,null,null,251,null,1250,181,34499744,null,251,-863345178,null,248],[190,null,1244,null,null,5,null,null,251,null,1244,190,34816130,null,251,-863028744,null,248],[68,null,1109,null,null,5,null,null,120,null,1109,68,35134104,null,120,-862710931,null,123],[57,null,1081,null,null,5,null,null,2,null,1081,57,35453679,null,2,-862391444,null,1],[191,null,1231,null,null,5,null,null,142,null,1231,191,35774861,null,142,-862070138,null,141],[43,null,1100,null,null,5,null,null,3,null,1100,43,36097663,null,3,-861747459,null,0],[36,null,1110,null,null,5,null,null,3,null,1110,36,36422086,null,3,-861423036,null,0],[215,null,1194,null,null,5,null,null,201,null,1194,215,36748142,null,201,-861097178,null,202],[20,null,1130,null,null,5,null,null,2,null,1130,20,37075838,null,2,-860769283,null,1],[131,null,1272,null,null,5,null,null,142,null,1272,131,37405182,null,142,-860439823,null,141],[7,null,1151,null,null,5,null,null,3,null,1151,7,37736181,null,3,-860108941,null,0],[202,null,1091,null,null,5,null,null,201,null,1091,202,38068846,null,201,-859776474,null,202]],null,null,1708499138686]
    for (j = 0; j < ve[90].length; j++) {
        if(ve[90][j].length==16){
        continue
        }
         offset1 = Math.floor(Math.random() * (8 + 8) - 8);
         ve[90][j][2] = ve[90][j][2] + offset1;
         ve[90][j][10] = ve[90][j][2];
       // offset2 = Math.floor(Math.random() * (1 + 1) - 1);
       // ve[90][j][0] = ve[90][j][0] + offset2;
       // ve[90][j][11] = ve[90][j][0]
    }
    return ve
}



function get_time_arr8(a) {
    var Be = a;
    Ie = void 0;
    So = (ko = 0 | (So = (ye = Be) / (Be = 4294967296))) * Be;
    Be = ye - So;
    ye = void 0;
    So = ko;
    ko = [];
    W = 255 & (ze = So >> 24);
    V = 255 & (ze = So >> 16);
    me = 255 & (ze = So >> 8);
    ze = 255 & So;
    ko.push(W, V, me, ze);
    So = ye = ko;
    ye = void 0;
    ko = Be;
    Be = [];
    W = 255 & (ze = ko >> 24);
    V = 255 & (ze = ko >> 16);
    me = 255 & (ze = ko >> 8);
    ze = 255 & ko;
    Be.push(W, V, me, ze);
    Be = ye = Be;
    ye = So.concat(Be);
    return ye;
}

function get_arr_5(k) {
    var arr_5 = [];
    for (var i = 0; i < k.length; i++) {
        if (k[i].length == 17) {
            arr_5.push(i)
        } else {

        }
    };
    return arr_5
}

function track_enc() {
    var Q = [30, 4, 300, 6, 0, 'cn', 14, undefined, 1, 200, 1, 1, 30, 4];
    var $ = void 0;
    var G = Q;
    var k = (oe = ve)[90];
    // oe[89] = k.length;
    oe[58] = 0;
//    oe[18] = [6, 7];
    oe[18]=[5,6];
    oe[5] = get_arr_5(k); //轨迹中长度为17的下标
    oe[46] = oe[5][oe[5].length - 1] - 1;
    if (oe[46] < 0) {
        oe[46] = 0;
    }

    var no = "Reflect";
    var ri = "clear";
    var _e = "navigator";
    var f = "hardwareConcurrency";
    var oo = "passive";
    li = k ? 4353 : 13953;
    while (li != 'lxl') {
        var gi = li >> 5,
            Ci = 31 & gi,
            mi = 31 & gi >> 5;
        // console.log(li);
        switch (31 & li) {
            case 0:
                switch (Ci) {
                    case 0:
                        switch (mi) {
                            case 16:
                                re = J[18],
                                    ke = void 0,
                                    ae = 0,
                                    Ee = N,
                                    li = (Be = re).indexOf ? 10915 : 6912
                                break;
                            default:
                                console.log('0-0');
                                break;
                        }
                        break;
                    case 2:
                        switch (mi) {
                            case 18:
                                j = b,
                                    li = 18243
                                break;
                            default:
                                console.log('0-2');
                                break;
                        }
                        break;
                    case 4:
                        switch (mi) {
                            case 0:
                                y = 3 === x[5],
                                    li = y ? 4450 : 19557
                                break;
                            case 20:
                                D = k[m],
                                    N = 5 !== D[5],
                                    li = N ? 28929 : 323
                                break;
                            default:
                                console.log('0-4');
                                break;
                        }
                        break;
                    case 7:
                        switch (mi) {
                            case 15:
                                // console.log(ve);
                                // console.log(S[0]);
                                li = 'lxl'
                                break;
                            default:
                                console.log('0-7');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 7:
                                E = 127 & y,
                                    li = (y >>= 7) ? 6884 : 29536
                                break;
                            case 20:
                                L = V >= -4,
                                    li = (qe = (bo = (Oo = (Y = Y < 5) * Y) + (qe = (P = 0 == P) * P)) >= (fe = Y * P)) ? 28449 : 9827
                                break;
                            default:
                                console.log('0-8');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 19:
                                ke = 128 + (V = M % 128),
                                    V = 127 & (re = (J = M - V) / 128),
                                    (J = []).push(ke, V),
                                    B = J,
                                    li = 21092
                                break;
                            case 23:
                                li = (L = x) ? 13665 : 28676
                                break;
                            default:
                                console.log('0-9');
                                break;
                        }
                        break;
                    case 10:
                        switch (mi) {
                            case 1:
                                li = m < k.length ? 20608 : 6533
                                break;
                            default:
                                console.log('0-10');
                                break;
                        }
                        break;
                    case 13:
                        switch (mi) {
                            case 20:
                                li = (Se = -1 === (Be = Se)) ? 18562 : 8611
                                break;
                            default:
                                console.log('0-13');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 25:
                                li = (N = L) ? 17251 : 6402
                                break;
                            default:
                                console.log('0-14');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 3:
                                m = B,
                                    li = 12099
                                break;
                            default:
                                console.log('0-15');
                                break;
                        }
                        break;
                    case 17:
                        switch (mi) {
                            case 10:
                                li = (B = (y = B) < 64) ? 3493 : 1377
                                break;
                            default:
                                console.log('0-17');
                                break;
                        }
                        break;
                    case 18:
                        switch (mi) {
                            case 4:
                                ae = J[18],
                                    re = ae.length,
                                    (ae = J[18]).push(N),
                                    li = 26;
                                break;
                            case 5:
                                m++,
                                li = 1344
                                break;
                            default:
                                console.log('0-18');
                                break;
                        }
                        break;
                    case 23:
                        switch (mi) {
                            case 25:
                                x = m,
                                    (L = L.concat(x)).push(V),
                                    m = void 0,
                                    li = (x = (y = 0 | (x = J)) < 16384) ? 20898 : 20322
                                break;
                            default:
                                console.log('0-23');
                                break;
                        }
                        break;
                    case 27:
                        switch (mi) {
                            case 28:
                                B.push(E),
                                    li = y ? 7393 : 7524
                                break;
                            default:
                                console.log('0-27');
                                break;
                        }
                        break;
                }
                break;
            case 1:
                switch (Ci) {
                    case 2:
                        switch (mi) {
                            case 26:
                                ee = ae = [ke],
                                    li = 22146
                                break;
                            default:
                                console.log('1-2');
                                break;
                        }
                        break;
                    case 3:
                        switch (mi) {
                            case 5:
                                J = 1,
                                    li = 10692
                                break;
                            case 6:
                                m = E = [x + 64 * y],
                                    li = 481
                                break;
                            default:
                                console.log('1-3');
                                break;
                        }
                        break;
                    case 4:
                        switch (mi) {
                            case 16:
                                B = x,
                                    li = (bo = (A = (fe = S !== f) * fe) >= (bo = (qe = fe * (P = 11)) - (Oo = P * P))) ? 23044 : 16898
                                break;
                            default:
                                console.log('1-4');
                                break;
                        }
                        break;
                    case 5:
                        switch (mi) {
                            case 3:
                                J = 0,
                                    li = 2468
                                break;
                            default:
                                console.log('1-5');
                                break;
                        }
                        break;
                    case 6:
                        switch (mi) {
                            case 12:
                                B = x,
                                    D = D.concat(B),
                                    x = void 0,
                                    li = (B = (E = 0 | (B = J)) < 16384) ? 22149 : 13604
                                break;
                            case 16:
                                ke = void 0,
                                    Ee = ee,
                                    Be = (ae = L)[18],
                                    Se = void 0,
                                    Ue = 0,
                                    Ve = Ee;
                                li = (Ne = Be).indexOf ? 2466 : 2305
                                break;
                            default:
                                console.log('1-6');
                                break;
                        }
                        break;
                    case 7:
                        switch (mi) {
                            case 7:
                                li = 7424
                                break;
                            default:
                                console.log('1-7');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 4:
                                S = [],
                                    C = G[2] * G[13],
                                    b = oe[89] - C,
                                    li = (C = b < 0) ? 16965 : 1091
                                break;
                            case 28:
                                li = 5696
                                break;
                            default:
                                console.log('1-8');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 7:
                                C = w = [j],
                                    li = 21763
                                break;
                            default:
                                console.log('1-9');
                                break;
                        }
                        break;
                    case 11:
                        switch (mi) {
                            case 1:
                                ke = 128 + (E = y % 128),
                                    ae = (E = 63 & (re = (M = y - E) / 128)) + (re = 64 * x),
                                    (M = []).push(ke, ae),
                                    m = M,
                                    li = 26336
                                break;
                            case 13:
                                x = (B = 128 | (x = J << 6)) | (E = (x = M + 4) << 3),
                                    B = V + 4,
                                    D[0] = x | B,
                                    li = 1347
                                break;
                            default:
                                console.log('1-11');
                                break;
                        }
                        break;
                    case 13:
                        switch (mi) {
                            case 17:
                                x = ee,
                                    li = 15843
                                break;
                            default:
                                console.log('1-13');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 25:
                                ae = 128 + (E = x % 128),
                                    Ee = (E = 63 & (ke = (re = x - E) / 128)) + (ke = 64 * y),
                                    (re = []).push(ae, Ee),
                                    m = re,
                                    li = 481
                                break;
                            default:
                                console.log('1-14');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 0:
                                x = m,
                                    L = L.concat(x),
                                    m = void 0,
                                    li = (B = x = (y = 0 | (x = M)) < 0) ? 4610 : 13060
                                break;
                            default:
                                console.log('1-15');
                                break;
                        }
                        break;
                    case 19:
                        switch (mi) {
                            case 5:
                                li = (ee = (E = ee) < 64) ? 28898 : 16581
                                break;
                            default:
                                console.log('1-19');
                                break;
                        }
                        break;
                    case 25:
                        switch (mi) {
                            case 27:
                                li = (x = L) ? 13605 : 23840
                                break;
                            default:
                                console.log('1-25');
                                break;
                        }
                        break;
                    case 27:
                        switch (mi) {
                            case 2:
                                li = 27268
                                break;
                            default:
                                console.log('1-27');
                                break;
                        }
                        break;
                }
                break;
            case 2:
                switch (Ci) {
                    case 0:
                        switch (mi) {
                            case 21:
                                N = 128 + (I = j % 128),
                                    I = 127 & (D = (m = j - I) / 128),
                                    (m = []).push(N, I),
                                    C = m,
                                    li = 2564
                                break;
                            default:
                                console.log('2-0');
                                break;
                        }
                        break;
                    case 3:
                        switch (mi) {
                            case 16:
                                li = (x = L) ? 9733 : 8581
                                break;
                            default:
                                console.log('2-3');
                                break;
                        }
                        break;
                    case 4:
                        switch (mi) {
                            case 2:
                                m = 1,
                                    li = 128
                                break;
                            case 18:
                                Ue = ae[18],
                                    Be = Ue.length,
                                    (Ue = ae[18]).push(Ee),
                                    li = 8611
                                break;
                            case 27:
                                ee = E,
                                    li = 5729
                                break;
                            default:
                                console.log('2-4');
                                break;
                        }
                        break;
                    case 5:
                        switch (mi) {
                            case 28:
                                li = (L = N) ? 25316 : 26048
                                break;
                            default:
                                console.log('2-5');
                                break;
                        }
                        break;
                    case 7:
                        switch (mi) {
                            case 28:
                                x = re = [E + 64 * B],
                                    li = 12773
                                break;
                            default:
                                console.log('2-7');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 0:
                                ee.push(re),
                                    li = E ? 2913 : 8834
                                break;
                            case 6:
                                N = void 0,
                                    L = oe,
                                    x = w,
                                    D = (y = D)[12],
                                    B = L[48],
                                    M = B[E = D % 7],
                                    B = 0,
                                    E = 0,
                                    ee = void 0 !== y[2],
                                    li = 6434
                                break;
                            default:
                                console.log('2-8');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 2:
                                ee = E,
                                    li = 23909
                                break;
                            case 6:
                                li = ee ? 13540 : 29281
                                break;
                            default:
                                console.log('2-9');
                                break;
                        }
                        break;
                    case 11:
                        switch (mi) {
                            case 4:
                                m = 2,
                                    li = 19557
                                break;
                            default:
                                console.log('2-11');
                                break;
                        }
                        break;
                    case 13:
                        switch (mi) {
                            case 2:
                                Be = Ne.indexOf(Ve),
                                    Se = Be,
                                    li = 20896
                                break;
                            case 20:
                                B = void 0,
                                    li = (E = (M = 0 | (E = y)) < 128) ? 15876 : 19744
                                break;
                            default:
                                console.log('2-13');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 6:
                                ee = M ^ y[14],
                                    y = 0 === x.length,
                                    li = y ? 2469 : 4133
                                break;
                            case 20:
                                N = C.length - I,
                                    L = 2 * G[12],
                                    li = (x = N > L) ? 25602 : 17987
                                break;
                            default:
                                console.log('2-14');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 4:
                                B = -y,
                                    li = 10784
                                break;
                            default:
                                console.log('2-16');
                                break;
                        }
                        break;
                    case 17:
                        switch (mi) {
                            case 7:
                                L[2] = 0,
                                    L[11] = 0,
                                    L[12] = 0,
                                    li = 16741
                                break;
                            default:
                                console.log('2-17');
                                break;
                        }
                        break;
                    case 20:
                        switch (mi) {
                            case 8:
                                li = 17825
                                break;
                            case 21:
                                x = re = ee,
                                    li = 15843
                                break;
                            default:
                                console.log('2-20');
                                break;
                        }
                        break;
                    case 22:
                        switch (mi) {
                            case 2:
                                m = I,
                                    li = 1344
                                break;
                            default:
                                console.log('2-22');
                                break;
                        }
                        break;
                    case 25:
                        switch (mi) {
                            case 7:
                                L = M >= -4,
                                    li = 16482
                                break;
                            case 28:
                                re |= 128,
                                    li = 258
                                break;
                            default:
                                console.log('2-25');
                                break;
                        }
                        break;
                    case 27:
                        switch (mi) {
                            case 19:
                                B = [],
                                    li = 7424
                                break;
                            default:
                                console.log('2-27');
                                break;
                        }
                        break;
                    case 28:
                        switch (mi) {
                            case 20:
                                m = void 0,
                                    li = (N = (x = 0 | (N = ee)) < 128) ? 7460 : 18048
                                break;
                            default:
                                console.log('2-28');
                                break;
                        }
                        break;
                }
                break;
            case 3:
                switch (Ci) {
                    case 2:
                        switch (mi) {
                            case 1:
                                C = oe[46],
                                    li = (j = -1 === C) ? 20163 : 19107
                                break;
                            default:
                                console.log('3-2');
                                break;
                        }
                        break;
                    case 6:
                        switch (mi) {
                            case 4:
                                I++,
                                li = 708
                                break;
                            default:
                                console.log('3-6');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 21:
                                b = C,
                                    S[0] = b.concat(S[0]),
                                    $ = S,
                                    li = 3717
                                break;
                            default:
                                console.log('3-8');
                                break;
                        }
                        break;
                    case 10:
                        switch (mi) {
                            case 0:
                                li = (N = m !== I) ? 22212 : 28834
                                break;
                            case 1:
                                D = N = D,
                                    N = S[1],
                                    S[1] = N.concat(D),
                                    j++,
                                    li = 5696
                                break;
                            default:
                                console.log('3-10');
                                break;
                        }
                        break;
                    case 11:
                        switch (mi) {
                            case 19:
                                li = (x = L) ? 25221 : 7813
                                break;
                            default:
                                console.log('3-11');
                                break;
                        }
                        break;
                    case 12:
                        switch (mi) {
                            case 1:
                                m = C[I],
                                    D = m + oe[58],
                                    li = (N = D < 0) ? 25219 : 20930
                                break;
                            default:
                                console.log('3-12');
                                break;
                        }
                        break;
                    case 13:
                        switch (mi) {
                            case 8:
                                y = ke = ae = Be + 1,
                                    li = 24419
                                break;
                            case 26:
                                C = I = [j],
                                    li = 2564
                                break;
                            default:
                                console.log('3-13');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 15:
                                B = x,
                                    D = D.concat(B),
                                    x = void 0,
                                    li = (ee = B = (E = 0 | (B = M)) < 0) ? 20004 : 2338
                                break;
                            default:
                                console.log('3-15');
                                break;
                        }
                        break;
                    case 18:
                        switch (mi) {
                            case 17:
                                li = (m = x) ? 29410 : 18821
                                break;
                            default:
                                console.log('3-18');
                                break;
                        }
                        break;
                    case 19:
                        switch (mi) {
                            case 8:
                                y = x[12],
                                    B = N[48],
                                    M = B[E = y % 7],
                                    B = M ^ x[2],
                                    E = M ^ x[11],
                                    ee = M ^ x[14],
                                    V = void 0,
                                    J = N,
                                    N = ee,
                                    li = 16384
                                break;
                            default:
                                console.log('3-19');
                                break;
                        }
                        break;
                    case 21:
                        switch (mi) {
                            case 10:
                                re = Be.indexOf(Ee);
                                ke = re;
                                li = 14596
                                break;
                            case 18:
                                li = (j = C < b) ? 19106 : 18496
                                break;
                            default:
                                console.log('3-21');
                                break;
                        }
                        break;
                    case 22:
                        switch (mi) {
                            case 14:
                                B = x,
                                    D = D.concat(B),
                                    x = void 0,
                                    li = (ee = B = (E = 0 | (B = V)) < 0) ? 26117 : 27778
                                break;
                            case 19:
                                C = b,
                                    li = 19107
                                break;
                            default:
                                console.log('3-22');
                                break;
                        }
                        break;
                    case 23:
                        switch (mi) {
                            case 2:
                                x = ee = [E],
                                    li = 12481
                                break;
                            default:
                                console.log('3-23');
                                break;
                        }
                        break;
                    case 26:
                        switch (mi) {
                            case 11:
                                x = m,
                                    (L = L.concat(x)).push(N),
                                    li = (m = 1 === N) ? 15362 : 21378
                                break;
                            case 17:
                                b = j,
                                    S[1] = [],
                                    j = 0,
                                    w = [],
                                    I = b + oe[58],
                                    li = (m = I < 0) ? 4800 : 2754
                                break;
                            default:
                                console.log('3-26');
                                break;
                        }
                        break;
                    case 27:
                        switch (mi) {
                            case 16:
                                li = 5696
                                break;
                            case 23:
                                li = (L = 16 === J) ? 3233 : 2468
                                break;
                            default:
                                console.log('3-27');
                                break;
                        }
                        break;
                }
                break;
            case 4:
                switch (Ci) {
                    case 0:
                        switch (mi) {
                            case 28:
                                x = void 0,
                                    li = (B = (E = 0 | (B = y)) < 64) ? 2787 : 8960
                                break;
                            default:
                                console.log('4-28');
                                break;
                        }
                        break;
                    case 7:
                        switch (mi) {
                            case 13:
                                B = M ^ y[2],
                                    E = M ^ y[11],
                                    li = 6594
                                break;
                            default:
                                console.log('4-7');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 14:
                                li = (ke = -1 === (re = ke)) ? 4672 : 26
                                break;
                            default:
                                console.log('4-8');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 7:
                                m = y = [x],
                                    li = 37
                                break;
                            case 13:
                                ee = [],
                                    li = 27268
                                break;
                            default:
                                console.log('4-9');
                                break;
                        }
                        break;
                    case 11:
                        switch (mi) {
                            case 7:
                                li = mi < 8 ? 3552 : ao ? 16930 : 19204
                                break;
                            default:
                                console.log('4-11');
                                break;
                        }
                        break;
                    case 12:
                        switch (mi) {
                            case 28:
                                B = -x,
                                    li = 23044
                                break;
                            default:
                                console.log('4-12');
                                break;
                        }
                        break;
                    case 13:
                        switch (mi) {
                            case 2:
                                li = (L = 17 === J) ? 5217 : 10692
                                break;
                            default:
                                console.log('4-13');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 10:
                                x[14] = ee,
                                    x[2] = B,
                                    x[11] = E,
                                    x[12] = D,
                                    D = [],
                                    li = (L = 0 === y) ? 14884 : 19811
                                break;
                            default:
                                console.log('4-14');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 2:
                                j = C;
                                S[1] = j.concat(S[1]);
                                S[0] = [];
                                C = oe[5];
                                j = 0;
                                w = [];
                                I = 0;
                                li = 708
                                break;
                            case 15:
                                B = V = [M],
                                    li = 21092
                                break;
                            case 22:
                                li = (B = (x = B) < 64) ? 6241 : 26049
                                break;
                            default:
                                console.log('4-16');
                                break;
                        }
                        break;
                    case 17:
                        switch (mi) {
                            case 14:
                                L = J >= 0,
                                    li = 19811
                                break;
                            case 19:
                                ee = -E,
                                    li = 23909
                                break;
                            default:
                                console.log('4-17');
                                break;
                        }
                        break;
                    case 19:
                        switch (mi) {
                            case 20:
                                m = E = B,
                                    li = (A = (fe = (P = oo !== w) * P) > -52) ? 12099 : 28961
                                break;
                            default:
                                console.log('4-19');
                                break;
                        }
                        break;
                    case 20:
                        switch (mi) {
                            case 25:
                                Se = 128 + (ae = ke % 128),
                                    ae = 127 & (Be = (Ee = ke - ae) / 128),
                                    (Ee = []).push(Se, ae),
                                    ee = Ee,
                                    li = 22146
                                break;
                            case 26:
                                re = 127 & E,
                                    li = (E >>= 7) ? 29474 : 258
                                break;
                            default:
                                console.log('4-20');
                                break;
                        }
                        break;
                    case 22:
                        switch (mi) {
                            case 0:
                                li = I < C.length ? 1411 : 12901
                                break;
                            case 21:
                                L = C + oe[58],
                                    N = m < L,
                                    li = 28834
                                break;
                            default:
                                console.log('4-22');
                                break;
                        }
                        break;
                    case 23:
                        switch (mi) {
                            case 6:
                                E |= 128,
                                    li = 29536
                                break;
                            case 24:
                                N = m % G[13],
                                    L = 0 !== N,
                                    li = 26048
                                break;
                            default:
                                console.log('4-23');
                                break;
                        }
                        break;
                    case 24:
                        switch (mi) {
                            case 8:
                                Ee = 128 + (re = E % 128),
                                    Be = (re = 63 & (ae = (ke = E - re) / 128)) + (ae = 64 * B),
                                    (ke = []).push(Ee, Be),
                                    x = ke;
                                li = 15043
                                break;
                            case 12:
                                B = y,
                                    li = 10784
                                break;
                            default:
                                console.log('4-24');
                                break;
                        }
                        break;
                }
                break;
            case 5:
                switch (Ci) {
                    case 1:
                        switch (mi) {
                            case 0:
                                N = m,
                                    L = L.concat(N),
                                    m = D = L,
                                    D = S[0],
                                    S[0] = D.concat(m),
                                    j++,
                                    li = 4291
                                break;
                            case 4:
                                y = ee,
                                    M = B - x[2],
                                    V = E - x[11],
                                    J = D - x[12],
                                    re = y === x[14],
                                    li = re ? 27813 : 16577
                                break;
                            default:
                                console.log('5-1');
                                break;
                        }
                        break;
                    case 3:
                        switch (mi) {
                            case 19:
                                y = 1 === x[5],
                                    li = y ? 580 : 8803
                                break;
                            default:
                                console.log('5-3');
                                break;
                        }
                        break;
                    case 5:
                        switch (mi) {
                            case 0:
                                x = re = [E + 64 * B],
                                    li = 15043
                                break;
                            case 27:
                                y = 0,
                                    li = 24419
                                break;
                            default:
                                console.log('5-5');
                                break;
                        }
                        break;
                    case 6:
                        switch (mi) {
                            case 16:
                                Ee = 128 + (re = E % 128),
                                    Be = (re = 63 & (ae = (ke = E - re) / 128)) + (ae = 64 * B),
                                    (ke = []).push(Ee, Be),
                                    x = ke,
                                    li = 12773
                                break;
                            default:
                                console.log('5-6');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 13:
                                x = V <= 3,
                                    li = 23840
                                break;
                            default:
                                console.log('5-9');
                                break;
                        }
                        break;
                    case 10:
                        switch (mi) {
                            case 12:
                                li = (B = y) ? 29060 : 16513
                                break;
                            default:
                                console.log('5-10');
                                break;
                        }
                        break;
                    case 11:
                        switch (mi) {
                            case 16:
                                x = B - L[2],
                                    M = E - L[11],
                                    J = y - L[12],
                                    L[2] = B,
                                    L[11] = E,
                                    L[12] = y,
                                    L = [m],
                                    m = void 0,
                                    y = (x = 0 | (y = x)) < 0,
                                    li = 12613
                                break;
                            case 23:
                                li = (ee = (E = ee) < 64) ? 165 : 8964
                                break;
                            default:
                                console.log('5-11');
                                break;
                        }
                        break;
                    case 12:
                        switch (mi) {
                            case 6:
                                C = void 0,
                                    li = (w = (j = 0 | (w = j)) < 128) ? 27043 : 21506
                                break;
                            case 8:
                                li = (L = x) ? 20736 : 28449
                                break;
                            case 18:
                                m = k[D],
                                    D = void 0,
                                    N = oe,
                                    L = w,
                                    x = m,
                                    m = 0,
                                    y = 2 === x[5],
                                    li = y ? 2178 : 128
                                break;
                            case 19:
                                x = 0 === L.length,
                                    li = x ? 7714 : 16741
                                break;
                            default:
                                console.log('5-12');
                                break;
                        }
                        break;
                    case 13:
                        switch (mi) {
                            case 2:
                                x[14] = -1,
                                    x[2] = 0,
                                    x[11] = 0,
                                    x[12] = 0,
                                    li = 4133
                                break;
                            case 3:
                                m = E = [y + 64 * x],
                                    li = 26336
                                break;
                            default:
                                console.log('5-13');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 12:
                                B = x,
                                    D = D.concat(B),
                                    li = 1347
                                break;
                            default:
                                console.log('5-15');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 9:
                                x = M <= 3,
                                    li = (P = (bo = (fe = no === ri) * fe) >= (P = (Y = fe * (qe = !_e)) - (qe *= qe))) ? 8581 : 19777
                                break;
                            case 25:
                                ee = -E,
                                    li = 5729
                                break;
                            default:
                                console.log('5-16');
                                break;
                        }
                        break;
                    case 18:
                        switch (mi) {
                            case 16:
                                b = 0,
                                    A = !'g',
                                    li = (bo = (A *= A) > -28) ? 1091 : 10659
                                break;
                            default:
                                console.log('5-18');
                                break;
                        }
                        break;
                    case 19:
                        switch (mi) {
                            case 12:
                                C = void 0,
                                    li = (b = (j = 0 | (b = j)) < 128) ? 7457 : 16161
                                break;
                            default:
                                console.log('5-19');
                                break;
                        }
                        break;
                    case 20:
                        switch (mi) {
                            case 3:
                                $ = (oe = $)[0],
                                    li = $ ? 15584 : 11076
                                break;
                            case 7:
                                li = (L = x) ? 7970 : 16482
                                break;
                            case 21:
                                ee = void 0,
                                    li = (re = (ke = 0 | (re = E)) < 128) ? 26689 : 26244
                                break;
                            case 24:
                                x = J <= 1,
                                    li = 7813
                                break;
                            default:
                                console.log('5-20');
                                break;
                        }
                        break;
                }
                break;
            case 26:
                var Wi, Hi, Fi, Gi;
                ee = V = N = re + 1,
                    N = M ^ x[16],
                    V = M ^ x[6],
                    li = (J = 1 === N) ? 17475 : 19845;
                break;
        }
    };
    // console.log(S[0].toString());
    // console.log(oe);
    // return {
    //     'big_arr': ve,
    //     'enc_track': S
    // }

}

function get_be_1() {
    str_to_num = function(str, step) {
        var S = [];
        for (var i = 0; i < str.length;) {
            A = str.charCodeAt(i);
            f = 255 & A;
            S.push(f);
            i += step;
        };
        return S
    };

    var U = [1, 7, 77, 111, 122, 105, 108, 108, 97, 1, 1, 1];
    j = Math.floor(Math.random() * (1801167347 - 520262599 + 1)) + 520262599;
    S = [];
    A = 255 & (m = j >> 24);
    f = 255 & (m = j >> 16);
    m = j >> 8;
    b = 255 & m;
    m = 255 & j;
    S.push(A, f, b, m);
    U = U.concat(S);
    // U = U.concat([238, 219, 194, 201]);
    U.push(1);
    U.push(1, 1, 48); //定值
    U.push(15, 247, 36, 241); //定值，检测的10240-Infinity,-Infinity,-In

    //'48000_2_1_0_2_explicit_speakers' 由这个转换而来，写死
    U = U.concat([31, 52, 56, 48, 48, 48, 95, 50, 95, 49, 95, 48, 95, 50, 95, 101, 120, 112, 108, 105, 99, 105, 116, 95, 115, 112, 101, 97, 107, 101, 114, 115]);
    //-----------------------------------
    U = U.concat([1, 0, 1, 254, 1]);

    //'ANGLE_instanced_arrays;'检测的属性，可写死
    U = U.concat([14, 93, 241, 192]);
    //-----------------------------------
    U = U.concat([1, 0, 1, 47, 1, 0, 1]); //47存在疑点
    //检测的Win32,可写死
    U = U.concat([5, 87, 105, 110, 51, 50, 1]);
    //-----------------------------------
    //检测页面大小，存疑，先写死
    U = U.concat([0, 0, 128, 15, 0, 0, 0, 0, 0, 0, 184, 8, 255, 0, 40, 40, 255, 0, 255, 0, 255, 0, 1, 6, 1]); //与无感的差别之一
    // U = U.concat([0, 0, 128, 15, 212, 12, 0, 0, 212, 12, 212, 12, 212, 12, 184, 8, 150, 8, 40, 40, 150, 8, 150, 8, 150, 8, 1, 6, 1]);
    //-----------------------------------
    //检测了canvas，先写死
    U = U.concat([1, 0, 56, 1, 2, 39, 5, 26, 15, 194, 253, 57, 56, 1, 2, 1, 254, 1, 2, 1, 0, 1, 0, 1, 1, 1, 24, 24, 1, 0, 1]); //与无感的差别之一
    //-----------------------------------
    //‘Netscape’由他转换而来，写死
    U = U.concat([8, 78, 101, 116, 115, 99, 97, 112, 101]);
    //-----------------------------------

    U = U.concat([1, 0, 1, 0, 0, 0, 0, 1, 0, 1]); //先写死
    U = U.concat(ve[48]); //由时间戳生成的数组
    // U = U.concat([0, 0, 1, 140, 71, 245, 64, 37]);

    U = U.concat([1, 0, 1, 0, 1, 1, 1]);

    //R为[0,97,1],先写死,好像是定值
    U = U.concat([0, 100, 1]);
    //-----------------------------------

    U.push(1);
    //对轨迹的操作，先写死,s[0]

    U = U.concat(GD[0]);
    // U = U.concat([6, 0, 203, 6, 224, 1, 0, 132, 5, 0, 5, 1, 0, 0, 0, 16, 0, 5, 0, 20, 42, 0, 199, 12, 0, 4, 1, 0, 0, 0, 79, 0, 4, 0, 28, 247, 0, 0, 162, 6, 0, 3, 1, 0, 0, 0, 102, 0, 3]);
    // U = U.concat()
    //-----------------------------------
    U = U.concat([1, 255, 1]);
    //先写死,其中6 7 8 9 10 11 可以同时加1
    U = U.concat([4, 5, 1, 0, 4, 6, 1, 1, 4, 7, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 4, 3, 1, 0, 4, 8, 4, 9, 4, 10, 255, 1, 0, 1]);
    //-----------------------------------

    //写死，尾部需要处理，最后一位比上面的倒数第二位多1
    U = U.concat([0, 3, 248, 78, 1, 0, 1, 0, 1, 11]);
    //-----------------------------------
    // console.log(U.toString());

    var be = get_pre_12();
    var bo = true;
    var $ = void 0;
    var co = "toString";
    var uo = "";
    var ge = "Math";
    var yo = "Float32Array";
    var w = "PerformanceEntry";
    var Oo = 25;
    var k = U;
    var W = [];
    var S = 10;
    var ye = (f = be).slice(8, S);
    li = 12708;
    while (li != 'lxl') {
        var gi = li >> 5,
            Ci = 31 & gi,
            mi = 31 & gi >> 5;
        // console.log(li);
        switch (31 & li) {
            case 0:
                switch (Ci) {
                    case 2:
                        switch (mi) {
                            case 22:
                                li = B < x.length ? 21956 : 7618
                                break;
                            default:
                                console.log('0-22');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 18:
                                f = 2 * U,
                                    m = 2 + (j = 2 * U),
                                    j = k.slice(f, m),
                                    li = (m = 0 == (f = (x = (f = 4 * S) + (m = U % 4)) % 4)) ? 3522 : 8194
                                break;
                            default:
                                console.log('0-8');
                                break;
                        }
                        break;
                    case 10:
                        switch (mi) {
                            case 15:
                                W = $ = W,
                                    $ = void 0,
                                    f = 0,
                                    (k = (U = W).slice()).push(0, 0, 0),
                                    U = 0,
                                    S = 0,
                                    li = 13347
                                break;
                            default:
                                console.log('0-10');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 28:
                                $ = (U = $ = U).concat(W),
                                    W = $.length,
                                    U = void 0,
                                    li = (f = (W = 0 | (f = W)) < 16384) ? 18529 : 4771
                                break;
                            default:
                                console.log('0-16');
                                break;
                        }
                        break;
                    case 17:
                        switch (mi) {
                            case 7:
                                li = ee < y.length ? 514 : 17921
                                break;
                            default:
                                console.log('0-17');
                                break;
                        }
                        break;
                    case 23:
                        switch (mi) {
                            case 10:
                                ee++,
                                li = 7712
                                break;
                            case 17:
                                P = (P = (Y = w !== b) * Y) > -10,
                                    b = k[C = U + 3],
                                    f += C = 126 & b,
                                    li = P ? 13347 : 10370
                                break;
                            default:
                                console.log('0-23');
                                break;
                        }
                        break;
                    case 24:
                        switch (mi) {
                            case 20:
                                J = 255 & V,
                                    B.push(J),
                                    li = 29025
                                break;
                            default:
                                console.log('0-24');
                                break;
                        }
                        break;
                }
                break;
            case 1:
                switch (Ci) {
                    case 3:
                        switch (mi) {
                            case 18:
                                k = void 0,
                                    li = (S = (C = 0 | (S = W)) < 128) ? 26402 : 12355
                                break;
                            default:
                                console.log('1-3');
                                break;
                        }
                        break;
                    case 5:
                        switch (mi) {
                            case 26:
                                U = S = k,
                                    li = 15617
                                break;
                            default:
                                console.log('1-5');
                                break;
                        }
                        break;
                    case 7:
                        switch (mi) {
                            case 8:
                                li = ee < y.length ? 28356 : 25411
                                break;
                            default:
                                console.log('1-7');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 15:
                                U = (W = U).concat($);
                                be = be.concat(U);
                                W = [];
                                $ = void 0;
                                li = 'lxl'
                                break;
                            default:
                                console.log('1-8');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 3:
                                ye = "\u03f8\u03fe\u03f2\u03f7",
                                    C = "",
                                    b = 0,
                                    li = 11267
                                break;
                            default:
                                console.log('1-9');
                                break;
                        }
                        break;
                    case 11:
                        switch (mi) {
                            case 9:
                                li = 16676
                                break;
                            case 28:
                                ee++,
                                li = (fe = (P = (Y = U !== yo) * Y) > -255) ? 8417 : 20770
                                break;
                            default:
                                console.log('1-11');
                                break;
                        }
                        break;
                    case 12:
                        switch (mi) {
                            case 15:
                                li = U < C ? 18688 : 15680
                                break;
                            default:
                                console.log('1-12');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 17:
                                y = x = B,
                                    W = W.concat(y),
                                    li = 867
                                break;
                            default:
                                console.log('1-16');
                                break;
                        }
                        break;
                    case 17:
                        switch (mi) {
                            case 25:
                                f = void 0,
                                    x = j,
                                    y = [],
                                    E = 6,
                                    M = 3,
                                    ee = B = 246,
                                    B = 0,
                                    li = 22592
                                break;
                            default:
                                console.log('1-17');
                                break;
                        }
                        break;
                    case 19:
                        switch (mi) {
                            case 13:
                                C = 255 & (S = k >> 8),
                                    S = 255 & k,
                                    U.push(C, S),
                                    U = f = U,
                                    li = Y ? 29184 : 6595
                                break;
                            default:
                                console.log('1-19');
                                break;
                        }
                        break;
                    case 25:
                        switch (mi) {
                            case 11:
                                li = S ? 3108 : 13925
                                break;
                            default:
                                console.log('1-25');
                                break;
                        }
                        break;
                }
                break;
            case 2:
                switch (Ci) {
                    case 0:
                        switch (mi) {
                            case 8:
                                li = (m = 1 === f) ? 5506 : 13122
                                break;
                            default:
                                console.log('2-0');
                                break;
                        }
                        break;
                    case 3:
                        switch (mi) {
                            case 3:
                                C = Math[ye = C](U),
                                    U = 0,
                                    b = f = "mtW",
                                    li = 15745
                                break;
                            case 25:
                                C = 126 & k[U],
                                    f += C,
                                    b = k[C = U + 1],
                                    f += C = 126 & b,
                                    b = k[C = U + 2],
                                    f += C = 126 & b,
                                    li = 18144
                                break;
                            default:
                                console.log('2-3');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 17:
                                U++,
                                li = 15745
                                break;
                            case 21:
                                ye = f.split(uo),
                                    f = void 0,
                                    S = ye,
                                    C = (ye = 1469191576) % S.length,
                                    ye = S[C],
                                    S = f = S = ye % 4,
                                    f = U[ge],
                                    U = k.length / 2,
                                    li = 3361
                                break;
                            default:
                                console.log('2-8');
                                break;
                        }
                        break;
                    case 12:
                        switch (mi) {
                            case 5:
                                x = void 0,
                                    y = j,
                                    B = [],
                                    E = b,
                                    M = 0,
                                    ee = 0,
                                    li = 8417
                                break;
                            default:
                                console.log('2-12');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 3:
                                x = void 0,
                                    y = j,
                                    B = [],
                                    E = 4,
                                    M = 7,
                                    ee = 0,
                                    li = 6980
                                break;
                            case 7:
                                x = f = y,
                                    W = W.concat(x),
                                    li = 17666
                                break;
                            default:
                                console.log('2-14');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 0:
                                V = y[ee] - E,
                                    V = 255 & (J = (re = (J = 255 & V) >> (V = M)) + (V = J << (ke = 8 - V))),
                                    B.push(V),
                                    li = 10976
                                break;
                            default:
                                console.log('2-16');
                                break;
                        }
                        break;
                    case 26:
                        switch (mi) {
                            case 12:
                                li = (m = 2 === f) ? 17668 : 867
                                break;
                            default:
                                console.log('2-26');
                                break;
                        }
                        break;
                }
                break;
            case 3:
                switch (Ci) {
                    case 0:
                        switch (mi) {
                            case 11:
                                li = b < ye.length ? 12100 : 3170
                                break;
                            default:
                                console.log('3-0');
                                break;
                        }
                        break;
                    case 1:
                        switch (mi) {
                            case 13:
                                li = 12065
                                break;
                            default:
                                console.log('3-1');
                                break;
                        }
                        break;
                    case 2:
                        switch (mi) {
                            case 12:
                                x = 128 + (b = C % 128),
                                    b = 127 & (m = (j = C - b) / 128),
                                    (j = []).push(x, b),
                                    k = j,
                                    li = 26785
                                break;
                            case 23:
                                b++,
                                li = 11267
                                break;
                            default:
                                console.log('3-2');
                                break;
                        }
                        break;
                    case 21:
                        switch (mi) {
                            case 17:
                                ee++,
                                li = 6980
                                break;
                            default:
                                console.log('3-21');
                                break;
                        }
                        break;
                    case 26:
                        switch (mi) {
                            case 24:
                                y = x = B,
                                    W = W.concat(y),
                                    li = 13122
                                break;
                            default:
                                console.log('3-26');
                                break;
                        }
                        break;
                    case 27:
                        switch (mi) {
                            case 0:
                                li = (m = 3 === f) ? 26145 : 17666
                                break;
                            default:
                                console.log('3-27');
                                break;
                        }
                        break;
                }
                break;
            case 4:
                switch (Ci) {
                    case 1:
                        switch (mi) {
                            case 3:
                                U += 4,
                                    li = 13925
                                break;
                            default:
                                console.log('4-1');
                                break;
                        }
                        break;
                    case 7:
                        switch (mi) {
                            case 7:
                                B++,
                                li = 22592
                                break;
                            default:
                                console.log('4-7');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 17:
                                x = void 0,
                                    y = j,
                                    B = [],
                                    E = 7,
                                    M = 3,
                                    ee = 0,
                                    li = 7712
                                break;
                            default:
                                console.log('4-8');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 16:
                                U = 65535 & f,
                                    Y = (fe = (Oo <<= 0) * Oo) > (qe = (Oo = 454 | (P = P >= 18)) << 24),
                                    f = void 0,
                                    k = U,
                                    U = [],
                                    li = 13921
                                break;
                            default:
                                console.log('4-9');
                                break;
                        }
                        break;
                    case 13:
                        switch (mi) {
                            case 12:
                                f = ye[0] << 8,
                                    S = f | ye[1],
                                    f = S[co](),
                                    li = bo ? 21762 : 27072
                                break;
                            default:
                                console.log('4-13');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 21:
                                ee = (V = 240 & (J = (V = ee << E) ^ ee)) + (J = ee >> M),
                                    V = x[B] ^ ee,
                                    J = 255 & V,
                                    y.push(J),
                                    li = 7396
                                break;
                            default:
                                console.log('4-14');
                                break;
                        }
                        break;
                    case 22:
                        switch (mi) {
                            case 27:
                                V = y[ee],
                                    J = E.charCodeAt(M),
                                    V ^= J,
                                    M++,
                                    J = M >= E.length,
                                    li = J ? 5921 : 21248
                                break;
                            default:
                                console.log('4-22');
                                break;
                        }
                        break;
                    case 26:
                        switch (mi) {
                            case 6:
                                li = ee < y.length ? 20292 : 21316
                                break;
                            case 11:
                                j = 923 ^ ye.charCodeAt(b),
                                    C += String.fromCharCode(j),
                                    li = 23619
                                break;
                            case 19:
                                V = y[ee] - E,
                                    V = 255 & (J = (re = (J = 255 & V) >> (V = M)) + (V = J << (ke = 8 - V))),
                                    B.push(V),
                                    li = 18083
                                break;
                            case 20:
                                y = x = B,
                                    W = W.concat(y),
                                    li = 8194
                                break;
                            default:
                                console.log('4-26');
                                break;
                        }
                        break;
                }
                break;
            case 5:
                switch (Ci) {
                    case 19:
                        switch (mi) {
                            case 13:
                                S = 1,
                                    C = U < k.length,
                                    li = C ? 25698 : 9569
                                break;
                            default:
                                console.log('5-19');
                                break;
                        }
                        break;
                }
                break;

        }
    }
    return be

}

function get_pre_12() {
    var W = ve[93] + ve[24] + 888;
    var O = void 0;
    W = (be = W) - ($ = (de = 0 | ($ = be / (W = 4294967296))) * W);
    be = void 0;
    $ = de;
    var R = 255 & (T = $ >> 24);
    var pe = 255 & (T = $ >> 16);
    var oe = 255 & (T = $ >> 8);
    (de = []).push(R, pe, oe, T = 255 & $);
    be = de;
    $ = be;
    be = void 0;
    de = W;
    W = [];
    R = 255 & (T = de >> 24);
    pe = 255 & (T = de >> 16);
    oe = 255 & (T = de >> 8);
    T = 255 & de;
    W.push(R, pe, oe, T);
    W = be = W;
    be = $.concat(W);
    W = O = be;
    (O = []).push(0, 0);
    be = O;
    O = (O = []).concat(be);
    de = void 0;
    pe = 255 & (R = (T = $ = 227) >> 8);
    ($ = []).push(pe, R = 255 & T);
    $ = de = $;
    O = (O = O.concat($)).concat(be);
    $ = W.slice(6);
    O = O.concat($);
    $ = void 0;
    de = 71;
    W = (T = W).slice(6);
    T = W[0] + de;
    W[0] = 255 & T;
    T = W[1] + de;
    W[1] = 255 & T;
    W = $ = W;
    O = (O = O.concat(W)).concat(be);
    return O
}

function get_cs_be_3() {
    var be_3 = [1, 0, 1, 0, 1, 0, 1];
    //zh-CN 转换而来，写死
    be_3 = be_3.concat([5, 122, 104, 45, 67, 78]);
    //----------------------------------------
    be_3 = be_3.concat([1, 0, 1, 0, 0, 0, 1]);
    //此处为S[1]
    // be_3 = be_3.concat([92, 3, 65, 128, 7, 150, 2, 0, 7, 67, 70, 0, 10, 67, 70, 0, 6, 67, 68, 0, 6, 65, 66, 136, 0, 29, 65, 68, 0, 26, 65, 68, 4, 5, 65, 69, 0, 3, 65, 66, 0, 14, 0, 65, 0, 4, 0, 66, 5, 119, 69, 85, 0, 3, 65, 0, 0, 7, 0, 65, 0, 254, 25, 0, 1, 0, 9, 0, 7, 0, 8, 3, 7, 4, 8, 3, 9, 3, 8, 2, 9, 0, 10, 3, 6, 0, 4, 4, 7, 0, 8, 4, 7, 0, 8, 1, 4, 0, 9, 2, 4, 0, 7, 1, 4, 0, 10, 1, 1, 4, 11, 0, 2, 0, 171, 1, 1, 0, 3, 1, 0, 66, 0, 15, 0, 66, 0, 8, 1, 65, 0, 8, 0, 65, 0, 8, 0, 65, 0, 9, 0, 65, 0, 8, 0, 66, 0, 7, 0, 65, 0, 9, 0, 65, 0, 7, 0, 66, 0, 8, 0, 66, 0, 8, 0, 65, 0, 8, 0, 65, 0, 9, 0, 65, 0, 40, 0, 65, 0, 159, 3, 0, 1, 0, 10, 1, 6, 0, 6, 1, 6, 4, 9, 2, 7, 0, 8, 1, 7, 0, 8, 1, 5, 0, 8, 1, 6, 0, 10, 0, 4, 0, 5, 0, 4, 0, 9, 0, 3, 0, 8, 0, 1, 0, 7, 1, 3, 0, 8, 0, 3, 0, 8, 0, 2, 0, 11, 0, 3, 0, 6, 0, 3, 0, 8, 0, 3, 0, 7, 1, 2, 0, 8, 0, 2, 0, 8, 1, 2, 0, 8, 0, 2, 0, 9, 0, 3, 0, 8, 0, 3, 0, 8, 0, 1, 0, 7, 0, 1, 0, 11, 1, 2, 0, 6, 0, 1, 0, 7, 0, 1, 0, 9, 0, 1, 230, 0, 39, 65, 2, 0, 7, 0, 1, 0, 8, 65, 0, 0, 9, 0, 1, 0, 8, 0, 1, 0, 11, 0, 1, 0, 4, 0, 1, 0, 13, 65, 1, 0, 3, 0, 2, 0, 9, 65, 1, 0, 7, 0, 1, 0, 10, 0, 2, 0, 6, 65, 1, 0, 9, 0, 1, 0, 8, 0, 1, 0, 7, 65, 0, 0, 8, 0, 2, 0, 48, 0, 1]);
    be_3 = be_3.concat(GD[1]);
    //----------------------------------------
    O = void 0;
    de = [30, 4, 300, 6, 0, 'cn', 14, undefined, 1, 200, 1, 1, 30, 4];
    var T = ($ = ve)[3];
    var P = 1;
    li = T ? 705 : 16899;
    while (li != 'lxl') {
        // console.log(li);
        var gi = li >> 5,
            Ci = 31 & gi,
            mi = 31 & gi >> 5;
        switch (31 & li) {
            case 0:
                switch (Ci) {
                    case 0:
                        switch (mi) {
                            case 2:
                                m = C = x = B + 1,
                                    z.push(j),
                                    j = void 0,
                                    li = (x = (C = 0 | (x = C = b - k)) < 16384) ? 20739 : 9954
                                break;
                            default:
                                console.log('0-0');
                                break;
                        }
                        break;
                    case 1:
                        switch (mi) {
                            case 17:
                                y = M = [E],
                                    li = 15968
                                break;
                            default:
                                console.log('0-1');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 21:
                                J = 128 + (M = E % 128),
                                    M = 127 & (V = (ee = E - M) / 128),
                                    (ee = []).push(J, M),
                                    y = ee,
                                    li = 15968
                                break;
                            default:
                                console.log('0-14');
                                break;
                        }
                        break;
                    case 18:
                        switch (mi) {
                            case 23:
                                C = x = [m],
                                    li = 7203
                                break;
                            default:
                                console.log('0-18');
                                break;
                        }
                        break;
                    case 19:
                        switch (mi) {
                            case 15:
                                j = B = y,
                                    li = 26403
                                break;
                            case 24:
                                li = ($ = O) ? 27361 : 14978
                                break;
                            case 21:
                                C = T[f],
                                    b = C[1],
                                    j = $[48],
                                    x = j[m = b % 7],
                                    j = x ^ C[2],
                                    m = x ^ C[0],
                                    C = void 0,
                                    x = $,
                                    y = m,
                                    li = 26692
                                break;
                            default:
                                console.log('0-19');
                                break;
                        }
                        break;
                    case 25:
                        switch (mi) {
                            case 27:
                                B = 127 & C,
                                    li = (C >>= 7) ? 3397 : 22561
                                break;
                            default:
                                console.log('0-25');
                                break;
                        }
                        break;
                }
                break;
            case 1:
                switch (Ci) {
                    case 1:
                        switch (mi) {
                            case 22:
                                y.push(B),
                                    li = C ? 19940 : 11874
                                break;
                            default:
                                console.log('1-1');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 22:
                                z = [],
                                    k = 0,
                                    S = 0,
                                    li = 11522
                                break;
                            default:
                                console.log('1-9');
                                break;
                        }
                        break;
                    case 20:
                        switch (mi) {
                            case 20:
                                li = (E = -1 === (B = E)) ? 13666 : 2048
                                break;
                            default:
                                console.log('1-20');
                                break;
                        }
                        break;
                    case 22:
                        switch (mi) {
                            case 0:
                                z = de[3],
                                    f = T.length - z,
                                    li = (z = f < 0) ? 28292 : 22817
                                break;
                            default:
                                console.log('1-22');
                                break;
                        }
                        break;
                }
                break;
            case 2:
                switch (Ci) {
                    case 8:
                        switch (mi) {
                            case 11:
                                li = f < T.length ? 22112 : 14405
                                break;
                            default:
                                console.log('2-8');
                                break;
                        }
                        break;
                    case 17:
                        switch (mi) {
                            case 15:
                                B = V.indexOf(ee),
                                    E = B,
                                    li = 21121
                                break;
                            default:
                                console.log('2-17');
                                break;
                        }
                        break;
                    case 19:
                        switch (mi) {
                            case 11:
                                li = 11524
                                break;
                            default:
                                console.log('2-19');
                                break;
                        }
                        break;
                    case 23:
                        switch (mi) {
                            case 9:
                                y = [],
                                    li = 28448
                                break;
                            default:
                                console.log('2-23');
                                break;
                        }
                        break;
                }
                break;
            case 3:
                switch (Ci) {
                    case 1:
                        switch (mi) {
                            case 7:
                                j = C,
                                    z = z.concat(j),
                                    k = b,
                                    S++,
                                    li = 3492
                                break;
                            default:
                                console.log('3-1');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 20:
                                y = void 0,
                                    li = (B = (E = 0 | (B = C)) < 128) ? 17440 : 21952
                                break;
                            default:
                                console.log('3-8');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 16:
                                O = z = [0],
                                    li = 25184
                                break;
                            case 27:
                                f = C = [S],
                                    li = 8708
                                break;
                            default:
                                console.log('3-16');
                                break;
                        }
                        break;
                    case 25:
                        switch (mi) {
                            case 25:
                                C = j,
                                    z = z.concat(C),
                                    C = void 0,
                                    li = (j = (m = 0 | (j = m)) < 128) ? 24128 : 24869
                                break;
                            default:
                                console.log('3-25');
                                break;
                        }
                        break;
                }
                break;
            case 4:
                switch (Ci) {
                    case 2:
                        switch (mi) {
                            case 26:
                                B = x[18],
                                    E = void 0,
                                    M = 0,
                                    ee = y,
                                    li = (V = B).indexOf ? 15906 : 28482
                                break;
                            default:
                                console.log('4-2');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 11:
                                j = y,
                                    li = 26403
                                break;
                            default:
                                console.log('4-8');
                                break;
                        }
                        break;
                    case 13:
                        switch (mi) {
                            case 3:
                                f++;
                                li = (fe = (A = (P = 2 <= P) * P) > -17) ? 11522 : 21345
                                break;
                            default:
                                console.log('4-13');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 19:
                                li = 28448
                                break;
                            default:
                                console.log('4-15');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 8:
                                z = (k = f).concat(z);
                                // console.log(z.toString());
                                li = 'lxl'
                                break;
                            default:
                                console.log('4-16');
                                break;
                        }
                        break;
                    case 20:
                        switch (mi) {
                            case 27:
                                f = 0,
                                    li = 22817
                                break;
                            default:
                                console.log('4-20');
                                break;
                        }
                        break;
                }
                break;
            case 5:
                switch (Ci) {
                    case 2:
                        switch (mi) {
                            case 14:
                                f = void 0,
                                    li = (k = (S = 0 | (k = S)) < 128) ? 28163 : 5634
                                break;
                            default:
                                console.log('5-2');
                                break;
                        }
                        break;
                    case 10:
                        switch (mi) {
                            case 3:
                                B |= 128,
                                    li = 22561
                                break;
                            default:
                                console.log('5-10');
                                break;
                        }
                        break;
                }
                break;
        }
    }
    be_3 = be_3.concat([1, 1, 1, 47, 1]);
    z[z.length - 1] += 1;
    be_3 = be_3.concat(z);
    be_3 = be_3.concat([1, 14, 3, 0, 1, 0, 1, 0, 1, 2, 0]); //写死
    //此处过后大数组第18位要加一个
    return be_3
}

function get_0000(k) {
    var b = [
        "\u0000",
        "\u0001",
        "\u0002",
        "\u0003",
        "\u0004",
        "\u0005",
        "\u0006",
        "\u0007",
        "\b",
        "\t",
        "\n",
        "\u000b",
        "\f",
        "\r",
        "\u000e",
        "\u000f",
        "\u0010",
        "\u0011",
        "\u0012",
        "\u0013",
        "\u0014",
        "\u0015",
        "\u0016",
        "\u0017",
        "\u0018",
        "\u0019",
        "\u001a",
        "\u001b",
        "\u001c",
        "\u001d",
        "\u001e",
        "\u001f",
        " ",
        "!",
        "\"",
        "#",
        "$",
        "%",
        "&",
        "'",
        "(",
        ")",
        "*",
        "+",
        ",",
        "-",
        ".",
        "/",
        "0",
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        ":",
        ";",
        "<",
        "=",
        ">",
        "?",
        "@",
        "A",
        "B",
        "C",
        "D",
        "E",
        "F",
        "G",
        "H",
        "I",
        "J",
        "K",
        "L",
        "M",
        "N",
        "O",
        "P",
        "Q",
        "R",
        "S",
        "T",
        "U",
        "V",
        "W",
        "X",
        "Y",
        "Z",
        "[",
        "\\",
        "]",
        "^",
        "_",
        "`",
        "a",
        "b",
        "c",
        "d",
        "e",
        "f",
        "g",
        "h",
        "i",
        "j",
        "k",
        "l",
        "m",
        "n",
        "o",
        "p",
        "q",
        "r",
        "s",
        "t",
        "u",
        "v",
        "w",
        "x",
        "y",
        "z",
        "{",
        "|",
        "}",
        "~",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        " ",
        "¡",
        "¢",
        "£",
        "¤",
        "¥",
        "¦",
        "§",
        "¨",
        "©",
        "ª",
        "«",
        "¬",
        "­",
        "®",
        "¯",
        "°",
        "±",
        "²",
        "³",
        "´",
        "µ",
        "¶",
        "·",
        "¸",
        "¹",
        "º",
        "»",
        "¼",
        "½",
        "¾",
        "¿",
        "À",
        "Á",
        "Â",
        "Ã",
        "Ä",
        "Å",
        "Æ",
        "Ç",
        "È",
        "É",
        "Ê",
        "Ë",
        "Ì",
        "Í",
        "Î",
        "Ï",
        "Ð",
        "Ñ",
        "Ò",
        "Ó",
        "Ô",
        "Õ",
        "Ö",
        "×",
        "Ø",
        "Ù",
        "Ú",
        "Û",
        "Ü",
        "Ý",
        "Þ",
        "ß",
        "à",
        "á",
        "â",
        "ã",
        "ä",
        "å",
        "æ",
        "ç",
        "è",
        "é",
        "ê",
        "ë",
        "ì",
        "í",
        "î",
        "ï",
        "ð",
        "ñ",
        "ò",
        "ó",
        "ô",
        "õ",
        "ö",
        "÷",
        "ø",
        "ù",
        "ú",
        "û",
        "ü",
        "ý",
        "þ",
        "ÿ"
    ];
    R = "";
    be = 3;
    F = 1;
    M = 0;
    // q = 2;
    // P = '              ';
    P = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00';
    D = ' \x00\x01\x02\x03\x04\x05\x06\x07\b\t\n\v\f\r\x0E\x0F\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1A\x1B\x1C\x1D\x1E\x1F !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\x7F\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89\x8A\x8B\x8C\x8D\x8E\x8F\x90\x91\x92\x93\x94\x95\x96\x97\x98\x99\x9A\x9B\x9C\x9D\x9E\x9F ¡¢£¤¥¦§¨©ª«¬­®¯°±²³´µ¶·¸¹º»¼½¾¿ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖ×ØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõö÷øùúûüýþÿ ';
    for (let J = 0; J < k.length; J++) {
        G = 255 & k[J];
        q = 0;
        Se = 0;
        q = D.indexOf(b[G], 1);
        // console.log(q, G);
        //step 1 
        if (G != 255) {
            Ce = b[G + 1];
            be = D.indexOf(Ce, 1);
        };
        if (G == 255) {
            be = D.length - 1;
        }
        //step 2

        Se = be;
        be = (G = F - M) / D.length;
        F = M + (G = be * Se);
        M += G = be * q;
        G = D['substr'](0, Se);
        q = G + P;
        // console.log(q.toString());

        G = D['substr'](Se);
        D = q + G;
        G = F['toString'](2);
        q = G['substr'](2);
        //step3

        G = M["toString"](2);
        Se = G["substr"](2);
        G = q.split('');
        be = Se.split('');
        Se = 0;
        //step 4 
        // aa = (function anonymous() {
        //     var a = arguments;
        //     return this[a[1]] !== a[0]
        // })

        findFirstDiffPos = function(a, b) {
            var shorterLength = Math.min(a.length, b.length);

            for (var i = 0; i < shorterLength; i++)

                if (a[i] !== b[i]) return i;


                // if (a.length !== b.length) return shorterLength;
            if (a == b) return -1;

            return -1;
        }
        j = "findIndex";
        Se = findFirstDiffPos(G, be);
        //step5
        // mm = q;
        // Se = ???
        G = q["substr"](0, Se);
        // console.log(G);
        R += G;
        G = Math.pow(2, Se);
        F = (q = F * G) - (Se = 0 | q);
        M = (q = M * G) - Se;


        //step6
        // q = get_q()

        // console.log(R);
        // console.log(q);
    }

    O = M["toString"](2);
    M = O["substr"](2);
    O = M["replace"]({}, '');
    R += O;
    return R
}

function get_T(R, k_length) {
    var T = [];
    // T = [];
    for (; R.length > 0;) {
        if (R.length > 7) {
            O = R["substr"](0, 8);
            M = parseInt(O, 2);
            // console.log(M);
            T.push(M);
            R = R["substr"](8);
        } else {

            break;
        }
        // if (R.length < 8) {
        //     break;
        // }

    }

    O = "0";
    O += "000";
    R = (O = R + (M = O += "0000"))["substr"](0, 8);
    O = parseInt(R, 2);
    T.push(O);

    // console.log(T);
    oe = k_length;
    G = 128 + (P = oe % 128);
    P = 127 & (J = (F = oe - P) / 128);
    (F = []).push(G, P);
    b = F;
    F = F.concat(T);
    return F
}

function get_be_3(gd_3) {
    var T = []; //这个T是be_+be_2
    var oi = -1;
    var qe = -134217728;
    var co = "toString";
    var uo = "";
    var eo = "_0x48b3";
    var Fo = "HEAD";
    var ze = "cdc_adoQpoasnfa76pfcZLmcfl_Symbol";

    z = gd_3;
    W = [];
    li = 22336;
    while (li != 'lxl') {
        // console.log(li);
        var gi = li >> 5,
            Ci = 31 & gi,
            mi = 31 & gi >> 5;
        switch (31 & li) {
            case 0:
                switch (Ci) {
                    case 3:
                        switch (mi) {
                            case 26:
                                W = O = W;
                                O = void 0;
                                T = 0;
                                (z = ($ = W).slice()).push(0, 0, 0);
                                $ = 0;
                                f = 0;
                                li = 18500
                                break;
                            default:
                                console.log('0-3');
                                break;
                        }
                        break;
                    case 7:
                        switch (mi) {
                            case 3:
                                m = j = L,
                                    W = W.concat(m),
                                    li = 17123
                                break;
                            default:
                                console.log('0-7');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 12:
                                z = S = [k],
                                    li = 10754
                                break;
                            default:
                                console.log('0-8');
                                break;
                        }
                        break;
                    case 13:
                        switch (mi) {
                            case 8:
                                T = void 0,
                                    j = S,
                                    m = [],
                                    L = 92,
                                    B = 8,
                                    E = 0,
                                    li = 23204
                                break;
                            default:
                                console.log('0-13');
                                break;
                        }
                        break;
                    case 17:
                        switch (mi) {
                            case 1:
                                E++,
                                li = 23204
                                break;
                            default:
                                console.log('0-17');
                                break;
                        }
                        break;
                    case 26:
                        switch (mi) {
                            case 21:
                                f = 10,
                                    Y = (Oo = (A = !oi) * A) >= (A = (P = A * (qe <<= 21)) - (A = qe * qe)),
                                    k = T.slice(8, f),
                                    T = k[0] << 8,
                                    li = 18789
                                break;
                            default:
                                console.log('0-26');
                                break;
                        }
                        break;
                    case 28:
                        switch (mi) {
                            case 1:
                                li = 18724
                                break;
                            default:
                                console.log('0-28');
                                break;
                        }
                        break;
                }
                break;
            case 1:
                switch (Ci) {
                    case 1:
                        switch (mi) {
                            case 28:
                                z = void 0,
                                    li = (f = (k = 0 | (f = W)) < 128) ? 12544 : 17154
                                break;
                            default:
                                console.log('1-1');
                                break;
                        }
                        break;
                    case 5:
                        switch (mi) {
                            case 8:
                                M++,
                                li = 20868
                                break;
                            default:
                                console.log('1-5');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 22:
                                j = T = m;
                                W = W.concat(j);
                                li = 14083
                                break;
                            default:
                                console.log('1-15');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 3:
                                j = void 0,
                                    m = S,
                                    L = [],
                                    B = 2,
                                    E = 3,
                                    M = 0,
                                    li = 8961
                                break;
                            default:
                                console.log('1-16');
                                break;
                        }
                        break;
                    case 23:
                        switch (mi) {
                            case 27:
                                $ += 4,
                                    li = 24674
                                break;
                            default:
                                console.log('1-23');
                                break;
                        }
                        break;
                    case 24:
                        switch (mi) {
                            case 8:
                                li = M < m.length ? 5316 : 16869
                                break;
                            case 18:
                                li = 19 == mi ? (J = M) ? 21089 : 14082 : mi < 19 ? (A = bo >= A) ? 18500 : 4449 : (R = T) ? 484 : 22978
                                break;
                            default:
                                console.log('1-24');
                                break;
                        }
                        break;
                    case 25:
                        switch (mi) {
                            case 7:
                                j = void 0,
                                    m = S,
                                    L = [],
                                    E = B = 96735,
                                    B = 0,
                                    li = 18851
                                break;
                            default:
                                console.log('1-25');
                                break;
                        }
                        break;
                }
                break;
            case 2:
                switch (Ci) {
                    case 3:
                        switch (mi) {
                            case 24:
                                f = 1,
                                    k = $ < z.length,
                                    li = k ? 12994 : 1920
                                break;
                            default:
                                console.log('2-3');
                                break;
                        }
                        break;
                    case 6:
                        switch (mi) {
                            case 20:
                                li = f ? 28385 : 24674
                                break;
                            default:
                                console.log('2-6');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 10:
                                $ = f = z,
                                    li = 23170
                                break;
                            default:
                                console.log('2-16');
                                break;
                        }
                        break;
                    case 20:
                        switch (mi) {
                            case 22:
                                $ = (W = $).concat(O),
                                    W = [],
                                    O = void 0;
                                li = 'lxl'
                                break;
                            default:
                                console.log('2-20');
                                break;
                        }
                        break;
                    case 22:
                        switch (mi) {
                            case 12:
                                k = 226 & z[$],
                                    T += k,
                                    S = z[k = $ + 1],
                                    T += k = 226 & S,
                                    S = z[k = $ + 2],
                                    T += k = 226 & S,
                                    li = 25315
                                break;
                            default:
                                console.log('2-22');
                                break;
                        }
                        break;
                    case 24:
                        switch (mi) {
                            case 16:
                                m = 128 + (S = k % 128),
                                    S = 127 & (j = (C = k - S) / 128),
                                    (C = []).push(m, S),
                                    z = C,
                                    li = 10754
                                break;
                            default:
                                console.log('2-24');
                                break;
                        }
                        break;
                    case 25:
                        switch (mi) {
                            case 16:
                                li = $ < k ? 15813 : 26720
                                break;
                            default:
                                console.log('2-25');
                                break;
                        }
                        break;
                }
                break;
            case 3:
                switch (Ci) {
                    case 3:
                        switch (mi) {
                            case 4:
                                M = m[B],
                                    E = V = M ^ E,
                                    M = 255 & V,
                                    L.push(M),
                                    li = 4899
                                break;
                            default:
                                console.log('3-3');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 3:
                                M++,
                                li = 8961
                                break;
                            default:
                                console.log('3-9');
                                break;
                        }
                        break;
                    case 13:
                        switch (mi) {
                            case 18:
                                li = B < m.length ? 4195 : 24868
                                break;
                            case 23:
                                O = ($ = O).concat(W),
                                    W = O.length,
                                    $ = void 0,
                                    li = (T = (W = 0 | (T = W)) < 16384) ? 28705 : 6818
                                break;
                            default:
                                console.log('3-13');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 19:
                                M = L ^ j[E],
                                    M = (V = M >> B) ^ j[E],
                                    V = 255 & M,
                                    m.push(V),
                                    li = 1568
                                break;
                            default:
                                console.log('3-14');
                                break;
                        }
                        break;
                    case 23:
                        switch (mi) {
                            case 16:
                                li = (C = 3 === T) ? 8608 : 14083
                                break;
                            case 24:
                                S = z[k = $ + 3],
                                    bo = (fe = eo !== ze) * fe,
                                    T += k = 226 & S,
                                    A = (fe *= A = !Fo) - (Y = A * A),
                                    li = 19201
                                break;
                            default:
                                console.log('3-23');
                                break;
                        }
                        break;
                    case 24:
                        switch (mi) {
                            case 13:
                                $++,
                                li = 17186
                                break;
                            default:
                                console.log('3-24');
                                break;
                        }
                        break;
                    case 25:
                        switch (mi) {
                            case 4:
                                B++,
                                li = 18851
                                break;
                            default:
                                console.log('3-25');
                                break;
                        }
                        break;
                }
                break;
            case 4:
                switch (Ci) {
                    case 2:
                        switch (mi) {
                            case 18:
                                li = 20674
                                break;
                            default:
                                console.log('4-2');
                                break;
                        }
                        break;
                    case 6:
                        switch (mi) {
                            case 5:
                                V = m[M] - B,
                                    V = 255 & (J = (re = (J = 255 & V) >> (V = E)) + (V = J << (ke = 8 - V))),
                                    L.push(V),
                                    li = 3363
                                break;
                            default:
                                console.log('4-6');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 24:
                                f = T,
                                    T = Math,
                                    $ = z.length / 2,
                                    k = Math['ceil']($),
                                    $ = 0,
                                    li = 17186
                                break;
                            default:
                                console.log('4-8');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 18:
                                $ = 65535 & T,
                                    T = void 0,
                                    k = 255 & (f = (z = $) >> 8),
                                    ($ = []).push(k, f = 255 & z),
                                    O = $ = T = $,
                                    li = 23971
                                break;
                            case 24:
                                m = j = L,
                                    W = W.concat(m),
                                    li = 27749
                                break;
                            default:
                                console.log('4-9');
                                break;
                        }
                        break;
                    case 12:
                        switch (mi) {
                            case 20:
                                li = M < m.length ? 12804 : 3296
                                break;
                            default:
                                console.log('4-12');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 13:
                                li = (C = 2 === T) ? 197 : 17123
                                break;
                            default:
                                console.log('4-14');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 12:
                                V = m[M],
                                    li = (J = (V += J = B - 1) >= E) ? 133 : 11653
                                break;
                            default:
                                console.log('4-16');
                                break;
                        }
                        break;
                    case 21:
                        switch (mi) {
                            case 22:
                                li = E < j.length ? 19907 : 23009
                                break;
                            default:
                                console.log('4-21');
                                break;
                        }
                        break;
                }
                break;
            case 5:
                switch (Ci) {
                    case 3:
                        switch (mi) {
                            case 27:
                                li = (C = 1 === T) ? 3585 : 13764
                                break;
                            default:
                                console.log('5-3');
                                break;
                        }
                        break;
                    case 4:
                        switch (mi) {
                            case 0:
                                V %= E,
                                    li = 11653
                                break;
                            default:
                                console.log('5-4');
                                break;
                        }
                        break;
                    case 6:
                        switch (mi) {
                            case 0:
                                j = void 0,
                                    m = S,
                                    L = [],
                                    B = 263,
                                    E = 256,
                                    M = 0,
                                    li = 20868
                                break;
                            default:
                                console.log('5-6');
                                break;
                        }
                        break;
                    case 11:
                        switch (mi) {
                            case 18:
                                f = T | k[1],
                                    T = f[co](),
                                    k = T.split(uo),
                                    T = void 0,
                                    f = k,
                                    S = (k = 436559119) % f.length,
                                    k = f[S],
                                    T = f = k % 4,
                                    li = Y ? 24836 : 9538
                                break;
                            default:
                                console.log('5-11');
                                break;
                        }
                        break;
                    case 12:
                        switch (mi) {
                            case 11:
                                L.push(V),
                                    li = 8353
                                break;
                            default:
                                console.log('5-12');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 15:
                                T = 2 * $,
                                    C = 2 + (S = 2 * $),
                                    S = z.slice(T, C),
                                    li = (C = 0 == (T = (j = (T = 4 * f) + (C = $ % 4)) % 4)) ? 7969 : 27749
                                break;
                            default:
                                console.log('5-14');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 16:
                                m = j = L;
                                W = W.concat(m);
                                li = 13764
                                break;
                            default:
                                console.log('5-15');
                                break;
                        }
                        break;
                }
                break;
        }
    }
    return $
}

function get_be_4(pre_url, t1, t2) {
    // ve = ve_2;
    //先写死
    var be_4 = [1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 1, 247, 15, 254, 230, 127, 1, 0, 1, 0, 1];
    // var mm = [Math.floor(Math.random() * (17000 - 15000 + 1)) + 15000, Math.floor(Math.random() * (35000 - 29000 + 1)) + 29000];
    var mm = [t1, t2];
    var z = [mm.length];
    for (var i = 0; i < mm.length; i++) {
        S = mm[i];
        if (!(mm[i] < 16384)) {
            while (S) {
                L = 127 & S;
                S >>= 7;
                if (!S) {
                    // m.push(L);
                    z.push(L);
                    break;
                }
                L |= 128;
                // m.push(L);
                z.push(L);
            }
        } else {
            B = mm[i];
            V = (M = B - (E = B % 128)) / 128;
            (M = []).push(J = E + 128, E = 127 & V);
            z = z.concat(M);
        }
    }
    // be_4 = be_4.concat([1, 146, 233, 10, 1, 254, 1]); //前几位位随机，先写死
    be_4 = be_4.concat(z);
    //------------------------------------------------
    be_4 = be_4.concat([1, 0, 1, 0]);
    //umidtoken转换而来
    generateRandomArray = function(length, min, max) {
        var arr = [51, 71, 50];

        for (var i = 0; i < length; i++) {
            var randomValue = Math.floor(Math.random() * (max - min + 1)) + min;
            arr.push(randomValue);
        }

        return arr;
    }

    // var randomArray = generateRandomArray(49, 48, 70);
    // console.log(randomArray);
    str_to_num = function(str, step) {
        var S = [];
        for (var i = 0; i < str.length;) {
            A = str.charCodeAt(i);
            f = 255 & A;
            S.push(f);
            i += step;
        };
        return S
    };

    // be_4 = be_4.concat([51, 71, 50, 66, 49, 54, 65, 68, 52, 48, 57, 53, 69, 70, 70, 56, 65, 50, 66, 55, 53, 50, 67, 48, 51, 65, 56, 65, 51, 57, 56, 55, 67, 55, 54, 66, 53, 68, 51, 49, 53, 65, 53, 49, 55, 53, 48, 65, 68, 55, 69, 60]);
    be_4 = be_4.concat(generateRandomArray(49, 47, 70));
    // be_4.push(51);
    // be_4 = be_4.concat(str_to_num('GDC06C2779A66DA7FBF1B0CF4D1CA9A070D6F5C70DB033BEB4C', 1));
    //------------------------------------------------
    be_4 = be_4.concat([1, 0, 1, 1, 1, 0, 1]);
    //先写死
    be_4 = be_4.concat([133, 126, 73, 16]); //先写死 随机截取代码操作
    //------------------------------------------------
    // be_4 = be_4.concat([0, 1, 14, 197, 11, 5, 155, 2, 5, 11, 5, 6, 5, 74, 6, 95, 6, 24, 6, 112, 6, 93, 6, 30, 6, 162, 1, 6, 102, 6, 121, 6, 9, 6, 1, 0, 1, 1]);  //与无感差异点
    // be_4 = be_4.concat([1, 0, 1, 0, 1, 0, 1]); //先写死
    be_4 = be_4.concat([1, 0, 1, 1, 160, 1, 3, 1, 0, 1])
        // be_4 = be_4.concat([0, 1, 0, 1, 0, 1]);
    be_4 = be_4.concat(z);
    be_4 = be_4.concat([1, 0, 0, 0, 0, 1]);
    be_4 = be_4.concat([4, 5, 1, 0, 4, 6, 1, 1, 4, 7, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 4, 3, 1, 0, 4, 8, 4, 9, 4, 10, 255, 1]); //与be_1要保持一致
    be_4 = be_4.concat([0, 100, 1, 1]);
    str_1 = '    at HTMLDocument.s (https://g.alicdn.com/AWSC/nc/1.94.0/nc.js:1:36209)';
    // str_2 = '    at https://g.alicdn.com/AWSC/nc/1.94.0/nc.js:1:47639';
    var gd_4 = str_to_num(str_1, 1);
    gd_4 = [gd_4.length].concat(gd_4);
    gd_4 = gd_4.concat(gd_4);
    //35由#转变而来
    gd_4.push(1, 1, 35);
    be_4 = be_4.concat(gd_4);
    be_4.push(1);
    var get_nounce = function() {
        var Be = Math.random();
        var Ie = Be["toString"](36)
        Be = Ie["substring"](2);
        Ie = Math.random();
        Te = Ie["toString"](36);
        Ie = Te["substring"](2);
        var arr_6 = Be + Ie;
        // console.log(arr_64);
        return arr_6
    };
    var a = [
        'Chrome',
        '120.0.0.0',
        '',
        // 'nc_1__scale_text',
        'nc_1_n1z',
        '0.01+running',
        '0',
        '[object Window]',
        '0|0',
        '1|1|1|1|1|1|1|1|1|1|1',
        'noid',
        // 'nx0ci496gw99o0f6bopl6',
        get_nounce(),
        'Google Inc. (NVIDIA)',
        'ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 (0x00001E89) Direct3D11 vs_5_0 ps_5_0, D3D11)',
        // 'https://login.taobao.com//newlogin/login.do/_____tmd_____/punish?x5secdata=xd670762b406ebd2c9afe5a1607eaaeca8c0e0ef17a804759c170',
        pre_url,
        'i=10596));break;case 9:void(14==mi?(F=te[_],li=F?4320:16737):mi<14?6==mi?',
    ];
    var Re = [0];
    for (var i = 0; i < a.length; i++) {
        Re = Re.concat(str_to_num(a[i], 1));
        Re.push(0);
    };

    je = 128 + (_e = Re.length % 128);
    _e = 127 & (ue = (L = Re.length - _e) / 128);
    (L = []).push(je, _e);
    Re = L.concat(Re);
    be_4 = be_4.concat(Re);
    W = be_4;
    var be = [];
    // var ve = [];
    var Q = void 0;
    // var T = ve; //97位大数组
    var T = [];

    function anonymous() {
        var a = arguments;
        return this[a[1]] !== a[0]
    }

    var ve = 30;
    var oe = (R = W).slice();
    var K = "substr";
    var z = "toString";
    var G = "findIndex";
    var co = "toString";
    var uo = "";
    var he = "";
    var Ie = "replace";
    var fe = 268435456;
    var hi = "userAgent";
    var vo = " ";
    var de = "00000000";
    var Oo = false;
    var y = '\x00\x01\x02\x03\x04\x05\x06\x07\b\t\n\v\f\r\x0E\x0F\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1A\x1B\x1C\x1D\x1E\x1F !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\x7F\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89\x8A\x8B\x8C\x8D\x8E\x8F\x90\x91\x92\x93\x94\x95\x96\x97\x98\x99\x9A\x9B\x9C\x9D\x9E\x9F ¡¢£¤¥¦§¨©ª«¬­®¯°±²³´µ¶·¸¹º»¼½¾¿ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖ×ØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõö÷øùúûüýþÿ';
    var d = [
        "\u0000",
        "\u0001",
        "\u0002",
        "\u0003",
        "\u0004",
        "\u0005",
        "\u0006",
        "\u0007",
        "\b",
        "\t",
        "\n",
        "\u000b",
        "\f",
        "\r",
        "\u000e",
        "\u000f",
        "\u0010",
        "\u0011",
        "\u0012",
        "\u0013",
        "\u0014",
        "\u0015",
        "\u0016",
        "\u0017",
        "\u0018",
        "\u0019",
        "\u001a",
        "\u001b",
        "\u001c",
        "\u001d",
        "\u001e",
        "\u001f",
        " ",
        "!",
        "\"",
        "#",
        "$",
        "%",
        "&",
        "'",
        "(",
        ")",
        "*",
        "+",
        ",",
        "-",
        ".",
        "/",
        "0",
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        ":",
        ";",
        "<",
        "=",
        ">",
        "?",
        "@",
        "A",
        "B",
        "C",
        "D",
        "E",
        "F",
        "G",
        "H",
        "I",
        "J",
        "K",
        "L",
        "M",
        "N",
        "O",
        "P",
        "Q",
        "R",
        "S",
        "T",
        "U",
        "V",
        "W",
        "X",
        "Y",
        "Z",
        "[",
        "\\",
        "]",
        "^",
        "_",
        "`",
        "a",
        "b",
        "c",
        "d",
        "e",
        "f",
        "g",
        "h",
        "i",
        "j",
        "k",
        "l",
        "m",
        "n",
        "o",
        "p",
        "q",
        "r",
        "s",
        "t",
        "u",
        "v",
        "w",
        "x",
        "y",
        "z",
        "{",
        "|",
        "}",
        "~",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        " ",
        "¡",
        "¢",
        "£",
        "¤",
        "¥",
        "¦",
        "§",
        "¨",
        "©",
        "ª",
        "«",
        "¬",
        "­",
        "®",
        "¯",
        "°",
        "±",
        "²",
        "³",
        "´",
        "µ",
        "¶",
        "·",
        "¸",
        "¹",
        "º",
        "»",
        "¼",
        "½",
        "¾",
        "¿",
        "À",
        "Á",
        "Â",
        "Ã",
        "Ä",
        "Å",
        "Æ",
        "Ç",
        "È",
        "É",
        "Ê",
        "Ë",
        "Ì",
        "Í",
        "Î",
        "Ï",
        "Ð",
        "Ñ",
        "Ò",
        "Ó",
        "Ô",
        "Õ",
        "Ö",
        "×",
        "Ø",
        "Ù",
        "Ú",
        "Û",
        "Ü",
        "Ý",
        "Þ",
        "ß",
        "à",
        "á",
        "â",
        "ã",
        "ä",
        "å",
        "æ",
        "ç",
        "è",
        "é",
        "ê",
        "ë",
        "ì",
        "í",
        "î",
        "ï",
        "ð",
        "ñ",
        "ò",
        "ó",
        "ô",
        "õ",
        "ö",
        "÷",
        "ø",
        "ù",
        "ú",
        "û",
        "ü",
        "ý",
        "þ",
        "ÿ"
    ];
    var ee = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00';
    li = 16515;
    while (li != 'lxl') {
        // console.log(li);
        var gi = li >> 5,
            Ci = 31 & gi,
            mi = 31 & gi >> 5;
        switch (31 & li) {
            case 0:
                switch (Ci) {
                    case 2:
                        switch (mi) {
                            case 5:
                                R = k = f,
                                    li = (bo = (P = (fe = fe < 15) * fe) > (Y = (A = 215 | (bo = !hi)) << 25)) ? 1349 : 14688
                                break;
                            default:
                                console.log('0-2');
                                break;
                        }
                        break;
                    case 3:
                        switch (mi) {
                            case 23:
                                Ge = z[Le],
                                    f = 255 & (Ge = (f = Ge >> G) + (k = Ge << he)),
                                    Ie.push(f),
                                    li = 8548
                                break;
                            default:
                                console.log('0-3');
                                break;
                        }
                        break;
                    case 10:
                        switch (mi) {
                            case 6:
                                f = void 0,
                                    li = (k = (S = 0 | (k = O)) < 128) ? 13984 : 25029
                                break;
                            default:
                                console.log('0-10');
                                break;
                        }
                        break;
                    case 12:
                        switch (mi) {
                            case 24:
                                Le++,
                                li = 24005
                                break;
                            default:
                                console.log('0-12');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 16:
                                li = 8739
                                break;
                            default:
                                console.log('0-15');
                                break;
                        }
                        break;
                    case 19:
                        switch (mi) {
                            case 18:
                                I = f.length - 1,
                                    li = 7685
                                break;
                            default:
                                console.log('0-19');
                                break;
                        }
                        break;
                    case 20:
                        switch (mi) {
                            case 1:
                                Q = void 0,
                                    K = R,
                                    z = [],
                                    G = 181,
                                    he = 5,
                                    Ie = 0,
                                    li = 28514
                                break;
                            case 25:
                                Pe = ve = W,
                                    ve = void 0,
                                    W = 0,
                                    (O = (Q = Pe).slice()).push(0, 0, 0),
                                    Q = 0,
                                    de = 0;
                                li = 22724
                                break;
                            default:
                                console.log('0-20');
                                break;
                        }
                        break;
                    case 21:
                        switch (mi) {
                            case 8:
                                li = de ? 3237 : 483
                                break;
                            default:
                                console.log('0-21');
                                break;
                        }
                        break;
                    case 22:
                        switch (mi) {
                            case 19:
                                z = K = Ie,
                                    W = W.concat(z),
                                    li = 19650
                                break;
                            default:
                                console.log('0-22');
                                break;
                        }
                        break;
                    case 23:
                        switch (mi) {
                            case 28:
                                K = void 0,
                                    z = R,
                                    G = 3,
                                    he = 5,
                                    Ie = [],
                                    Le = 0,
                                    li = 1316
                                break;
                            default:
                                console.log('0-23');
                                break;
                        }
                        break;
                    case 27:
                        switch (mi) {
                            case 6:
                                Ie++,
                                li = 28514
                                break;
                            default:
                                console.log('0-27');
                                break;
                        }
                        break;
                    case 28:
                        switch (mi) {
                            case 14:
                                R = T % de.length,
                                    T = de[R],
                                    de = Pe = de = T % 4,
                                    Pe = Math,
                                    Q = O.length / 2,
                                    T = Pe['ceil'](Q),
                                    Pe = 0,
                                    li = 23010
                                break;
                            default:
                                console.log('0-28');
                                break;
                        }
                        break;
                }
                break;
            case 1:
                switch (Ci) {
                    case 0:
                        switch (mi) {
                            case 12:
                                li = 1381
                                break;
                            case 18:
                                ve = (Q = ve = Q).concat(Pe),
                                    Pe = ve.length,
                                    Q = void 0,
                                    li = (W = (Pe = 0 | (W = Pe)) < 16384) ? 20546 : 28386
                                break;
                            default:
                                console.log('1-0');
                                break;
                        }
                        break;
                    case 3:
                        switch (mi) {
                            case 2:
                                b = 255 & oe[C],
                                    j = 0,
                                    w = 0,
                                    j = f.indexOf(Ge[b], 1),
                                    li = (I = 255 === b) ? 19040 : 4321
                                break;
                            case 27:
                                li = Le < z.length ? 8035 : 20160
                                break;
                            default:
                                console.log('1-3');
                                break;
                        }
                        break;
                    case 6:
                        switch (mi) {
                            case 13:
                                Pe++,
                                li = 23010
                                break;
                            default:
                                console.log('1-6');
                                break;
                        }
                        break;
                    case 7:
                        switch (mi) {
                            case 4:
                                D = Ge[m = b + 1],
                                    I = f.indexOf(D, 1),
                                    li = 7685
                                break;
                            default:
                                console.log('1-7');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 17:
                                li = (oe = 1 === Q) ? 27717 : 19650
                                break;
                            default:
                                console.log('1-9');
                                break;
                        }
                        break;
                    case 22:
                        switch (mi) {
                            case 8:
                                m = anonymous,
                                    li = 8578
                                break;
                            default:
                                console.log('1-22');
                                break;
                        }
                        break;
                    case 26:
                        switch (mi) {
                            case 8:
                                Y |= 7,
                                    T = 100 & O[Q],
                                    qe = (Oo = Y * Y) > -13,
                                    W += T,
                                    R = O[T = Q + 1],
                                    W += T = 100 & R,
                                    T = Q + 2,
                                    li = 26243
                                break;
                            default:
                                console.log('1-26');
                                break;
                        }
                        break;
                    case 27:
                        switch (mi) {
                            case 6:
                                Ge = z[Le],
                                    Ge = 255 & (f = (Ge = (f = Ge >> he) + (S = Ge << (k = 8 - he))) + Ie),
                                    G.push(Ge),
                                    li = 24960
                                break;
                            default:
                                console.log('1-27');
                                break;
                        }
                        break;
                }
                break;
            case 2:
                switch (Ci) {
                    case 2:
                        switch (mi) {
                            case 20:
                                O = void 0,
                                    li = (de = (T = 0 | (de = Pe)) < 128) ? 5954 : 13090
                                break;
                            default:
                                console.log('2-2');
                                break;
                        }
                        break;
                    case 6:
                        switch (mi) {
                            case 19:
                                li = (oe = 2 === Q) ? 11589 : 8421
                                break;
                            default:
                                console.log('2-6');
                                break;
                        }
                        break;
                    case 10:
                        switch (mi) {
                            case 24:
                                C++,
                                li = 23266
                                break;
                            default:
                                console.log('2-10');
                                break;
                        }
                        break;
                    case 12:
                        switch (mi) {
                            case 8:
                                li = (D = m) ? 29316 : 8034
                                break;
                            default:
                                console.log('2-12');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 22:
                                li = Pe < T ? 9732 : 26240
                                break;
                            default:
                                console.log('2-15');
                                break;
                        }
                        break;
                    case 23:
                        switch (mi) {
                            case 22:
                                li = C < oe.length ? 2145 : 1187
                                break;
                            default:
                                console.log('2-23');
                                break;
                        }
                        break;
                    case 24:
                        switch (mi) {
                            case 9:
                                ve = R.length > 7,
                                    li = ve ? 4197 : 12289
                                break;
                            default:
                                console.log('2-24');
                                break;
                        }
                        break;
                    case 25:
                        switch (mi) {
                            case 12:
                                z = 128 + (R = T % 128),
                                    R = 127 & (K = (oe = T - R) / 128),
                                    (oe = []).push(z, R),
                                    O = oe,
                                    li = 25797
                                break;
                            default:
                                console.log('2-25');
                                break;
                        }
                        break;
                    case 26:
                        switch (mi) {
                            case 15:
                                Le = G ^ K[Ie],
                                    Le = (Ge = Le >> he) ^ K[Ie],
                                    Ge = 255 & Le,
                                    z.push(Ge),
                                    li = 7008
                                break;
                            default:
                                console.log('2-26');
                                break;
                        }
                        break;
                    case 27:
                        switch (mi) {
                            case 27:
                                li = Ie < K.length ? 16194 : 17156
                                break;
                            default:
                                console.log('2-27');
                                break;
                        }
                        break;
                }
                break;
            case 3:
                switch (Ci) {
                    case 4:
                        switch (mi) {
                            case 16:
                                Le = parseInt,
                                    O = R.length,
                                    R = void 0,
                                    li = (Ge = (O = 0 | (Ge = O)) < 16384) ? 6464 : 23074
                                break;
                            default:
                                console.log('3-4');
                                break;
                        }
                        break;
                    case 5:
                        switch (mi) {
                            case 1:
                                T = ve[z](2);
                                ve = T[K](2);
                                T = ve[Ie]('/0+$/', he);
                                R += T;
                                li = 25700
                                break;
                            default:
                                console.log('3-5');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 0:
                                de = 1,
                                    T = Q < O.length,
                                    li = T ? 9025 : 16864
                                break;
                            default:
                                console.log('3-15');
                                break;
                        }
                        break;
                    case 17:
                        switch (mi) {
                            case 8:
                                Q = 65535 & W,
                                    W = void 0,
                                    T = 255 & (de = (O = Q) >> 8),
                                    (Q = []).push(T, de = 255 & O),
                                    Q = W = Q,
                                    li = 18433
                                break;
                            default:
                                console.log('3-17');
                                break;
                        }
                        break;
                    case 20:
                        switch (mi) {
                            case 25:
                                R = O[T],
                                    W += T = 100 & R,
                                    li = qe ? 14852 : 28480
                                break;
                            default:
                                console.log('3-20');
                                break;
                        }
                        break;
                    case 26:
                        switch (mi) {
                            case 16:
                                z = K = Ie,
                                    W = W.concat(z),
                                    li = 17697
                                break;
                            default:
                                console.log('3-26');
                                break;
                        }
                        break;
                    case 27:
                        switch (mi) {
                            case 7:
                                Ge = z[Le],
                                    f = 255 & (Ge = (f = Ge >> G) + (k = Ge << he)),
                                    Ie.push(f),
                                    li = 28900
                                break;
                            default:
                                console.log('3-27');
                                break;
                        }
                        break;
                }
                break;
            case 4:
                switch (Ci) {
                    case 3:
                        switch (mi) {
                            case 25:
                                li = 9986
                                break;
                            default:
                                console.log('4-3');
                                break;
                        }
                        break;
                    case 6:
                        switch (mi) {
                            case 0:
                                W = [],
                                    de = 10,
                                    T = Pe.slice(8, de),
                                    Pe = T[0] << 8,
                                    de = Pe | T[1],
                                    Pe = de[co](),
                                    T = Pe.split(uo),
                                    Pe = void 0,
                                    de = T,
                                    T = 516727686,
                                    li = 15232
                                break;
                            case 22:
                                li = 8864
                                break;
                            default:
                                console.log('4-6');
                                break;
                        }
                        break;
                    case 7:
                        switch (mi) {
                            case 28:
                                Le++,
                                li = 27745
                                break;
                            default:
                                console.log('4-7');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 1:
                                li = Le < z.length ? 23648 : 17219
                                break;
                            default:
                                console.log('4-9');
                                break;
                        }
                        break;
                    case 11:
                        switch (mi) {
                            case 8:
                                Le++,
                                li = 1316
                                break;
                            default:
                                console.log('4-11');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 4:
                                b = S[z](2),
                                    j = b[K](2),
                                    b = ve[z](2),
                                    w = b[K](2),
                                    b = j.split(he),
                                    I = w.split(he),
                                    w = 0,
                                    m = b[G],
                                    li = m ? 8897 : 8578
                                break;
                            default:
                                console.log('4-15');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 9:
                                Q = 2 * Pe,
                                    oe = 2 + (R = 2 * Pe),
                                    R = O.slice(Q, oe),
                                    li = (oe = 0 == (Q = (K = (Q = 4 * de) + (oe = Pe % 4)) % 4)) ? 29408 : 17697
                                break;
                            case 14:
                                R = O[T = Q + 3],
                                    W += T = 100 & R,
                                    li = 22724
                                break;
                            default:
                                console.log('4-16');
                                break;
                        }
                        break;
                    case 20:
                        switch (mi) {
                            case 28:
                                w = b[G](anonymous, I);
                                li = (Oo = (bo = (Oo = 19 == Oo) * Oo) > -73) ? 2788 : 7875
                                break;
                            default:
                                console.log('4-20');
                                break;
                        }
                        break;
                    case 23:
                        switch (mi) {
                            case 2:
                                b = j[K](0, w),
                                    R += b,
                                    b = Math.pow(2, w),
                                    S = (j = S * b) - (w = 0 | j),
                                    ve = (j = ve * b) - w,
                                    li = 24898
                                break;
                            default:
                                console.log('4-23');
                                break;
                        }
                        break;
                    case 24:
                        switch (mi) {
                            case 16:
                                K = Q = z,
                                    W = W.concat(K),
                                    li = 13505
                                break;
                            default:
                                console.log('4-24');
                                break;
                        }
                        break;
                    case 27:
                        switch (mi) {
                            case 24:
                                z = K = G,
                                    bo >>= 18,
                                    Oo = 8,
                                    W = W.concat(z),
                                    li = (Oo = (fe = (Y = bo + Oo) * Y) >= (bo = 4 * (qe = bo * Oo))) ? 8421 : 10659
                                break;
                            default:
                                console.log('4-27');
                                break;
                        }
                        break;
                }
                break;
            case 5:
                switch (Ci) {
                    case 2:
                        switch (mi) {
                            case 27:
                                K = void 0,
                                    z = R,
                                    G = 7,
                                    he = 1,
                                    Ie = [],
                                    Le = 0,
                                    li = 27745
                                break;
                            default:
                                console.log('5-2');
                                break;
                        }
                        break;
                    case 3:
                        switch (mi) {
                            case 4:
                                ve = R[K](0, 8);
                                T = Le(ve, 2);
                                O.push(T);
                                R = R[K](8);
                                li = 25700
                                break;
                            default:
                                console.log('5-3');
                                break;
                        }
                        break;
                    case 5:
                        switch (mi) {
                            case 3:
                                Q += 4,
                                    li = 483
                                break;
                            default:
                                console.log('5-5');
                                break;
                        }
                        break;
                    case 6:
                        switch (mi) {
                            case 25:
                                Q = de = O,
                                    li = 25957
                                break;
                            default:
                                console.log('5-6');
                                break;
                        }
                        break;
                    case 7:
                        switch (mi) {
                            case 8:
                                li = (oe = 3 === Q) ? 1664 : 13505
                                break;
                            default:
                                console.log('5-7');
                                break;
                        }
                        break;
                    case 10:
                        switch (mi) {
                            case 1:
                                O = R,
                                    R = he,
                                    f = (Ge = vo + y) + vo,
                                    Ge = d,
                                    k = ee[K](0, ve),
                                    ve = 0,
                                    S = 1,
                                    C = 0,
                                    li = 23266
                                break;
                            case 11:
                                K = void 0,
                                    z = R,
                                    G = [],
                                    he = 6,
                                    Ie = 17961,
                                    Le = 0,
                                    li = 24005
                                break;
                            default:
                                console.log('5-10');
                                break;
                        }
                        break;
                    case 11:
                        switch (mi) {
                            case 1:
                                de = (ve = R + de)[K](0, 8);
                                ve = Le(de, 2),
                                    O.push(ve),
                                    W = Q = O,
                                    ve = void 0,
                                    Pe = be,
                                    O = W,
                                    li = 196
                                break;
                            case 25:
                                Q = (Pe = Q).concat(ve);
                                li = 'lxl'
                                break;
                            default:
                                console.log('5-11');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 23:
                                li = Le < z.length ? 7009 : 25444
                                break;
                            case 24:
                                w = 128 + (C = S % 128),
                                    C = 127 & (j = (b = S - C) / 128),
                                    (b = []).push(w, C),
                                    f = b,
                                    li = 5184
                                break;
                            default:
                                console.log('5-14');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 7:
                                w = I,
                                    I = (b = S - ve) / f.length,
                                    S = ve + (b = I * w),
                                    ve += b = I * j,
                                    b = f[K](0, w),
                                    j = b + k,
                                    b = f[K](w),
                                    f = j + b,
                                    li = 4580
                                break;
                            default:
                                console.log('5-16');
                                break;
                        }
                        break;
                }
                break;
        }
    };
    be_4 = Q;
    return be_4;
}



function deal_be(be) {
    be[1] = 4;
    be[4] = 255 & ((be.length - 12) >> 8);
    be[5] = 255 & (be.length - 12);
    var uo = '';
    var Pe = be.slice(12);
    var ve = void 0,
        Q = Pe,
        Pe = 0,
        W = 0,
        li = 5604;
    // var li = 8420;
    while (li != 'lxl') {
        var gi = li >> 5,
            Ci = 31 & gi,
            mi = 31 & gi >> 5;
        // console.log(li);
        switch (31 & li) {
            case 0:
                switch (Ci) {
                    case 12:
                        switch (mi) {
                            case 7:
                                W++,
                                li = 5604
                                break;
                            default:
                                console.log('0-12');
                                break;
                        }
                        break;
                }
                break;
            case 3:
                switch (Ci) {
                    case 15:
                        switch (mi) {
                            case 21:
                                Q = void 0,
                                    $ = 255 & (O = (W = Pe) >> 8),
                                    (Pe = []).push($, O = 255 & W),
                                    ve = Pe = Q = Pe,
                                    li = 11
                                break;
                            case 27:
                                li = ji < 2 ? 9380 : 6020
                                break;
                            default:
                                console.log('3-15');
                                break;
                        }
                        break;
                }
                break;
            case 4:
                switch (Ci) {
                    case 5:
                        switch (mi) {
                            case 9:
                                be[ve = 10 + ji] = Pe[ji],
                                    li = 20196
                                break;
                            default:
                                console.log('4-5');
                                break;
                        }
                        break;
                    case 7:
                        switch (mi) {
                            case 8:
                                O = 71 & Q[W],
                                    Pe = 65535 & ($ = Pe + O),
                                    li = 7552
                                break;
                            default:
                                console.log('4-7');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 5:
                                li = W < Q.length ? 8420 : 21987;
                                break;
                            default:
                                console.log('4-15');
                                break;
                        }
                        break;
                    case 23:
                        switch (mi) {
                            case 19:
                                ji++,
                                li = 28131
                                break;
                            default:
                                console.log('4-23');
                                break;
                        }
                        break;
                    case 28:
                        switch (mi) {
                            case 5:
                                // 停止点
                                li = 'lxl'
                                    // ve = Pe = Z = be,
                                    //     li = le[11] ? 11588 : 22144
                                break;
                            default:
                                console.log('4-28');
                                break;
                        }
                        break;
                }
                break;
            case 11:
                Pe = ve;
                var ji = 0;
                li = 28131;
                break;
        }

    };
    // console.log(be.toString());
    return be;

}

function lxl(Z) {
    var K = "S+6s3fdKZ9I21yLDiCGJgVomYrFq5O/XU7ea0EbQMBTNuP4lhRwx8ktApzcWvjnH=";
    var z = Z.length;
    var G = 'charAt';
    li = 18723;
    var Be = false;
    var W = '';
    var oe = 0;
    while (li != 'lxl') {
        // console.log(li);
        var gi = li >> 5,
            Ci = 31 & gi,
            mi = 31 & gi >> 5;
        switch (31 & li) {
            case 0:
                switch (Ci) {
                    case 22:
                        switch (mi) {
                            case 23:
                                qe = !Be,
                                    bo = (qe *= qe) > -183,
                                    he = oe++,
                                    U = Z[he],
                                    O = 255 & U,
                                    he = oe++,
                                    U = Z[he],
                                    be = 255 & U,
                                    he = oe++,
                                    li = 10244
                                break;
                            default:
                                console.log('0-22');
                                break;
                        }
                        break;
                }
                break;
            case 1:
                switch (Ci) {
                    case 26:
                        switch (mi) {
                            case 21:
                                O = 227,
                                    A = true,
                                    be = [],
                                    $ = "00",
                                    de = (de = "!").split("").reverse().join(""),
                                    be.push($, O, de),
                                    $ = be,
                                    li = 13476
                                break;
                            default:
                                console.log('1-26');
                                break;
                        }
                        break;
                }
                break;
            case 2:
                switch (Ci) {
                    case 4:
                        switch (mi) {
                            case 24:
                                he = K[G](de),
                                    U = W + he,
                                    he = K[G](T),
                                    Ie = U + he,
                                    he = K[G](R),
                                    U = Ie + he,
                                    he = K[G](pe),
                                    W = U + he,
                                    li = 18723
                                break;
                            default:
                                console.log('2-4');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 25:
                                R = pe = 64,
                                    li = 24706
                                break;
                            default:
                                console.log('2-14');
                                break;
                        }
                        break;
                    case 21:
                        switch (mi) {
                            case 3:
                                li = (U = oe === he) ? 26050 : 8805
                                break;
                            default:
                                console.log('2-21');
                                break;
                        }
                        break;
                }
                break;
            case 3:
                switch (Ci) {
                    case 9:
                        switch (mi) {
                            case 18:
                                li = 11429
                                break;
                            default:
                                console.log('3-9');
                                break;
                        }
                        break;
                    case 12:
                        switch (mi) {
                            case 13:
                                li = 22337
                                break;
                            default:
                                console.log('3-12');
                                break;
                        }
                        break;
                    case 20:
                        switch (mi) {
                            case 10:
                                T = (U = (he = 3 & O) << 4) | (he = be >> 4),
                                    R = (U = (he = 15 & be) << 2) | (he = $ >> 6),
                                    pe = 63 & $,
                                    he = z + 2,
                                    li = 3746
                                break;
                            default:
                                console.log('3-20');
                                break;
                        }
                        break;

                }
                break;
            case 4:
                switch (Ci) {
                    case 0:
                        switch (mi) {
                            case 10:
                                U = Z[he],
                                    $ = 255 & U,
                                    de = O >> 2,
                                    li = bo ? 10883 : 22753
                                break;
                            default:
                                console.log('4-0');
                                break;
                        }
                        break;
                    case 5:
                        switch (mi) {
                            case 13:
                                O = $.join(""),
                                    be = O.length - 4,
                                    $ = O["substring"](be),
                                    O = $ + W;
                                li = 'lxl'
                                break;
                            default:
                                console.log('4-5');
                                break;
                        }
                        break;
                    case 25:
                        switch (mi) {
                            case 19:
                                pe = 64,
                                    li = 24706
                                break;
                            default:
                                console.log('4-25');
                                break;
                        }
                        break;

                }
                break;
            case 5:
                switch (Ci) {
                    case 5:
                        switch (mi) {
                            case 11:
                                li = (he = oe < z) ? 24256 : 13699
                                break;
                            default:
                                console.log('5-5');
                                break;
                        }
                        break;
                    case 19:
                        switch (mi) {
                            case 8:
                                li = (Ie = oe === (he = z + 1)) ? 20260 : 24706
                                break;
                            default:
                                console.log('5-19');
                                break;
                        }
                        break;
                }
                break;
        }
    };
    // O是最后参数
    return O

}



function get_227_wg(pre_url) {
    ve = get_track();
    track_enc();
    GD = S;
    var be_1 = get_be_1();
     ve[18] = [5, 6, 3, 4, 7, 8, 9, 10, 11, 12, 13, 0, 1];
//    ve[18] = [6, 7, 3, 4, 5, 8, 9, 10, 11, 12, 13, 14, 0, 1];
    var be_2 = [50, 17, 94, 115, 115, 81, 81, 54, 79, 16, 176, 74, 124, 133, 130, 14, 127, 184, 192, 68, 125, 81, 88, 55, 78, 235, 231, 115, 113, 80, 82, 54, 76, 231, 239, 114, 115, 80, 81, 55, 174, 235, 235, 41, 150, 239, 121, 55, 79, 20, 24];
    var be_2 = [50, 18, 22, 115, 115, 81, 81, 54, 79, 16, 188, 70, 118, 133, 136, 5, 119, 184, 196, 71, 117, 81, 88, 55, 78, 235, 231, 115, 113, 80, 82, 54, 76, 231, 239, 114, 115, 80, 81, 55, 174, 235, 235, 90, 162, 225, 197, 55, 79, 20, 24];
    be_1 = be_1.concat(be_2);
    // var S = params.enc_track;
    var W = get_cs_be_3();
    var gd_3 = get_T(get_0000(W), W.length);
    var be_3 = get_be_3(gd_3);
    be_1 = be_1.concat(be_3);
    var be_4 = get_be_4(pre_url, ve[24], ve[24] + Math.floor(Math.random() * (1390 - 1000 + 1)) + 1000);
    be_1 = be_1.concat(be_4);
    var token = deal_be(be_1);
    data = lxl(token);
    console.log(data);
    return data

}



//pre_url = 'https://login.taobao.com//newlogin/account/check.do/_____tmd_____/punish?x5secdata=xd8d65d78e35e23219ecc11bf970f47640f62bc47d0e8'
//get_227_wg(pre_url)
    // for (var i = 0; i < 1000; i++) {
    //     pre_url = 'https://login.taobao.com//newlogin/account/check.do/_____tmd_____/punish?x5secdata=xd8d65d78e35e23219ecc11bf970f47640f62bc47d0e8'
    //     get_227_wg(pre_url)
    // }