(function() {
  var oldOpen = XMLHttpRequest.prototype.open;
  var oldSend = XMLHttpRequest.prototype.send;
  var oldSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;

  XMLHttpRequest.prototype.open = function(method, url, async, user, password) {
    this._method = method;
    this._url = url;
    return oldOpen.apply(this, arguments);
  };

  XMLHttpRequest.prototype.send = function(body) {
    this._body = body;
    var self = this;
    var oldOnReadyStateChange = this.onreadystatechange;

    this.onreadystatechange = function() {
      //这里过滤url中包含值
      if (self.readyState === 4 && self._url.includes('.ts')) {
        // ...其他的日志记录代码...
        console.log("Request URL:", self._url);
        console.log("Request Method:", self._method);
        console.log("Request Headers:", self._headers);
        if (self._body) {
          console.log("Request Body:", self._body);
        }
        console.log('Response Body:', self.responseText);

      }
      if (oldOnReadyStateChange) {
        return oldOnReadyStateChange.apply(self, arguments);
      }
    };

    return oldSend.apply(this, arguments);

  };
})();
