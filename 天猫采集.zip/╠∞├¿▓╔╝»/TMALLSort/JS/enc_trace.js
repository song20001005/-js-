function get_arr_90(track_list) {
    var We = [];
    We[90] = [];
    We[93] = Date.now();
    We[48] = get_time_arr8(We[93]);
    We[89] = 0;
    We[16] = 0;
    We[58] = 0;
    We[3] = [];
    // event_ = {
    //     'pageX': 242,
    //     'pageY': 162,
    //     'type': 'mousedown',
    //     'step_time': 462337
    // };
    for (var i = 0; i < track_list.length; i++) {
        event_ = track_list[i];
        if (event_.type == 'mousemove') {
            if (event_.move_off) {
                var De = 4;

            } else {
                var De = 3;
            }
            // var F = 0;
            // var Ze = new Date;
            // Ze = (Xe = +Ze) - We[93];
            var Ze = event_.step_time;
            var Xe = We[93] + Ze;
            We[24] = Ze;
            var q = We[48];
            var je = q[ce = Ze % 7];
            (q = [])[5] = 5;
            q[14] = De ^ je;
            q[12] = Ze;
            var se = 0;

            q[2] = event_['pageX']; //pageX不要取0
            q[11] = event_['pageY'];
            q[2] = q[2] ^ je;
            q[11] = q[11] ^ je;
            ie = 0; //客户端高度，ClientTop
            ce = ie;
            ie = event_['pageX'] //此处是clientX，但是最好与pageX一致
            q[10] = ie ^ je;
            _ = event_['pageY'] + se; //此处是clientX，但是最好与pageX一致
            q[0] = _ ^ je;
            q[8] = F ^ je;
            q[17] = ce ^ je;
            q[15] = Xe ^ je;
            (ce = We[90]).push(q);
            We[89]++;
        } else {
            var $e = 0;
            var De = 4; //初始大数组26为长度，nc_1_n1z的位置
            var ce = event_.step_time;
            var Fe = We[48];
            var se = Fe[je = ce % 7];
            var Fe = [];
            if (event_.type == 'mousedown') {
                var F = 3;

            } else {
                var F = 2;
            }
            Fe[5] = F;
            // Xe = 1 === We[36],  //判断分支 滑块为0
            Fe[14] = De ^ se;
            Fe[2] = event_.pageX ^ se;
            Fe[11] = event_.pageY ^ se;
            Fe[6] = $e ^ se;
            Fe[12] = ce;
            Fe[16] = se;
            (De = We[90]).push(Fe);
            We[89]++;
            // Fe = We[90];
            //focus同时触发
            if (event_.type == 'mousedown') {
                Xe = event_.step_time + 1;
                De = 1;
            } else {
                Xe = event_.step_time + 1000;
                De = 0;
            }
            we = We[48];
            Ze = we[no = Xe % 7];
            var cs_arr_26 = 4; //初始大数组26为长度
            (we = [])[0] = cs_arr_26 ^ Ze;
            we[2] = De ^ Ze;
            we[1] = Xe;
            We[3].push(we);

        };
    };
    console.log(JSON.stringify(We));
    return We

}



function get_track_list(cs_trace) {
    var trace = [];
    var hh = 0;
    for (var i = 0; i < cs_trace.length; i++) {
        if (cs_trace[i][2] - hh >= 2) {
            trace.push({
                'pageX': cs_trace[i][0],
                'pageY': cs_trace[i][1],
                'type': 'mousemove',
                'step_time': Math.floor(cs_trace[i][2])
            });
            hh = cs_trace[i][2]
        }
    }
    // trace.push({
    //     'pageX': button_x - 2,
    //     'pageY': button_y,
    //     'type': 'mousedown',
    //     'step_time': cs_time
    // });
    trace[Math.floor((trace.length / 3))].type = 'mousedown';
    // trace[0].type = 'mousedown';
    return trace
};

function get_time_arr8(a) {
    var Be = a;
    Ie = void 0;
    So = (ko = 0 | (So = (ye = Be) / (Be = 4294967296))) * Be;
    Be = ye - So;
    ye = void 0;
    So = ko;
    ko = [];
    W = 255 & (ze = So >> 24);
    V = 255 & (ze = So >> 16);
    me = 255 & (ze = So >> 8);
    ze = 255 & So;
    ko.push(W, V, me, ze);
    So = ye = ko;
    ye = void 0;
    ko = Be;
    Be = [];
    W = 255 & (ze = ko >> 24);
    V = 255 & (ze = ko >> 16);
    me = 255 & (ze = ko >> 8);
    ze = 255 & ko;
    Be.push(W, V, me, ze);
    Be = ye = Be;
    ye = So.concat(Be);
    return ye;
}

function get_arr_5(k) {
    var arr_5 = [];
    for (var i = 0; i < k.length; i++) {
        if (k[i].length == 17) {
            arr_5.push(i)
        } else {

        }
    };
    return arr_5
}

function track_enc() {
    var Q = [30, 4, 300, 6, 0, 'cn', 14, undefined, 1, 200, 1, 1, 30, 4];
    var $ = void 0;
    var G = Q;
    var k = (oe = ve)[90];
    // oe[89] = k.length;
    oe[58] = 0;
    // oe[18] = [6, 7];
    oe[5] = get_arr_5(k); //轨迹中长度为17的下标
    oe[46] = oe[5][oe[5].length - 1] - 1;
    if (oe[46] < 0) {
        oe[46] = 0;
    }

    var no = "Reflect";
    var ri = "clear";
    var _e = "navigator";
    var f = "hardwareConcurrency";
    var oo = "passive";
    li = k ? 4353 : 13953;
    while (li != 'lxl') {
        var gi = li >> 5,
            Ci = 31 & gi,
            mi = 31 & gi >> 5;
        // console.log(li);
        switch (31 & li) {
            case 0:
                switch (Ci) {
                    case 0:
                        switch (mi) {
                            case 16:
                                re = J[18],
                                    ke = void 0,
                                    ae = 0,
                                    Ee = N,
                                    li = (Be = re).indexOf ? 10915 : 6912
                                break;
                            default:
                                console.log('0-0');
                                break;
                        }
                        break;
                    case 2:
                        switch (mi) {
                            case 18:
                                j = b,
                                    li = 18243
                                break;
                            default:
                                console.log('0-2');
                                break;
                        }
                        break;
                    case 4:
                        switch (mi) {
                            case 0:
                                y = 3 === x[5],
                                    li = y ? 4450 : 19557
                                break;
                            case 20:
                                D = k[m],
                                    N = 5 !== D[5],
                                    li = N ? 28929 : 323
                                break;
                            default:
                                console.log('0-4');
                                break;
                        }
                        break;
                    case 7:
                        switch (mi) {
                            case 15:
                                // console.log(ve);
                                // console.log(S[0]);
                                li = 'lxl'
                                break;
                            default:
                                console.log('0-7');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 7:
                                E = 127 & y,
                                    li = (y >>= 7) ? 6884 : 29536
                                break;
                            case 20:
                                L = V >= -4,
                                    li = (qe = (bo = (Oo = (Y = Y < 5) * Y) + (qe = (P = 0 == P) * P)) >= (fe = Y * P)) ? 28449 : 9827
                                break;
                            default:
                                console.log('0-8');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 19:
                                ke = 128 + (V = M % 128),
                                    V = 127 & (re = (J = M - V) / 128),
                                    (J = []).push(ke, V),
                                    B = J,
                                    li = 21092
                                break;
                            case 23:
                                li = (L = x) ? 13665 : 28676
                                break;
                            default:
                                console.log('0-9');
                                break;
                        }
                        break;
                    case 10:
                        switch (mi) {
                            case 1:
                                li = m < k.length ? 20608 : 6533
                                break;
                            default:
                                console.log('0-10');
                                break;
                        }
                        break;
                    case 13:
                        switch (mi) {
                            case 20:
                                li = (Se = -1 === (Be = Se)) ? 18562 : 8611
                                break;
                            default:
                                console.log('0-13');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 25:
                                li = (N = L) ? 17251 : 6402
                                break;
                            default:
                                console.log('0-14');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 3:
                                m = B,
                                    li = 12099
                                break;
                            default:
                                console.log('0-15');
                                break;
                        }
                        break;
                    case 17:
                        switch (mi) {
                            case 10:
                                li = (B = (y = B) < 64) ? 3493 : 1377
                                break;
                            default:
                                console.log('0-17');
                                break;
                        }
                        break;
                    case 18:
                        switch (mi) {
                            case 4:
                                ae = J[18],
                                    re = ae.length,
                                    (ae = J[18]).push(N),
                                    li = 26;
                                break;
                            case 5:
                                m++,
                                li = 1344
                                break;
                            default:
                                console.log('0-18');
                                break;
                        }
                        break;
                    case 23:
                        switch (mi) {
                            case 25:
                                x = m,
                                    (L = L.concat(x)).push(V),
                                    m = void 0,
                                    li = (x = (y = 0 | (x = J)) < 16384) ? 20898 : 20322
                                break;
                            default:
                                console.log('0-23');
                                break;
                        }
                        break;
                    case 27:
                        switch (mi) {
                            case 28:
                                B.push(E),
                                    li = y ? 7393 : 7524
                                break;
                            default:
                                console.log('0-27');
                                break;
                        }
                        break;
                }
                break;
            case 1:
                switch (Ci) {
                    case 2:
                        switch (mi) {
                            case 26:
                                ee = ae = [ke],
                                    li = 22146
                                break;
                            default:
                                console.log('1-2');
                                break;
                        }
                        break;
                    case 3:
                        switch (mi) {
                            case 5:
                                J = 1,
                                    li = 10692
                                break;
                            case 6:
                                m = E = [x + 64 * y],
                                    li = 481
                                break;
                            default:
                                console.log('1-3');
                                break;
                        }
                        break;
                    case 4:
                        switch (mi) {
                            case 16:
                                B = x,
                                    li = (bo = (A = (fe = S !== f) * fe) >= (bo = (qe = fe * (P = 11)) - (Oo = P * P))) ? 23044 : 16898
                                break;
                            default:
                                console.log('1-4');
                                break;
                        }
                        break;
                    case 5:
                        switch (mi) {
                            case 3:
                                J = 0,
                                    li = 2468
                                break;
                            default:
                                console.log('1-5');
                                break;
                        }
                        break;
                    case 6:
                        switch (mi) {
                            case 12:
                                B = x,
                                    D = D.concat(B),
                                    x = void 0,
                                    li = (B = (E = 0 | (B = J)) < 16384) ? 22149 : 13604
                                break;
                            case 16:
                                ke = void 0,
                                    Ee = ee,
                                    Be = (ae = L)[18],
                                    Se = void 0,
                                    Ue = 0,
                                    Ve = Ee;
                                li = (Ne = Be).indexOf ? 2466 : 2305
                                break;
                            default:
                                console.log('1-6');
                                break;
                        }
                        break;
                    case 7:
                        switch (mi) {
                            case 7:
                                li = 7424
                                break;
                            default:
                                console.log('1-7');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 4:
                                S = [],
                                    C = G[2] * G[13],
                                    b = oe[89] - C,
                                    li = (C = b < 0) ? 16965 : 1091
                                break;
                            case 28:
                                li = 5696
                                break;
                            default:
                                console.log('1-8');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 7:
                                C = w = [j],
                                    li = 21763
                                break;
                            default:
                                console.log('1-9');
                                break;
                        }
                        break;
                    case 11:
                        switch (mi) {
                            case 1:
                                ke = 128 + (E = y % 128),
                                    ae = (E = 63 & (re = (M = y - E) / 128)) + (re = 64 * x),
                                    (M = []).push(ke, ae),
                                    m = M,
                                    li = 26336
                                break;
                            case 13:
                                x = (B = 128 | (x = J << 6)) | (E = (x = M + 4) << 3),
                                    B = V + 4,
                                    D[0] = x | B,
                                    li = 1347
                                break;
                            default:
                                console.log('1-11');
                                break;
                        }
                        break;
                    case 13:
                        switch (mi) {
                            case 17:
                                x = ee,
                                    li = 15843
                                break;
                            default:
                                console.log('1-13');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 25:
                                ae = 128 + (E = x % 128),
                                    Ee = (E = 63 & (ke = (re = x - E) / 128)) + (ke = 64 * y),
                                    (re = []).push(ae, Ee),
                                    m = re,
                                    li = 481
                                break;
                            default:
                                console.log('1-14');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 0:
                                x = m,
                                    L = L.concat(x),
                                    m = void 0,
                                    li = (B = x = (y = 0 | (x = M)) < 0) ? 4610 : 13060
                                break;
                            default:
                                console.log('1-15');
                                break;
                        }
                        break;
                    case 19:
                        switch (mi) {
                            case 5:
                                li = (ee = (E = ee) < 64) ? 28898 : 16581
                                break;
                            default:
                                console.log('1-19');
                                break;
                        }
                        break;
                    case 25:
                        switch (mi) {
                            case 27:
                                li = (x = L) ? 13605 : 23840
                                break;
                            default:
                                console.log('1-25');
                                break;
                        }
                        break;
                    case 27:
                        switch (mi) {
                            case 2:
                                li = 27268
                                break;
                            default:
                                console.log('1-27');
                                break;
                        }
                        break;
                }
                break;
            case 2:
                switch (Ci) {
                    case 0:
                        switch (mi) {
                            case 21:
                                N = 128 + (I = j % 128),
                                    I = 127 & (D = (m = j - I) / 128),
                                    (m = []).push(N, I),
                                    C = m,
                                    li = 2564
                                break;
                            default:
                                console.log('2-0');
                                break;
                        }
                        break;
                    case 3:
                        switch (mi) {
                            case 16:
                                li = (x = L) ? 9733 : 8581
                                break;
                            default:
                                console.log('2-3');
                                break;
                        }
                        break;
                    case 4:
                        switch (mi) {
                            case 2:
                                m = 1,
                                    li = 128
                                break;
                            case 18:
                                Ue = ae[18],
                                    Be = Ue.length,
                                    (Ue = ae[18]).push(Ee),
                                    li = 8611
                                break;
                            case 27:
                                ee = E,
                                    li = 5729
                                break;
                            default:
                                console.log('2-4');
                                break;
                        }
                        break;
                    case 5:
                        switch (mi) {
                            case 28:
                                li = (L = N) ? 25316 : 26048
                                break;
                            default:
                                console.log('2-5');
                                break;
                        }
                        break;
                    case 7:
                        switch (mi) {
                            case 28:
                                x = re = [E + 64 * B],
                                    li = 12773
                                break;
                            default:
                                console.log('2-7');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 0:
                                ee.push(re),
                                    li = E ? 2913 : 8834
                                break;
                            case 6:
                                N = void 0,
                                    L = oe,
                                    x = w,
                                    D = (y = D)[12],
                                    B = L[48],
                                    M = B[E = D % 7],
                                    B = 0,
                                    E = 0,
                                    ee = void 0 !== y[2],
                                    li = 6434
                                break;
                            default:
                                console.log('2-8');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 2:
                                ee = E,
                                    li = 23909
                                break;
                            case 6:
                                li = ee ? 13540 : 29281
                                break;
                            default:
                                console.log('2-9');
                                break;
                        }
                        break;
                    case 11:
                        switch (mi) {
                            case 4:
                                m = 2,
                                    li = 19557
                                break;
                            default:
                                console.log('2-11');
                                break;
                        }
                        break;
                    case 13:
                        switch (mi) {
                            case 2:
                                Be = Ne.indexOf(Ve),
                                    Se = Be,
                                    li = 20896
                                break;
                            case 20:
                                B = void 0,
                                    li = (E = (M = 0 | (E = y)) < 128) ? 15876 : 19744
                                break;
                            default:
                                console.log('2-13');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 6:
                                ee = M ^ y[14],
                                    y = 0 === x.length,
                                    li = y ? 2469 : 4133
                                break;
                            case 20:
                                N = C.length - I,
                                    L = 2 * G[12],
                                    li = (x = N > L) ? 25602 : 17987
                                break;
                            default:
                                console.log('2-14');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 4:
                                B = -y,
                                    li = 10784
                                break;
                            default:
                                console.log('2-16');
                                break;
                        }
                        break;
                    case 17:
                        switch (mi) {
                            case 7:
                                L[2] = 0,
                                    L[11] = 0,
                                    L[12] = 0,
                                    li = 16741
                                break;
                            default:
                                console.log('2-17');
                                break;
                        }
                        break;
                    case 20:
                        switch (mi) {
                            case 8:
                                li = 17825
                                break;
                            case 21:
                                x = re = ee,
                                    li = 15843
                                break;
                            default:
                                console.log('2-20');
                                break;
                        }
                        break;
                    case 22:
                        switch (mi) {
                            case 2:
                                m = I,
                                    li = 1344
                                break;
                            default:
                                console.log('2-22');
                                break;
                        }
                        break;
                    case 25:
                        switch (mi) {
                            case 7:
                                L = M >= -4,
                                    li = 16482
                                break;
                            case 28:
                                re |= 128,
                                    li = 258
                                break;
                            default:
                                console.log('2-25');
                                break;
                        }
                        break;
                    case 27:
                        switch (mi) {
                            case 19:
                                B = [],
                                    li = 7424
                                break;
                            default:
                                console.log('2-27');
                                break;
                        }
                        break;
                    case 28:
                        switch (mi) {
                            case 20:
                                m = void 0,
                                    li = (N = (x = 0 | (N = ee)) < 128) ? 7460 : 18048
                                break;
                            default:
                                console.log('2-28');
                                break;
                        }
                        break;
                }
                break;
            case 3:
                switch (Ci) {
                    case 2:
                        switch (mi) {
                            case 1:
                                C = oe[46],
                                    li = (j = -1 === C) ? 20163 : 19107
                                break;
                            default:
                                console.log('3-2');
                                break;
                        }
                        break;
                    case 6:
                        switch (mi) {
                            case 4:
                                I++,
                                li = 708
                                break;
                            default:
                                console.log('3-6');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 21:
                                b = C,
                                    S[0] = b.concat(S[0]),
                                    $ = S,
                                    li = 3717
                                break;
                            default:
                                console.log('3-8');
                                break;
                        }
                        break;
                    case 10:
                        switch (mi) {
                            case 0:
                                li = (N = m !== I) ? 22212 : 28834
                                break;
                            case 1:
                                D = N = D,
                                    N = S[1],
                                    S[1] = N.concat(D),
                                    j++,
                                    li = 5696
                                break;
                            default:
                                console.log('3-10');
                                break;
                        }
                        break;
                    case 11:
                        switch (mi) {
                            case 19:
                                li = (x = L) ? 25221 : 7813
                                break;
                            default:
                                console.log('3-11');
                                break;
                        }
                        break;
                    case 12:
                        switch (mi) {
                            case 1:
                                m = C[I],
                                    D = m + oe[58],
                                    li = (N = D < 0) ? 25219 : 20930
                                break;
                            default:
                                console.log('3-12');
                                break;
                        }
                        break;
                    case 13:
                        switch (mi) {
                            case 8:
                                y = ke = ae = Be + 1,
                                    li = 24419
                                break;
                            case 26:
                                C = I = [j],
                                    li = 2564
                                break;
                            default:
                                console.log('3-13');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 15:
                                B = x,
                                    D = D.concat(B),
                                    x = void 0,
                                    li = (ee = B = (E = 0 | (B = M)) < 0) ? 20004 : 2338
                                break;
                            default:
                                console.log('3-15');
                                break;
                        }
                        break;
                    case 18:
                        switch (mi) {
                            case 17:
                                li = (m = x) ? 29410 : 18821
                                break;
                            default:
                                console.log('3-18');
                                break;
                        }
                        break;
                    case 19:
                        switch (mi) {
                            case 8:
                                y = x[12],
                                    B = N[48],
                                    M = B[E = y % 7],
                                    B = M ^ x[2],
                                    E = M ^ x[11],
                                    ee = M ^ x[14],
                                    V = void 0,
                                    J = N,
                                    N = ee,
                                    li = 16384
                                break;
                            default:
                                console.log('3-19');
                                break;
                        }
                        break;
                    case 21:
                        switch (mi) {
                            case 10:
                                re = Be.indexOf(Ee);
                                ke = re;
                                li = 14596
                                break;
                            case 18:
                                li = (j = C < b) ? 19106 : 18496
                                break;
                            default:
                                console.log('3-21');
                                break;
                        }
                        break;
                    case 22:
                        switch (mi) {
                            case 14:
                                B = x,
                                    D = D.concat(B),
                                    x = void 0,
                                    li = (ee = B = (E = 0 | (B = V)) < 0) ? 26117 : 27778
                                break;
                            case 19:
                                C = b,
                                    li = 19107
                                break;
                            default:
                                console.log('3-22');
                                break;
                        }
                        break;
                    case 23:
                        switch (mi) {
                            case 2:
                                x = ee = [E],
                                    li = 12481
                                break;
                            default:
                                console.log('3-23');
                                break;
                        }
                        break;
                    case 26:
                        switch (mi) {
                            case 11:
                                x = m,
                                    (L = L.concat(x)).push(N),
                                    li = (m = 1 === N) ? 15362 : 21378
                                break;
                            case 17:
                                b = j,
                                    S[1] = [],
                                    j = 0,
                                    w = [],
                                    I = b + oe[58],
                                    li = (m = I < 0) ? 4800 : 2754
                                break;
                            default:
                                console.log('3-26');
                                break;
                        }
                        break;
                    case 27:
                        switch (mi) {
                            case 16:
                                li = 5696
                                break;
                            case 23:
                                li = (L = 16 === J) ? 3233 : 2468
                                break;
                            default:
                                console.log('3-27');
                                break;
                        }
                        break;
                }
                break;
            case 4:
                switch (Ci) {
                    case 0:
                        switch (mi) {
                            case 28:
                                x = void 0,
                                    li = (B = (E = 0 | (B = y)) < 64) ? 2787 : 8960
                                break;
                            default:
                                console.log('4-28');
                                break;
                        }
                        break;
                    case 7:
                        switch (mi) {
                            case 13:
                                B = M ^ y[2],
                                    E = M ^ y[11],
                                    li = 6594
                                break;
                            default:
                                console.log('4-7');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 14:
                                li = (ke = -1 === (re = ke)) ? 4672 : 26
                                break;
                            default:
                                console.log('4-8');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 7:
                                m = y = [x],
                                    li = 37
                                break;
                            case 13:
                                ee = [],
                                    li = 27268
                                break;
                            default:
                                console.log('4-9');
                                break;
                        }
                        break;
                    case 11:
                        switch (mi) {
                            case 7:
                                li = mi < 8 ? 3552 : ao ? 16930 : 19204
                                break;
                            default:
                                console.log('4-11');
                                break;
                        }
                        break;
                    case 12:
                        switch (mi) {
                            case 28:
                                B = -x,
                                    li = 23044
                                break;
                            default:
                                console.log('4-12');
                                break;
                        }
                        break;
                    case 13:
                        switch (mi) {
                            case 2:
                                li = (L = 17 === J) ? 5217 : 10692
                                break;
                            default:
                                console.log('4-13');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 10:
                                x[14] = ee,
                                    x[2] = B,
                                    x[11] = E,
                                    x[12] = D,
                                    D = [],
                                    li = (L = 0 === y) ? 14884 : 19811
                                break;
                            default:
                                console.log('4-14');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 2:
                                j = C;
                                S[1] = j.concat(S[1]);
                                S[0] = [];
                                C = oe[5];
                                j = 0;
                                w = [];
                                I = 0;
                                li = 708
                                break;
                            case 15:
                                B = V = [M],
                                    li = 21092
                                break;
                            case 22:
                                li = (B = (x = B) < 64) ? 6241 : 26049
                                break;
                            default:
                                console.log('4-16');
                                break;
                        }
                        break;
                    case 17:
                        switch (mi) {
                            case 14:
                                L = J >= 0,
                                    li = 19811
                                break;
                            case 19:
                                ee = -E,
                                    li = 23909
                                break;
                            default:
                                console.log('4-17');
                                break;
                        }
                        break;
                    case 19:
                        switch (mi) {
                            case 20:
                                m = E = B,
                                    li = (A = (fe = (P = oo !== w) * P) > -52) ? 12099 : 28961
                                break;
                            default:
                                console.log('4-19');
                                break;
                        }
                        break;
                    case 20:
                        switch (mi) {
                            case 25:
                                Se = 128 + (ae = ke % 128),
                                    ae = 127 & (Be = (Ee = ke - ae) / 128),
                                    (Ee = []).push(Se, ae),
                                    ee = Ee,
                                    li = 22146
                                break;
                            case 26:
                                re = 127 & E,
                                    li = (E >>= 7) ? 29474 : 258
                                break;
                            default:
                                console.log('4-20');
                                break;
                        }
                        break;
                    case 22:
                        switch (mi) {
                            case 0:
                                li = I < C.length ? 1411 : 12901
                                break;
                            case 21:
                                L = C + oe[58],
                                    N = m < L,
                                    li = 28834
                                break;
                            default:
                                console.log('4-22');
                                break;
                        }
                        break;
                    case 23:
                        switch (mi) {
                            case 6:
                                E |= 128,
                                    li = 29536
                                break;
                            case 24:
                                N = m % G[13],
                                    L = 0 !== N,
                                    li = 26048
                                break;
                            default:
                                console.log('4-23');
                                break;
                        }
                        break;
                    case 24:
                        switch (mi) {
                            case 8:
                                Ee = 128 + (re = E % 128),
                                    Be = (re = 63 & (ae = (ke = E - re) / 128)) + (ae = 64 * B),
                                    (ke = []).push(Ee, Be),
                                    x = ke;
                                li = 15043
                                break;
                            case 12:
                                B = y,
                                    li = 10784
                                break;
                            default:
                                console.log('4-24');
                                break;
                        }
                        break;
                }
                break;
            case 5:
                switch (Ci) {
                    case 1:
                        switch (mi) {
                            case 0:
                                N = m,
                                    L = L.concat(N),
                                    m = D = L,
                                    D = S[0],
                                    S[0] = D.concat(m),
                                    j++,
                                    li = 4291
                                break;
                            case 4:
                                y = ee,
                                    M = B - x[2],
                                    V = E - x[11],
                                    J = D - x[12],
                                    re = y === x[14],
                                    li = re ? 27813 : 16577
                                break;
                            default:
                                console.log('5-1');
                                break;
                        }
                        break;
                    case 3:
                        switch (mi) {
                            case 19:
                                y = 1 === x[5],
                                    li = y ? 580 : 8803
                                break;
                            default:
                                console.log('5-3');
                                break;
                        }
                        break;
                    case 5:
                        switch (mi) {
                            case 0:
                                x = re = [E + 64 * B],
                                    li = 15043
                                break;
                            case 27:
                                y = 0,
                                    li = 24419
                                break;
                            default:
                                console.log('5-5');
                                break;
                        }
                        break;
                    case 6:
                        switch (mi) {
                            case 16:
                                Ee = 128 + (re = E % 128),
                                    Be = (re = 63 & (ae = (ke = E - re) / 128)) + (ae = 64 * B),
                                    (ke = []).push(Ee, Be),
                                    x = ke,
                                    li = 12773
                                break;
                            default:
                                console.log('5-6');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 13:
                                x = V <= 3,
                                    li = 23840
                                break;
                            default:
                                console.log('5-9');
                                break;
                        }
                        break;
                    case 10:
                        switch (mi) {
                            case 12:
                                li = (B = y) ? 29060 : 16513
                                break;
                            default:
                                console.log('5-10');
                                break;
                        }
                        break;
                    case 11:
                        switch (mi) {
                            case 16:
                                x = B - L[2],
                                    M = E - L[11],
                                    J = y - L[12],
                                    L[2] = B,
                                    L[11] = E,
                                    L[12] = y,
                                    L = [m],
                                    m = void 0,
                                    y = (x = 0 | (y = x)) < 0,
                                    li = 12613
                                break;
                            case 23:
                                li = (ee = (E = ee) < 64) ? 165 : 8964
                                break;
                            default:
                                console.log('5-11');
                                break;
                        }
                        break;
                    case 12:
                        switch (mi) {
                            case 6:
                                C = void 0,
                                    li = (w = (j = 0 | (w = j)) < 128) ? 27043 : 21506
                                break;
                            case 8:
                                li = (L = x) ? 20736 : 28449
                                break;
                            case 18:
                                m = k[D],
                                    D = void 0,
                                    N = oe,
                                    L = w,
                                    x = m,
                                    m = 0,
                                    y = 2 === x[5],
                                    li = y ? 2178 : 128
                                break;
                            case 19:
                                x = 0 === L.length,
                                    li = x ? 7714 : 16741
                                break;
                            default:
                                console.log('5-12');
                                break;
                        }
                        break;
                    case 13:
                        switch (mi) {
                            case 2:
                                x[14] = -1,
                                    x[2] = 0,
                                    x[11] = 0,
                                    x[12] = 0,
                                    li = 4133
                                break;
                            case 3:
                                m = E = [y + 64 * x],
                                    li = 26336
                                break;
                            default:
                                console.log('5-13');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 12:
                                B = x,
                                    D = D.concat(B),
                                    li = 1347
                                break;
                            default:
                                console.log('5-15');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 9:
                                x = M <= 3,
                                    li = (P = (bo = (fe = no === ri) * fe) >= (P = (Y = fe * (qe = !_e)) - (qe *= qe))) ? 8581 : 19777
                                break;
                            case 25:
                                ee = -E,
                                    li = 5729
                                break;
                            default:
                                console.log('5-16');
                                break;
                        }
                        break;
                    case 18:
                        switch (mi) {
                            case 16:
                                b = 0,
                                    A = !'g',
                                    li = (bo = (A *= A) > -28) ? 1091 : 10659
                                break;
                            default:
                                console.log('5-18');
                                break;
                        }
                        break;
                    case 19:
                        switch (mi) {
                            case 12:
                                C = void 0,
                                    li = (b = (j = 0 | (b = j)) < 128) ? 7457 : 16161
                                break;
                            default:
                                console.log('5-19');
                                break;
                        }
                        break;
                    case 20:
                        switch (mi) {
                            case 3:
                                $ = (oe = $)[0],
                                    li = $ ? 15584 : 11076
                                break;
                            case 7:
                                li = (L = x) ? 7970 : 16482
                                break;
                            case 21:
                                ee = void 0,
                                    li = (re = (ke = 0 | (re = E)) < 128) ? 26689 : 26244
                                break;
                            case 24:
                                x = J <= 1,
                                    li = 7813
                                break;
                            default:
                                console.log('5-20');
                                break;
                        }
                        break;
                }
                break;
            case 26:
                var Wi, Hi, Fi, Gi;
                ee = V = N = re + 1,
                    N = M ^ x[16],
                    V = M ^ x[6],
                    li = (J = 1 === N) ? 17475 : 19845;
                break;
        }
    };
    // console.log(S[0].toString());
    // console.log(oe);
    // return {
    //     'big_arr': ve,
    //     'enc_track': S
    // }

}

function get_be_1() {

    str_to_num = function(str, step) {
        var S = [];
        for (var i = 0; i < str.length;) {
            A = str.charCodeAt(i);
            f = 255 & A;
            S.push(f);
            i += step;
        };
        return S
    };

    var U = [1, 7, 77, 111, 122, 105, 108, 108, 97, 1, 1, 1];
    // j = Math.floor(Math.random() * (1801167347 - 520262599 + 1)) + 520262599;
    // S = [];
    // A = 255 & (m = j >> 24);
    // f = 255 & (m = j >> 16);
    // m = j >> 8;
    // b = 255 & m;
    // m = 255 & j;
    // S.push(A, f, b, m);
    // U = U.concat(S);
    U = U.concat([238, 219, 194, 201]);
    U.push(1);
    U.push(1, 1, 48); //定值
    U.push(15, 247, 36, 241); //定值，检测的10240-Infinity,-Infinity,-In

    //'48000_2_1_0_2_explicit_speakers' 由这个转换而来，写死
    U = U.concat([31, 52, 56, 48, 48, 48, 95, 50, 95, 49, 95, 48, 95, 50, 95, 101, 120, 112, 108, 105, 99, 105, 116, 95, 115, 112, 101, 97, 107, 101, 114, 115]);
    //-----------------------------------
    U = U.concat([1, 0, 1, 254, 1]);

    //'ANGLE_instanced_arrays;'检测的属性，可写死
    U = U.concat([14, 93, 241, 192]);
    //-----------------------------------
    U = U.concat([1, 0, 1, 47, 1, 0, 1]); //47存在疑点
    //检测的Win32,可写死
    U = U.concat([5, 87, 105, 110, 51, 50, 1]);
    //-----------------------------------
    //检测页面大小，存疑，先写死
    U = U.concat([0, 0, 128, 15, 0, 0, 0, 0, 0, 0, 184, 8, 255, 0, 40, 40, 255, 0, 255, 0, 255, 0, 1, 6, 1]); //与无感的差别之一
    // U = U.concat([0, 0, 128, 15, 212, 12, 0, 0, 212, 12, 212, 12, 212, 12, 184, 8, 150, 8, 40, 40, 150, 8, 150, 8, 150, 8, 1, 6, 1]);
    //-----------------------------------
    //检测了canvas，先写死
    U = U.concat([1, 0, 56, 1, 2, 39, 5, 26, 15, 194, 253, 57, 56, 1, 2, 1, 254, 1, 2, 1, 0, 1, 0, 1, 1, 1, 24, 24, 1, 0, 1]); //与无感的差别之一
    //-----------------------------------
    //‘Netscape’由他转换而来，写死
    U = U.concat([8, 78, 101, 116, 115, 99, 97, 112, 101]);
    //-----------------------------------

    U = U.concat([1, 0, 1, 0, 0, 0, 0, 1, 0, 1]); //先写死
    U = U.concat(ve[48]); //由时间戳生成的数组
    // U = U.concat([0, 0, 1, 140, 71, 245, 64, 37]);

    U = U.concat([1, 0, 1, 0, 1, 1, 1]);

    //R为[0,97,1],先写死,好像是定值
    U = U.concat([0, 100, 1]);
    //-----------------------------------

    U.push(1);
    //对轨迹的操作，先写死,s[0]

    U = U.concat(GD[0]);
    // U = U.concat([6, 0, 203, 6, 224, 1, 0, 132, 5, 0, 5, 1, 0, 0, 0, 16, 0, 5, 0, 20, 42, 0, 199, 12, 0, 4, 1, 0, 0, 0, 79, 0, 4, 0, 28, 247, 0, 0, 162, 6, 0, 3, 1, 0, 0, 0, 102, 0, 3]);
    // U = U.concat()
    //-----------------------------------
    U = U.concat([1, 255, 1]);
    //先写死,其中6 7 8 9 10 11 可以同时加1
    U = U.concat([4, 5, 1, 0, 4, 6, 1, 1, 4, 7, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 4, 3, 1, 0, 4, 8, 4, 9, 4, 10, 255, 1, 0, 1]);
    //-----------------------------------

    //写死，尾部需要处理，最后一位比上面的倒数第二位多1
    U = U.concat([0, 3, 248, 78, 1, 0, 1, 0, 1, 11]);
    //-----------------------------------
    // console.log(U.toString());

    var be = get_pre_12();
    var bo = true;
    var $ = void 0;
    var co = "toString";
    var uo = "";
    var ge = "Math";
    var yo = "Float32Array";
    var w = "PerformanceEntry";
    var Oo = 25;
    var k = U;
    var W = [];
    var S = 10;
    var ye = (f = be).slice(8, S);
    li = 12708;
    while (li != 'lxl') {
        var gi = li >> 5,
            Ci = 31 & gi,
            mi = 31 & gi >> 5;
        // console.log(li);
        switch (31 & li) {
            case 0:
                switch (Ci) {
                    case 2:
                        switch (mi) {
                            case 22:
                                li = B < x.length ? 21956 : 7618
                                break;
                            default:
                                console.log('0-22');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 18:
                                f = 2 * U,
                                    m = 2 + (j = 2 * U),
                                    j = k.slice(f, m),
                                    li = (m = 0 == (f = (x = (f = 4 * S) + (m = U % 4)) % 4)) ? 3522 : 8194
                                break;
                            default:
                                console.log('0-8');
                                break;
                        }
                        break;
                    case 10:
                        switch (mi) {
                            case 15:
                                W = $ = W,
                                    $ = void 0,
                                    f = 0,
                                    (k = (U = W).slice()).push(0, 0, 0),
                                    U = 0,
                                    S = 0,
                                    li = 13347
                                break;
                            default:
                                console.log('0-10');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 28:
                                $ = (U = $ = U).concat(W),
                                    W = $.length,
                                    U = void 0,
                                    li = (f = (W = 0 | (f = W)) < 16384) ? 18529 : 4771
                                break;
                            default:
                                console.log('0-16');
                                break;
                        }
                        break;
                    case 17:
                        switch (mi) {
                            case 7:
                                li = ee < y.length ? 514 : 17921
                                break;
                            default:
                                console.log('0-17');
                                break;
                        }
                        break;
                    case 23:
                        switch (mi) {
                            case 10:
                                ee++,
                                li = 7712
                                break;
                            case 17:
                                P = (P = (Y = w !== b) * Y) > -10,
                                    b = k[C = U + 3],
                                    f += C = 126 & b,
                                    li = P ? 13347 : 10370
                                break;
                            default:
                                console.log('0-23');
                                break;
                        }
                        break;
                    case 24:
                        switch (mi) {
                            case 20:
                                J = 255 & V,
                                    B.push(J),
                                    li = 29025
                                break;
                            default:
                                console.log('0-24');
                                break;
                        }
                        break;
                }
                break;
            case 1:
                switch (Ci) {
                    case 3:
                        switch (mi) {
                            case 18:
                                k = void 0,
                                    li = (S = (C = 0 | (S = W)) < 128) ? 26402 : 12355
                                break;
                            default:
                                console.log('1-3');
                                break;
                        }
                        break;
                    case 5:
                        switch (mi) {
                            case 26:
                                U = S = k,
                                    li = 15617
                                break;
                            default:
                                console.log('1-5');
                                break;
                        }
                        break;
                    case 7:
                        switch (mi) {
                            case 8:
                                li = ee < y.length ? 28356 : 25411
                                break;
                            default:
                                console.log('1-7');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 15:
                                U = (W = U).concat($);
                                be = be.concat(U);
                                W = [];
                                $ = void 0;
                                li = 'lxl'
                                break;
                            default:
                                console.log('1-8');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 3:
                                ye = "\u03f8\u03fe\u03f2\u03f7",
                                    C = "",
                                    b = 0,
                                    li = 11267
                                break;
                            default:
                                console.log('1-9');
                                break;
                        }
                        break;
                    case 11:
                        switch (mi) {
                            case 9:
                                li = 16676
                                break;
                            case 28:
                                ee++,
                                li = (fe = (P = (Y = U !== yo) * Y) > -255) ? 8417 : 20770
                                break;
                            default:
                                console.log('1-11');
                                break;
                        }
                        break;
                    case 12:
                        switch (mi) {
                            case 15:
                                li = U < C ? 18688 : 15680
                                break;
                            default:
                                console.log('1-12');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 17:
                                y = x = B,
                                    W = W.concat(y),
                                    li = 867
                                break;
                            default:
                                console.log('1-16');
                                break;
                        }
                        break;
                    case 17:
                        switch (mi) {
                            case 25:
                                f = void 0,
                                    x = j,
                                    y = [],
                                    E = 6,
                                    M = 3,
                                    ee = B = 246,
                                    B = 0,
                                    li = 22592
                                break;
                            default:
                                console.log('1-17');
                                break;
                        }
                        break;
                    case 19:
                        switch (mi) {
                            case 13:
                                C = 255 & (S = k >> 8),
                                    S = 255 & k,
                                    U.push(C, S),
                                    U = f = U,
                                    li = Y ? 29184 : 6595
                                break;
                            default:
                                console.log('1-19');
                                break;
                        }
                        break;
                    case 25:
                        switch (mi) {
                            case 11:
                                li = S ? 3108 : 13925
                                break;
                            default:
                                console.log('1-25');
                                break;
                        }
                        break;
                }
                break;
            case 2:
                switch (Ci) {
                    case 0:
                        switch (mi) {
                            case 8:
                                li = (m = 1 === f) ? 5506 : 13122
                                break;
                            default:
                                console.log('2-0');
                                break;
                        }
                        break;
                    case 3:
                        switch (mi) {
                            case 3:
                                C = Math[ye = C](U),
                                    U = 0,
                                    b = f = "mtW",
                                    li = 15745
                                break;
                            case 25:
                                C = 126 & k[U],
                                    f += C,
                                    b = k[C = U + 1],
                                    f += C = 126 & b,
                                    b = k[C = U + 2],
                                    f += C = 126 & b,
                                    li = 18144
                                break;
                            default:
                                console.log('2-3');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 17:
                                U++,
                                li = 15745
                                break;
                            case 21:
                                ye = f.split(uo),
                                    f = void 0,
                                    S = ye,
                                    C = (ye = 1469191576) % S.length,
                                    ye = S[C],
                                    S = f = S = ye % 4,
                                    f = U[ge],
                                    U = k.length / 2,
                                    li = 3361
                                break;
                            default:
                                console.log('2-8');
                                break;
                        }
                        break;
                    case 12:
                        switch (mi) {
                            case 5:
                                x = void 0,
                                    y = j,
                                    B = [],
                                    E = b,
                                    M = 0,
                                    ee = 0,
                                    li = 8417
                                break;
                            default:
                                console.log('2-12');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 3:
                                x = void 0,
                                    y = j,
                                    B = [],
                                    E = 4,
                                    M = 7,
                                    ee = 0,
                                    li = 6980
                                break;
                            case 7:
                                x = f = y,
                                    W = W.concat(x),
                                    li = 17666
                                break;
                            default:
                                console.log('2-14');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 0:
                                V = y[ee] - E,
                                    V = 255 & (J = (re = (J = 255 & V) >> (V = M)) + (V = J << (ke = 8 - V))),
                                    B.push(V),
                                    li = 10976
                                break;
                            default:
                                console.log('2-16');
                                break;
                        }
                        break;
                    case 26:
                        switch (mi) {
                            case 12:
                                li = (m = 2 === f) ? 17668 : 867
                                break;
                            default:
                                console.log('2-26');
                                break;
                        }
                        break;
                }
                break;
            case 3:
                switch (Ci) {
                    case 0:
                        switch (mi) {
                            case 11:
                                li = b < ye.length ? 12100 : 3170
                                break;
                            default:
                                console.log('3-0');
                                break;
                        }
                        break;
                    case 1:
                        switch (mi) {
                            case 13:
                                li = 12065
                                break;
                            default:
                                console.log('3-1');
                                break;
                        }
                        break;
                    case 2:
                        switch (mi) {
                            case 12:
                                x = 128 + (b = C % 128),
                                    b = 127 & (m = (j = C - b) / 128),
                                    (j = []).push(x, b),
                                    k = j,
                                    li = 26785
                                break;
                            case 23:
                                b++,
                                li = 11267
                                break;
                            default:
                                console.log('3-2');
                                break;
                        }
                        break;
                    case 21:
                        switch (mi) {
                            case 17:
                                ee++,
                                li = 6980
                                break;
                            default:
                                console.log('3-21');
                                break;
                        }
                        break;
                    case 26:
                        switch (mi) {
                            case 24:
                                y = x = B,
                                    W = W.concat(y),
                                    li = 13122
                                break;
                            default:
                                console.log('3-26');
                                break;
                        }
                        break;
                    case 27:
                        switch (mi) {
                            case 0:
                                li = (m = 3 === f) ? 26145 : 17666
                                break;
                            default:
                                console.log('3-27');
                                break;
                        }
                        break;
                }
                break;
            case 4:
                switch (Ci) {
                    case 1:
                        switch (mi) {
                            case 3:
                                U += 4,
                                    li = 13925
                                break;
                            default:
                                console.log('4-1');
                                break;
                        }
                        break;
                    case 7:
                        switch (mi) {
                            case 7:
                                B++,
                                li = 22592
                                break;
                            default:
                                console.log('4-7');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 17:
                                x = void 0,
                                    y = j,
                                    B = [],
                                    E = 7,
                                    M = 3,
                                    ee = 0,
                                    li = 7712
                                break;
                            default:
                                console.log('4-8');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 16:
                                U = 65535 & f,
                                    Y = (fe = (Oo <<= 0) * Oo) > (qe = (Oo = 454 | (P = P >= 18)) << 24),
                                    f = void 0,
                                    k = U,
                                    U = [],
                                    li = 13921
                                break;
                            default:
                                console.log('4-9');
                                break;
                        }
                        break;
                    case 13:
                        switch (mi) {
                            case 12:
                                f = ye[0] << 8,
                                    S = f | ye[1],
                                    f = S[co](),
                                    li = bo ? 21762 : 27072
                                break;
                            default:
                                console.log('4-13');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 21:
                                ee = (V = 240 & (J = (V = ee << E) ^ ee)) + (J = ee >> M),
                                    V = x[B] ^ ee,
                                    J = 255 & V,
                                    y.push(J),
                                    li = 7396
                                break;
                            default:
                                console.log('4-14');
                                break;
                        }
                        break;
                    case 22:
                        switch (mi) {
                            case 27:
                                V = y[ee],
                                    J = E.charCodeAt(M),
                                    V ^= J,
                                    M++,
                                    J = M >= E.length,
                                    li = J ? 5921 : 21248
                                break;
                            default:
                                console.log('4-22');
                                break;
                        }
                        break;
                    case 26:
                        switch (mi) {
                            case 6:
                                li = ee < y.length ? 20292 : 21316
                                break;
                            case 11:
                                j = 923 ^ ye.charCodeAt(b),
                                    C += String.fromCharCode(j),
                                    li = 23619
                                break;
                            case 19:
                                V = y[ee] - E,
                                    V = 255 & (J = (re = (J = 255 & V) >> (V = M)) + (V = J << (ke = 8 - V))),
                                    B.push(V),
                                    li = 18083
                                break;
                            case 20:
                                y = x = B,
                                    W = W.concat(y),
                                    li = 8194
                                break;
                            default:
                                console.log('4-26');
                                break;
                        }
                        break;
                }
                break;
            case 5:
                switch (Ci) {
                    case 19:
                        switch (mi) {
                            case 13:
                                S = 1,
                                    C = U < k.length,
                                    li = C ? 25698 : 9569
                                break;
                            default:
                                console.log('5-19');
                                break;
                        }
                        break;
                }
                break;

        }
    }
    return be

}

function get_pre_12() {
    var W = ve[93] + ve[24] + 888;
    var O = void 0;
    W = (be = W) - ($ = (de = 0 | ($ = be / (W = 4294967296))) * W);
    be = void 0;
    $ = de;
    var R = 255 & (T = $ >> 24);
    var pe = 255 & (T = $ >> 16);
    var oe = 255 & (T = $ >> 8);
    (de = []).push(R, pe, oe, T = 255 & $);
    be = de;
    $ = be;
    be = void 0;
    de = W;
    W = [];
    R = 255 & (T = de >> 24);
    pe = 255 & (T = de >> 16);
    oe = 255 & (T = de >> 8);
    T = 255 & de;
    W.push(R, pe, oe, T);
    W = be = W;
    be = $.concat(W);
    W = O = be;
    (O = []).push(0, 0);
    be = O;
    O = (O = []).concat(be);
    de = void 0;
    pe = 255 & (R = (T = $ = 227) >> 8);
    ($ = []).push(pe, R = 255 & T);
    $ = de = $;
    O = (O = O.concat($)).concat(be);
    $ = W.slice(6);
    O = O.concat($);
    $ = void 0;
    de = 71;
    W = (T = W).slice(6);
    T = W[0] + de;
    W[0] = 255 & T;
    T = W[1] + de;
    W[1] = 255 & T;
    W = $ = W;
    O = (O = O.concat(W)).concat(be);
    return O
}

function get_cs_be_3() {
    var be_3 = [1, 0, 1, 0, 1, 0, 1];
    //zh-CN 转换而来，写死
    be_3 = be_3.concat([5, 122, 104, 45, 67, 78]);
    //----------------------------------------
    be_3 = be_3.concat([1, 0, 1, 0, 0, 0, 1]);
    //此处为S[1]
    // be_3 = be_3.concat([92, 3, 65, 128, 7, 150, 2, 0, 7, 67, 70, 0, 10, 67, 70, 0, 6, 67, 68, 0, 6, 65, 66, 136, 0, 29, 65, 68, 0, 26, 65, 68, 4, 5, 65, 69, 0, 3, 65, 66, 0, 14, 0, 65, 0, 4, 0, 66, 5, 119, 69, 85, 0, 3, 65, 0, 0, 7, 0, 65, 0, 254, 25, 0, 1, 0, 9, 0, 7, 0, 8, 3, 7, 4, 8, 3, 9, 3, 8, 2, 9, 0, 10, 3, 6, 0, 4, 4, 7, 0, 8, 4, 7, 0, 8, 1, 4, 0, 9, 2, 4, 0, 7, 1, 4, 0, 10, 1, 1, 4, 11, 0, 2, 0, 171, 1, 1, 0, 3, 1, 0, 66, 0, 15, 0, 66, 0, 8, 1, 65, 0, 8, 0, 65, 0, 8, 0, 65, 0, 9, 0, 65, 0, 8, 0, 66, 0, 7, 0, 65, 0, 9, 0, 65, 0, 7, 0, 66, 0, 8, 0, 66, 0, 8, 0, 65, 0, 8, 0, 65, 0, 9, 0, 65, 0, 40, 0, 65, 0, 159, 3, 0, 1, 0, 10, 1, 6, 0, 6, 1, 6, 4, 9, 2, 7, 0, 8, 1, 7, 0, 8, 1, 5, 0, 8, 1, 6, 0, 10, 0, 4, 0, 5, 0, 4, 0, 9, 0, 3, 0, 8, 0, 1, 0, 7, 1, 3, 0, 8, 0, 3, 0, 8, 0, 2, 0, 11, 0, 3, 0, 6, 0, 3, 0, 8, 0, 3, 0, 7, 1, 2, 0, 8, 0, 2, 0, 8, 1, 2, 0, 8, 0, 2, 0, 9, 0, 3, 0, 8, 0, 3, 0, 8, 0, 1, 0, 7, 0, 1, 0, 11, 1, 2, 0, 6, 0, 1, 0, 7, 0, 1, 0, 9, 0, 1, 230, 0, 39, 65, 2, 0, 7, 0, 1, 0, 8, 65, 0, 0, 9, 0, 1, 0, 8, 0, 1, 0, 11, 0, 1, 0, 4, 0, 1, 0, 13, 65, 1, 0, 3, 0, 2, 0, 9, 65, 1, 0, 7, 0, 1, 0, 10, 0, 2, 0, 6, 65, 1, 0, 9, 0, 1, 0, 8, 0, 1, 0, 7, 65, 0, 0, 8, 0, 2, 0, 48, 0, 1]);
    be_3 = be_3.concat(GD[1]);
    //----------------------------------------
    O = void 0;
    de = [30, 4, 300, 6, 0, 'cn', 14, undefined, 1, 200, 1, 1, 30, 4];
    var T = ($ = ve)[3];
    var P = 1;
    li = T ? 705 : 16899;
    while (li != 'lxl') {
        // console.log(li);
        var gi = li >> 5,
            Ci = 31 & gi,
            mi = 31 & gi >> 5;
        switch (31 & li) {
            case 0:
                switch (Ci) {
                    case 0:
                        switch (mi) {
                            case 2:
                                m = C = x = B + 1,
                                    z.push(j),
                                    j = void 0,
                                    li = (x = (C = 0 | (x = C = b - k)) < 16384) ? 20739 : 9954
                                break;
                            default:
                                console.log('0-0');
                                break;
                        }
                        break;
                    case 1:
                        switch (mi) {
                            case 17:
                                y = M = [E],
                                    li = 15968
                                break;
                            default:
                                console.log('0-1');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 21:
                                J = 128 + (M = E % 128),
                                    M = 127 & (V = (ee = E - M) / 128),
                                    (ee = []).push(J, M),
                                    y = ee,
                                    li = 15968
                                break;
                            default:
                                console.log('0-14');
                                break;
                        }
                        break;
                    case 18:
                        switch (mi) {
                            case 23:
                                C = x = [m],
                                    li = 7203
                                break;
                            default:
                                console.log('0-18');
                                break;
                        }
                        break;
                    case 19:
                        switch (mi) {
                            case 15:
                                j = B = y,
                                    li = 26403
                                break;
                            case 21:
                                C = T[f],
                                    b = C[1],
                                    j = $[48],
                                    x = j[m = b % 7],
                                    j = x ^ C[2],
                                    m = x ^ C[0],
                                    C = void 0,
                                    x = $,
                                    y = m,
                                    li = 26692
                                break;
                            default:
                                console.log('0-19');
                                break;
                        }
                        break;
                    case 25:
                        switch (mi) {
                            case 27:
                                B = 127 & C,
                                    li = (C >>= 7) ? 3397 : 22561
                                break;
                            default:
                                console.log('0-25');
                                break;
                        }
                        break;
                }
                break;
            case 1:
                switch (Ci) {
                    case 1:
                        switch (mi) {
                            case 22:
                                y.push(B),
                                    li = C ? 19940 : 11874
                                break;
                            default:
                                console.log('1-1');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 22:
                                z = [],
                                    k = 0,
                                    S = 0,
                                    li = 11522
                                break;
                            default:
                                console.log('1-9');
                                break;
                        }
                        break;
                    case 20:
                        switch (mi) {
                            case 20:
                                li = (E = -1 === (B = E)) ? 13666 : 2048
                                break;
                            default:
                                console.log('1-20');
                                break;
                        }
                        break;
                    case 22:
                        switch (mi) {
                            case 0:
                                z = de[3],
                                    f = T.length - z,
                                    li = (z = f < 0) ? 28292 : 22817
                                break;
                            default:
                                console.log('1-22');
                                break;
                        }
                        break;
                }
                break;
            case 2:
                switch (Ci) {
                    case 8:
                        switch (mi) {
                            case 11:
                                li = f < T.length ? 22112 : 14405
                                break;
                            default:
                                console.log('2-8');
                                break;
                        }
                        break;
                    case 17:
                        switch (mi) {
                            case 15:
                                B = V.indexOf(ee),
                                    E = B,
                                    li = 21121
                                break;
                            default:
                                console.log('2-17');
                                break;
                        }
                        break;
                    case 19:
                        switch (mi) {
                            case 11:
                                li = 11524
                                break;
                            default:
                                console.log('2-19');
                                break;
                        }
                        break;
                    case 23:
                        switch (mi) {
                            case 9:
                                y = [],
                                    li = 28448
                                break;
                            default:
                                console.log('2-23');
                                break;
                        }
                        break;
                }
                break;
            case 3:
                switch (Ci) {
                    case 1:
                        switch (mi) {
                            case 7:
                                j = C,
                                    z = z.concat(j),
                                    k = b,
                                    S++,
                                    li = 3492
                                break;
                            default:
                                console.log('3-1');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 20:
                                y = void 0,
                                    li = (B = (E = 0 | (B = C)) < 128) ? 17440 : 21952
                                break;
                            default:
                                console.log('3-8');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 27:
                                f = C = [S],
                                    li = 8708
                                break;
                            default:
                                console.log('3-16');
                                break;
                        }
                        break;
                    case 25:
                        switch (mi) {
                            case 25:
                                C = j,
                                    z = z.concat(C),
                                    C = void 0,
                                    li = (j = (m = 0 | (j = m)) < 128) ? 24128 : 24869
                                break;
                            default:
                                console.log('3-25');
                                break;
                        }
                        break;
                }
                break;
            case 4:
                switch (Ci) {
                    case 2:
                        switch (mi) {
                            case 26:
                                B = x[18],
                                    E = void 0,
                                    M = 0,
                                    ee = y,
                                    li = (V = B).indexOf ? 15906 : 28482
                                break;
                            default:
                                console.log('4-2');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 11:
                                j = y,
                                    li = 26403
                                break;
                            default:
                                console.log('4-8');
                                break;
                        }
                        break;
                    case 13:
                        switch (mi) {
                            case 3:
                                f++;
                                li = (fe = (A = (P = 2 <= P) * P) > -17) ? 11522 : 21345
                                break;
                            default:
                                console.log('4-13');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 19:
                                li = 28448
                                break;
                            default:
                                console.log('4-15');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 8:
                                z = (k = f).concat(z);
                                // console.log(z.toString());
                                li = 'lxl'
                                break;
                            default:
                                console.log('4-16');
                                break;
                        }
                        break;
                    case 20:
                        switch (mi) {
                            case 27:
                                f = 0,
                                    li = 22817
                                break;
                            default:
                                console.log('4-20');
                                break;
                        }
                        break;
                }
                break;
            case 5:
                switch (Ci) {
                    case 2:
                        switch (mi) {
                            case 14:
                                f = void 0,
                                    li = (k = (S = 0 | (k = S)) < 128) ? 28163 : 5634
                                break;
                            default:
                                console.log('5-2');
                                break;
                        }
                        break;
                    case 10:
                        switch (mi) {
                            case 3:
                                B |= 128,
                                    li = 22561
                                break;
                            default:
                                console.log('5-10');
                                break;
                        }
                        break;
                }
                break;
        }
    }
    be_3 = be_3.concat([1, 1, 1, 47, 1]);
    z[z.length - 1] += 1;
    be_3 = be_3.concat(z);
    be_3 = be_3.concat([1, 14, 3, 0, 1, 0, 1, 0, 1, 2, 0]); //写死
    //此处过后大数组第18位要加一个
    return be_3
}

function get_0000(k) {
    var b = [
        "\u0000",
        "\u0001",
        "\u0002",
        "\u0003",
        "\u0004",
        "\u0005",
        "\u0006",
        "\u0007",
        "\b",
        "\t",
        "\n",
        "\u000b",
        "\f",
        "\r",
        "\u000e",
        "\u000f",
        "\u0010",
        "\u0011",
        "\u0012",
        "\u0013",
        "\u0014",
        "\u0015",
        "\u0016",
        "\u0017",
        "\u0018",
        "\u0019",
        "\u001a",
        "\u001b",
        "\u001c",
        "\u001d",
        "\u001e",
        "\u001f",
        " ",
        "!",
        "\"",
        "#",
        "$",
        "%",
        "&",
        "'",
        "(",
        ")",
        "*",
        "+",
        ",",
        "-",
        ".",
        "/",
        "0",
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        ":",
        ";",
        "<",
        "=",
        ">",
        "?",
        "@",
        "A",
        "B",
        "C",
        "D",
        "E",
        "F",
        "G",
        "H",
        "I",
        "J",
        "K",
        "L",
        "M",
        "N",
        "O",
        "P",
        "Q",
        "R",
        "S",
        "T",
        "U",
        "V",
        "W",
        "X",
        "Y",
        "Z",
        "[",
        "\\",
        "]",
        "^",
        "_",
        "`",
        "a",
        "b",
        "c",
        "d",
        "e",
        "f",
        "g",
        "h",
        "i",
        "j",
        "k",
        "l",
        "m",
        "n",
        "o",
        "p",
        "q",
        "r",
        "s",
        "t",
        "u",
        "v",
        "w",
        "x",
        "y",
        "z",
        "{",
        "|",
        "}",
        "~",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        " ",
        "¡",
        "¢",
        "£",
        "¤",
        "¥",
        "¦",
        "§",
        "¨",
        "©",
        "ª",
        "«",
        "¬",
        "­",
        "®",
        "¯",
        "°",
        "±",
        "²",
        "³",
        "´",
        "µ",
        "¶",
        "·",
        "¸",
        "¹",
        "º",
        "»",
        "¼",
        "½",
        "¾",
        "¿",
        "À",
        "Á",
        "Â",
        "Ã",
        "Ä",
        "Å",
        "Æ",
        "Ç",
        "È",
        "É",
        "Ê",
        "Ë",
        "Ì",
        "Í",
        "Î",
        "Ï",
        "Ð",
        "Ñ",
        "Ò",
        "Ó",
        "Ô",
        "Õ",
        "Ö",
        "×",
        "Ø",
        "Ù",
        "Ú",
        "Û",
        "Ü",
        "Ý",
        "Þ",
        "ß",
        "à",
        "á",
        "â",
        "ã",
        "ä",
        "å",
        "æ",
        "ç",
        "è",
        "é",
        "ê",
        "ë",
        "ì",
        "í",
        "î",
        "ï",
        "ð",
        "ñ",
        "ò",
        "ó",
        "ô",
        "õ",
        "ö",
        "÷",
        "ø",
        "ù",
        "ú",
        "û",
        "ü",
        "ý",
        "þ",
        "ÿ"
    ];
    R = "";
    be = 3;
    F = 1;
    M = 0;
    // q = 2;
    // P = '              ';
    P = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00';
    D = ' \x00\x01\x02\x03\x04\x05\x06\x07\b\t\n\v\f\r\x0E\x0F\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1A\x1B\x1C\x1D\x1E\x1F !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\x7F\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89\x8A\x8B\x8C\x8D\x8E\x8F\x90\x91\x92\x93\x94\x95\x96\x97\x98\x99\x9A\x9B\x9C\x9D\x9E\x9F ¡¢£¤¥¦§¨©ª«¬­®¯°±²³´µ¶·¸¹º»¼½¾¿ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖ×ØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõö÷øùúûüýþÿ ';
    for (let J = 0; J < k.length; J++) {
        G = 255 & k[J];
        q = 0;
        Se = 0;
        q = D.indexOf(b[G], 1);
        // console.log(q, G);
        //step 1 
        if (G != 255) {
            Ce = b[G + 1];
            be = D.indexOf(Ce, 1);
        };
        if (G == 255) {
            be = D.length - 1;
        }
        //step 2

        Se = be;
        be = (G = F - M) / D.length;
        F = M + (G = be * Se);
        M += G = be * q;
        G = D['substr'](0, Se);
        q = G + P;
        // console.log(q.toString());

        G = D['substr'](Se);
        D = q + G;
        G = F['toString'](2);
        q = G['substr'](2);
        //step3

        G = M["toString"](2);
        Se = G["substr"](2);
        G = q.split('');
        be = Se.split('');
        Se = 0;
        //step 4 
        // aa = (function anonymous() {
        //     var a = arguments;
        //     return this[a[1]] !== a[0]
        // })

        findFirstDiffPos = function(a, b) {
            var shorterLength = Math.min(a.length, b.length);

            for (var i = 0; i < shorterLength; i++)

                if (a[i] !== b[i]) return i;


                // if (a.length !== b.length) return shorterLength;
            if (a == b) return -1;

            return -1;
        }
        j = "findIndex";
        Se = findFirstDiffPos(G, be);
        //step5
        // mm = q;
        // Se = ???
        G = q["substr"](0, Se);
        // console.log(G);
        R += G;
        G = Math.pow(2, Se);
        F = (q = F * G) - (Se = 0 | q);
        M = (q = M * G) - Se;


        //step6
        // q = get_q()

        // console.log(R);
        // console.log(q);
    }

    O = M["toString"](2);
    M = O["substr"](2);
    O = M["replace"]({}, '');
    R += O;
    return R
}

function get_T(R, k_length) {
    var T = [];
    // T = [];
    for (; R.length > 0;) {
        if (R.length > 7) {
            O = R["substr"](0, 8);
            M = parseInt(O, 2);
            // console.log(M);
            T.push(M);
            R = R["substr"](8);
        } else {

            break;
        }
        // if (R.length < 8) {
        //     break;
        // }

    }

    O = "0";
    O += "000";
    R = (O = R + (M = O += "0000"))["substr"](0, 8);
    O = parseInt(R, 2);
    T.push(O);

    // console.log(T);
    oe = k_length;
    G = 128 + (P = oe % 128);
    P = 127 & (J = (F = oe - P) / 128);
    (F = []).push(G, P);
    b = F;
    F = F.concat(T);
    return F
}

function get_be_3(gd_3) {
    var T = []; //这个T是be_+be_2
    var oi = -1;
    var qe = -134217728;
    var co = "toString";
    var uo = "";
    var eo = "_0x48b3";
    var Fo = "HEAD";
    var ze = "cdc_adoQpoasnfa76pfcZLmcfl_Symbol";

    z = gd_3;
    W = [];
    li = 22336;
    while (li != 'lxl') {
        // console.log(li);
        var gi = li >> 5,
            Ci = 31 & gi,
            mi = 31 & gi >> 5;
        switch (31 & li) {
            case 0:
                switch (Ci) {
                    case 3:
                        switch (mi) {
                            case 26:
                                W = O = W;
                                O = void 0;
                                T = 0;
                                (z = ($ = W).slice()).push(0, 0, 0);
                                $ = 0;
                                f = 0;
                                li = 18500
                                break;
                            default:
                                console.log('0-3');
                                break;
                        }
                        break;
                    case 7:
                        switch (mi) {
                            case 3:
                                m = j = L,
                                    W = W.concat(m),
                                    li = 17123
                                break;
                            default:
                                console.log('0-7');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 12:
                                z = S = [k],
                                    li = 10754
                                break;
                            default:
                                console.log('0-8');
                                break;
                        }
                        break;
                    case 13:
                        switch (mi) {
                            case 8:
                                T = void 0,
                                    j = S,
                                    m = [],
                                    L = 92,
                                    B = 8,
                                    E = 0,
                                    li = 23204
                                break;
                            default:
                                console.log('0-13');
                                break;
                        }
                        break;
                    case 17:
                        switch (mi) {
                            case 1:
                                E++,
                                li = 23204
                                break;
                            default:
                                console.log('0-17');
                                break;
                        }
                        break;
                    case 26:
                        switch (mi) {
                            case 21:
                                f = 10,
                                    Y = (Oo = (A = !oi) * A) >= (A = (P = A * (qe <<= 21)) - (A = qe * qe)),
                                    k = T.slice(8, f),
                                    T = k[0] << 8,
                                    li = 18789
                                break;
                            default:
                                console.log('0-26');
                                break;
                        }
                        break;
                    case 28:
                        switch (mi) {
                            case 1:
                                li = 18724
                                break;
                            default:
                                console.log('0-28');
                                break;
                        }
                        break;
                }
                break;
            case 1:
                switch (Ci) {
                    case 1:
                        switch (mi) {
                            case 28:
                                z = void 0,
                                    li = (f = (k = 0 | (f = W)) < 128) ? 12544 : 17154
                                break;
                            default:
                                console.log('1-1');
                                break;
                        }
                        break;
                    case 5:
                        switch (mi) {
                            case 8:
                                M++,
                                li = 20868
                                break;
                            default:
                                console.log('1-5');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 22:
                                j = T = m;
                                W = W.concat(j);
                                li = 14083
                                break;
                            default:
                                console.log('1-15');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 3:
                                j = void 0,
                                    m = S,
                                    L = [],
                                    B = 2,
                                    E = 3,
                                    M = 0,
                                    li = 8961
                                break;
                            default:
                                console.log('1-16');
                                break;
                        }
                        break;
                    case 23:
                        switch (mi) {
                            case 27:
                                $ += 4,
                                    li = 24674
                                break;
                            default:
                                console.log('1-23');
                                break;
                        }
                        break;
                    case 24:
                        switch (mi) {
                            case 8:
                                li = M < m.length ? 5316 : 16869
                                break;
                            case 18:
                                li = 19 == mi ? (J = M) ? 21089 : 14082 : mi < 19 ? (A = bo >= A) ? 18500 : 4449 : (R = T) ? 484 : 22978
                                break;
                            default:
                                console.log('1-24');
                                break;
                        }
                        break;
                    case 25:
                        switch (mi) {
                            case 7:
                                j = void 0,
                                    m = S,
                                    L = [],
                                    E = B = 96735,
                                    B = 0,
                                    li = 18851
                                break;
                            default:
                                console.log('1-25');
                                break;
                        }
                        break;
                }
                break;
            case 2:
                switch (Ci) {
                    case 3:
                        switch (mi) {
                            case 24:
                                f = 1,
                                    k = $ < z.length,
                                    li = k ? 12994 : 1920
                                break;
                            default:
                                console.log('2-3');
                                break;
                        }
                        break;
                    case 6:
                        switch (mi) {
                            case 20:
                                li = f ? 28385 : 24674
                                break;
                            default:
                                console.log('2-6');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 10:
                                $ = f = z,
                                    li = 23170
                                break;
                            default:
                                console.log('2-16');
                                break;
                        }
                        break;
                    case 20:
                        switch (mi) {
                            case 22:
                                $ = (W = $).concat(O),
                                    W = [],
                                    O = void 0;
                                li = 'lxl'
                                break;
                            default:
                                console.log('2-20');
                                break;
                        }
                        break;
                    case 22:
                        switch (mi) {
                            case 12:
                                k = 226 & z[$],
                                    T += k,
                                    S = z[k = $ + 1],
                                    T += k = 226 & S,
                                    S = z[k = $ + 2],
                                    T += k = 226 & S,
                                    li = 25315
                                break;
                            default:
                                console.log('2-22');
                                break;
                        }
                        break;
                    case 24:
                        switch (mi) {
                            case 16:
                                m = 128 + (S = k % 128),
                                    S = 127 & (j = (C = k - S) / 128),
                                    (C = []).push(m, S),
                                    z = C,
                                    li = 10754
                                break;
                            default:
                                console.log('2-24');
                                break;
                        }
                        break;
                    case 25:
                        switch (mi) {
                            case 16:
                                li = $ < k ? 15813 : 26720
                                break;
                            default:
                                console.log('2-25');
                                break;
                        }
                        break;
                }
                break;
            case 3:
                switch (Ci) {
                    case 3:
                        switch (mi) {
                            case 4:
                                M = m[B],
                                    E = V = M ^ E,
                                    M = 255 & V,
                                    L.push(M),
                                    li = 4899
                                break;
                            default:
                                console.log('3-3');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 3:
                                M++,
                                li = 8961
                                break;
                            default:
                                console.log('3-9');
                                break;
                        }
                        break;
                    case 13:
                        switch (mi) {
                            case 18:
                                li = B < m.length ? 4195 : 24868
                                break;
                            case 23:
                                O = ($ = O).concat(W),
                                    W = O.length,
                                    $ = void 0,
                                    li = (T = (W = 0 | (T = W)) < 16384) ? 28705 : 6818
                                break;
                            default:
                                console.log('3-13');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 19:
                                M = L ^ j[E],
                                    M = (V = M >> B) ^ j[E],
                                    V = 255 & M,
                                    m.push(V),
                                    li = 1568
                                break;
                            default:
                                console.log('3-14');
                                break;
                        }
                        break;
                    case 23:
                        switch (mi) {
                            case 16:
                                li = (C = 3 === T) ? 8608 : 14083
                                break;
                            case 24:
                                S = z[k = $ + 3],
                                    bo = (fe = eo !== ze) * fe,
                                    T += k = 226 & S,
                                    A = (fe *= A = !Fo) - (Y = A * A),
                                    li = 19201
                                break;
                            default:
                                console.log('3-23');
                                break;
                        }
                        break;
                    case 24:
                        switch (mi) {
                            case 13:
                                $++,
                                li = 17186
                                break;
                            default:
                                console.log('3-24');
                                break;
                        }
                        break;
                    case 25:
                        switch (mi) {
                            case 4:
                                B++,
                                li = 18851
                                break;
                            default:
                                console.log('3-25');
                                break;
                        }
                        break;
                }
                break;
            case 4:
                switch (Ci) {
                    case 2:
                        switch (mi) {
                            case 18:
                                li = 20674
                                break;
                            default:
                                console.log('4-2');
                                break;
                        }
                        break;
                    case 6:
                        switch (mi) {
                            case 5:
                                V = m[M] - B,
                                    V = 255 & (J = (re = (J = 255 & V) >> (V = E)) + (V = J << (ke = 8 - V))),
                                    L.push(V),
                                    li = 3363
                                break;
                            default:
                                console.log('4-6');
                                break;
                        }
                        break;
                    case 8:
                        switch (mi) {
                            case 24:
                                f = T,
                                    T = Math,
                                    $ = z.length / 2,
                                    k = Math['ceil']($),
                                    $ = 0,
                                    li = 17186
                                break;
                            default:
                                console.log('4-8');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 18:
                                $ = 65535 & T,
                                    T = void 0,
                                    k = 255 & (f = (z = $) >> 8),
                                    ($ = []).push(k, f = 255 & z),
                                    O = $ = T = $,
                                    li = 23971
                                break;
                            case 24:
                                m = j = L,
                                    W = W.concat(m),
                                    li = 27749
                                break;
                            default:
                                console.log('4-9');
                                break;
                        }
                        break;
                    case 12:
                        switch (mi) {
                            case 20:
                                li = M < m.length ? 12804 : 3296
                                break;
                            default:
                                console.log('4-12');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 13:
                                li = (C = 2 === T) ? 197 : 17123
                                break;
                            default:
                                console.log('4-14');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 12:
                                V = m[M],
                                    li = (J = (V += J = B - 1) >= E) ? 133 : 11653
                                break;
                            default:
                                console.log('4-16');
                                break;
                        }
                        break;
                    case 21:
                        switch (mi) {
                            case 22:
                                li = E < j.length ? 19907 : 23009
                                break;
                            default:
                                console.log('4-21');
                                break;
                        }
                        break;
                }
                break;
            case 5:
                switch (Ci) {
                    case 3:
                        switch (mi) {
                            case 27:
                                li = (C = 1 === T) ? 3585 : 13764
                                break;
                            default:
                                console.log('5-3');
                                break;
                        }
                        break;
                    case 4:
                        switch (mi) {
                            case 0:
                                V %= E,
                                    li = 11653
                                break;
                            default:
                                console.log('5-4');
                                break;
                        }
                        break;
                    case 6:
                        switch (mi) {
                            case 0:
                                j = void 0,
                                    m = S,
                                    L = [],
                                    B = 263,
                                    E = 256,
                                    M = 0,
                                    li = 20868
                                break;
                            default:
                                console.log('5-6');
                                break;
                        }
                        break;
                    case 11:
                        switch (mi) {
                            case 18:
                                f = T | k[1],
                                    T = f[co](),
                                    k = T.split(uo),
                                    T = void 0,
                                    f = k,
                                    S = (k = 436559119) % f.length,
                                    k = f[S],
                                    T = f = k % 4,
                                    li = Y ? 24836 : 9538
                                break;
                            default:
                                console.log('5-11');
                                break;
                        }
                        break;
                    case 12:
                        switch (mi) {
                            case 11:
                                L.push(V),
                                    li = 8353
                                break;
                            default:
                                console.log('5-12');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 15:
                                T = 2 * $,
                                    C = 2 + (S = 2 * $),
                                    S = z.slice(T, C),
                                    li = (C = 0 == (T = (j = (T = 4 * f) + (C = $ % 4)) % 4)) ? 7969 : 27749
                                break;
                            default:
                                console.log('5-14');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 16:
                                m = j = L;
                                W = W.concat(m);
                                li = 13764
                                break;
                            default:
                                console.log('5-15');
                                break;
                        }
                        break;
                }
                break;
        }
    }
    return $
}

function get_be_4(pre_url, t1, t2) {
    // ve = ve_2;
    //先写死
    var be_4 = [1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 1, 247, 15, 254, 230, 127, 1, 0, 1, 0, 1];
    // var mm = [Math.floor(Math.random() * (17000 - 15000 + 1)) + 15000, Math.floor(Math.random() * (35000 - 29000 + 1)) + 29000];
    var mm = [t1, t2];
    var z = [mm.length];
    for (var i = 0; i < mm.length; i++) {
        S = mm[i];
        if (!(mm[i] < 16384)) {
            while (S) {
                L = 127 & S;
                S >>= 7;
                if (!S) {
                    // m.push(L);
                    z.push(L);
                    break;
                }
                L |= 128;
                // m.push(L);
                z.push(L);
            }
        } else {
            B = mm[i];
            V = (M = B - (E = B % 128)) / 128;
            (M = []).push(J = E + 128, E = 127 & V);
            z = z.concat(M);
        }
    }
    // be_4 = be_4.concat([1, 146, 233, 10, 1, 254, 1]); //前几位位随机，先写死
    be_4 = be_4.concat(z);
    //------------------------------------------------
    be_4 = be_4.concat([1, 0, 1, 0]);
    //umidtoken转换而来
    generateRandomArray = function(length, min, max) {
        var arr = [51, 71, 50];

        for (var i = 0; i < length; i++) {
            var randomValue = Math.floor(Math.random() * (max - min + 1)) + min;
            arr.push(randomValue);
        }

        return arr;
    }

    // var randomArray = generateRandomArray(49, 48, 70);
    // console.log(randomArray);
    str_to_num = function(str, step) {
        var S = [];
        for (var i = 0; i < str.length;) {
            A = str.charCodeAt(i);
            f = 255 & A;
            S.push(f);
            i += step;
        };
        return S
    };

    // be_4 = be_4.concat([51, 71, 50, 66, 49, 54, 65, 68, 52, 48, 57, 53, 69, 70, 70, 56, 65, 50, 66, 55, 53, 50, 67, 48, 51, 65, 56, 65, 51, 57, 56, 55, 67, 55, 54, 66, 53, 68, 51, 49, 53, 65, 53, 49, 55, 53, 48, 65, 68, 55, 69, 60]);
    be_4 = be_4.concat(generateRandomArray(49, 47, 70));
    // be_4.push(51);
    // be_4 = be_4.concat(str_to_num('GDC06C2779A66DA7FBF1B0CF4D1CA9A070D6F5C70DB033BEB4C', 1));
    //------------------------------------------------
    be_4 = be_4.concat([1, 0, 1, 1, 1, 0, 1]);
    //先写死
    be_4 = be_4.concat([133, 126, 73, 16]); //先写死 随机截取代码操作
    //------------------------------------------------
    // be_4 = be_4.concat([0, 1, 14, 197, 11, 5, 155, 2, 5, 11, 5, 6, 5, 74, 6, 95, 6, 24, 6, 112, 6, 93, 6, 30, 6, 162, 1, 6, 102, 6, 121, 6, 9, 6, 1, 0, 1, 1]);  //与无感差异点
    // be_4 = be_4.concat([1, 0, 1, 0, 1, 0, 1]); //先写死
    be_4 = be_4.concat([1, 0, 1, 1, 160, 1, 3, 1, 0, 1])
        // be_4 = be_4.concat([0, 1, 0, 1, 0, 1]);
    be_4 = be_4.concat(z);
    be_4 = be_4.concat([1, 0, 0, 0, 0, 1]);
    be_4 = be_4.concat([4, 5, 1, 0, 4, 6, 1, 1, 4, 7, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 4, 3, 1, 0, 4, 8, 4, 9, 4, 10, 255, 1]); //与be_1要保持一致
    be_4 = be_4.concat([0, 100, 1, 1]);
    str_1 = '    at HTMLDocument.s (https://g.alicdn.com/AWSC/nc/1.94.0/nc.js:1:36209)';
    // str_2 = '    at https://g.alicdn.com/AWSC/nc/1.94.0/nc.js:1:47639';
    var gd_4 = str_to_num(str_1, 1);
    gd_4 = [gd_4.length].concat(gd_4);
    gd_4 = gd_4.concat(gd_4);
    //35由#转变而来
    gd_4.push(1, 1, 35);
    be_4 = be_4.concat(gd_4);
    be_4.push(1);
    var get_nounce = function() {
        var Be = Math.random();
        var Ie = Be["toString"](36)
        Be = Ie["substring"](2);
        Ie = Math.random();
        Te = Ie["toString"](36);
        Ie = Te["substring"](2);
        var arr_6 = Be + Ie;
        // console.log(arr_64);
        return arr_6
    };
    var a = [
        'Chrome',
        '120.0.0.0',
        '',
        // 'nc_1__scale_text',
        'nc_1_n1z',
        '0.01+running',
        '0',
        '[object Window]',
        '0|0',
        '1|1|1|1|1|1|1|1|1|1|1',
        'noid',
        // 'nx0ci496gw99o0f6bopl6',
        get_nounce(),
        'Google Inc. (NVIDIA)',
        'ANGLE (NVIDIA, NVIDIA GeForce RTX 2060 (0x00001E89) Direct3D11 vs_5_0 ps_5_0, D3D11)',
        // 'https://login.taobao.com//newlogin/login.do/_____tmd_____/punish?x5secdata=xd670762b406ebd2c9afe5a1607eaaeca8c0e0ef17a804759c170',
        pre_url,
        'i=10596));break;case 9:void(14==mi?(F=te[_],li=F?4320:16737):mi<14?6==mi?',
    ];

    var Re = [0];
    for (var i = 0; i < a.length; i++) {
        Re = Re.concat(str_to_num(a[i], 1));
        Re.push(0);
    };

    je = 128 + (_e = Re.length % 128);
    _e = 127 & (ue = (L = Re.length - _e) / 128);
    (L = []).push(je, _e);
    Re = L.concat(Re);
    be_4 = be_4.concat(Re);
    W = be_4;
    var be = [];
    // var ve = [];
    var Q = void 0;
    // var T = ve; //97位大数组
    var T = [];

    function anonymous() {
        var a = arguments;
        return this[a[1]] !== a[0]
    }

    var ve = 30;
    var oe = (R = W).slice();
    var K = "substr";
    var z = "toString";
    var G = "findIndex";
    var co = "toString";
    var uo = "";
    var he = "";
    var Ie = "replace";
    var fe = 268435456;
    var hi = "userAgent";
    var vo = " ";
    var de = "00000000";
    var Oo = false;
    var y = '\x00\x01\x02\x03\x04\x05\x06\x07\b\t\n\v\f\r\x0E\x0F\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1A\x1B\x1C\x1D\x1E\x1F !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\x7F\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89\x8A\x8B\x8C\x8D\x8E\x8F\x90\x91\x92\x93\x94\x95\x96\x97\x98\x99\x9A\x9B\x9C\x9D\x9E\x9F ¡¢£¤¥¦§¨©ª«¬­®¯°±²³´µ¶·¸¹º»¼½¾¿ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖ×ØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõö÷øùúûüýþÿ';
    var d = [
        "\u0000",
        "\u0001",
        "\u0002",
        "\u0003",
        "\u0004",
        "\u0005",
        "\u0006",
        "\u0007",
        "\b",
        "\t",
        "\n",
        "\u000b",
        "\f",
        "\r",
        "\u000e",
        "\u000f",
        "\u0010",
        "\u0011",
        "\u0012",
        "\u0013",
        "\u0014",
        "\u0015",
        "\u0016",
        "\u0017",
        "\u0018",
        "\u0019",
        "\u001a",
        "\u001b",
        "\u001c",
        "\u001d",
        "\u001e",
        "\u001f",
        " ",
        "!",
        "\"",
        "#",
        "$",
        "%",
        "&",
        "'",
        "(",
        ")",
        "*",
        "+",
        ",",
        "-",
        ".",
        "/",
        "0",
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        ":",
        ";",
        "<",
        "=",
        ">",
        "?",
        "@",
        "A",
        "B",
        "C",
        "D",
        "E",
        "F",
        "G",
        "H",
        "I",
        "J",
        "K",
        "L",
        "M",
        "N",
        "O",
        "P",
        "Q",
        "R",
        "S",
        "T",
        "U",
        "V",
        "W",
        "X",
        "Y",
        "Z",
        "[",
        "\\",
        "]",
        "^",
        "_",
        "`",
        "a",
        "b",
        "c",
        "d",
        "e",
        "f",
        "g",
        "h",
        "i",
        "j",
        "k",
        "l",
        "m",
        "n",
        "o",
        "p",
        "q",
        "r",
        "s",
        "t",
        "u",
        "v",
        "w",
        "x",
        "y",
        "z",
        "{",
        "|",
        "}",
        "~",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        " ",
        "¡",
        "¢",
        "£",
        "¤",
        "¥",
        "¦",
        "§",
        "¨",
        "©",
        "ª",
        "«",
        "¬",
        "­",
        "®",
        "¯",
        "°",
        "±",
        "²",
        "³",
        "´",
        "µ",
        "¶",
        "·",
        "¸",
        "¹",
        "º",
        "»",
        "¼",
        "½",
        "¾",
        "¿",
        "À",
        "Á",
        "Â",
        "Ã",
        "Ä",
        "Å",
        "Æ",
        "Ç",
        "È",
        "É",
        "Ê",
        "Ë",
        "Ì",
        "Í",
        "Î",
        "Ï",
        "Ð",
        "Ñ",
        "Ò",
        "Ó",
        "Ô",
        "Õ",
        "Ö",
        "×",
        "Ø",
        "Ù",
        "Ú",
        "Û",
        "Ü",
        "Ý",
        "Þ",
        "ß",
        "à",
        "á",
        "â",
        "ã",
        "ä",
        "å",
        "æ",
        "ç",
        "è",
        "é",
        "ê",
        "ë",
        "ì",
        "í",
        "î",
        "ï",
        "ð",
        "ñ",
        "ò",
        "ó",
        "ô",
        "õ",
        "ö",
        "÷",
        "ø",
        "ù",
        "ú",
        "û",
        "ü",
        "ý",
        "þ",
        "ÿ"
    ];
    var ee = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00';
    li = 16515;
    while (li != 'lxl') {
        // console.log(li);
        var gi = li >> 5,
            Ci = 31 & gi,
            mi = 31 & gi >> 5;
        switch (31 & li) {
            case 0:
                switch (Ci) {
                    case 2:
                        switch (mi) {
                            case 5:
                                R = k = f,
                                    li = (bo = (P = (fe = fe < 15) * fe) > (Y = (A = 215 | (bo = !hi)) << 25)) ? 1349 : 14688
                                break;
                            default:
                                console.log('0-2');
                                break;
                        }
                        break;
                    case 3:
                        switch (mi) {
                            case 23:
                                Ge = z[Le],
                                    f = 255 & (Ge = (f = Ge >> G) + (k = Ge << he)),
                                    Ie.push(f),
                                    li = 8548
                                break;
                            default:
                                console.log('0-3');
                                break;
                        }
                        break;
                    case 10:
                        switch (mi) {
                            case 6:
                                f = void 0,
                                    li = (k = (S = 0 | (k = O)) < 128) ? 13984 : 25029
                                break;
                            default:
                                console.log('0-10');
                                break;
                        }
                        break;
                    case 12:
                        switch (mi) {
                            case 24:
                                Le++,
                                li = 24005
                                break;
                            default:
                                console.log('0-12');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 16:
                                li = 8739
                                break;
                            default:
                                console.log('0-15');
                                break;
                        }
                        break;
                    case 19:
                        switch (mi) {
                            case 18:
                                I = f.length - 1,
                                    li = 7685
                                break;
                            default:
                                console.log('0-19');
                                break;
                        }
                        break;
                    case 20:
                        switch (mi) {
                            case 1:
                                Q = void 0,
                                    K = R,
                                    z = [],
                                    G = 181,
                                    he = 5,
                                    Ie = 0,
                                    li = 28514
                                break;
                            case 25:
                                Pe = ve = W,
                                    ve = void 0,
                                    W = 0,
                                    (O = (Q = Pe).slice()).push(0, 0, 0),
                                    Q = 0,
                                    de = 0;
                                li = 22724
                                break;
                            default:
                                console.log('0-20');
                                break;
                        }
                        break;
                    case 21:
                        switch (mi) {
                            case 8:
                                li = de ? 3237 : 483
                                break;
                            default:
                                console.log('0-21');
                                break;
                        }
                        break;
                    case 22:
                        switch (mi) {
                            case 19:
                                z = K = Ie,
                                    W = W.concat(z),
                                    li = 19650
                                break;
                            default:
                                console.log('0-22');
                                break;
                        }
                        break;
                    case 23:
                        switch (mi) {
                            case 28:
                                K = void 0,
                                    z = R,
                                    G = 3,
                                    he = 5,
                                    Ie = [],
                                    Le = 0,
                                    li = 1316
                                break;
                            default:
                                console.log('0-23');
                                break;
                        }
                        break;
                    case 27:
                        switch (mi) {
                            case 6:
                                Ie++,
                                li = 28514
                                break;
                            default:
                                console.log('0-27');
                                break;
                        }
                        break;
                    case 28:
                        switch (mi) {
                            case 14:
                                R = T % de.length,
                                    T = de[R],
                                    de = Pe = de = T % 4,
                                    Pe = Math,
                                    Q = O.length / 2,
                                    T = Pe['ceil'](Q),
                                    Pe = 0,
                                    li = 23010
                                break;
                            default:
                                console.log('0-28');
                                break;
                        }
                        break;
                }
                break;
            case 1:
                switch (Ci) {
                    case 0:
                        switch (mi) {
                            case 12:
                                li = 1381
                                break;
                            case 18:
                                ve = (Q = ve = Q).concat(Pe),
                                    Pe = ve.length,
                                    Q = void 0,
                                    li = (W = (Pe = 0 | (W = Pe)) < 16384) ? 20546 : 28386
                                break;
                            default:
                                console.log('1-0');
                                break;
                        }
                        break;
                    case 3:
                        switch (mi) {
                            case 2:
                                b = 255 & oe[C],
                                    j = 0,
                                    w = 0,
                                    j = f.indexOf(Ge[b], 1),
                                    li = (I = 255 === b) ? 19040 : 4321
                                break;
                            case 27:
                                li = Le < z.length ? 8035 : 20160
                                break;
                            default:
                                console.log('1-3');
                                break;
                        }
                        break;
                    case 6:
                        switch (mi) {
                            case 13:
                                Pe++,
                                li = 23010
                                break;
                            default:
                                console.log('1-6');
                                break;
                        }
                        break;
                    case 7:
                        switch (mi) {
                            case 4:
                                D = Ge[m = b + 1],
                                    I = f.indexOf(D, 1),
                                    li = 7685
                                break;
                            default:
                                console.log('1-7');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 17:
                                li = (oe = 1 === Q) ? 27717 : 19650
                                break;
                            default:
                                console.log('1-9');
                                break;
                        }
                        break;
                    case 22:
                        switch (mi) {
                            case 8:
                                m = anonymous,
                                    li = 8578
                                break;
                            default:
                                console.log('1-22');
                                break;
                        }
                        break;
                    case 26:
                        switch (mi) {
                            case 8:
                                Y |= 7,
                                    T = 100 & O[Q],
                                    qe = (Oo = Y * Y) > -13,
                                    W += T,
                                    R = O[T = Q + 1],
                                    W += T = 100 & R,
                                    T = Q + 2,
                                    li = 26243
                                break;
                            default:
                                console.log('1-26');
                                break;
                        }
                        break;
                    case 27:
                        switch (mi) {
                            case 6:
                                Ge = z[Le],
                                    Ge = 255 & (f = (Ge = (f = Ge >> he) + (S = Ge << (k = 8 - he))) + Ie),
                                    G.push(Ge),
                                    li = 24960
                                break;
                            default:
                                console.log('1-27');
                                break;
                        }
                        break;
                }
                break;
            case 2:
                switch (Ci) {
                    case 2:
                        switch (mi) {
                            case 20:
                                O = void 0,
                                    li = (de = (T = 0 | (de = Pe)) < 128) ? 5954 : 13090
                                break;
                            default:
                                console.log('2-2');
                                break;
                        }
                        break;
                    case 6:
                        switch (mi) {
                            case 19:
                                li = (oe = 2 === Q) ? 11589 : 8421
                                break;
                            default:
                                console.log('2-6');
                                break;
                        }
                        break;
                    case 10:
                        switch (mi) {
                            case 24:
                                C++,
                                li = 23266
                                break;
                            default:
                                console.log('2-10');
                                break;
                        }
                        break;
                    case 12:
                        switch (mi) {
                            case 8:
                                li = (D = m) ? 29316 : 8034
                                break;
                            default:
                                console.log('2-12');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 22:
                                li = Pe < T ? 9732 : 26240
                                break;
                            default:
                                console.log('2-15');
                                break;
                        }
                        break;
                    case 23:
                        switch (mi) {
                            case 22:
                                li = C < oe.length ? 2145 : 1187
                                break;
                            default:
                                console.log('2-23');
                                break;
                        }
                        break;
                    case 24:
                        switch (mi) {
                            case 9:
                                ve = R.length > 7,
                                    li = ve ? 4197 : 12289
                                break;
                            default:
                                console.log('2-24');
                                break;
                        }
                        break;
                    case 25:
                        switch (mi) {
                            case 12:
                                z = 128 + (R = T % 128),
                                    R = 127 & (K = (oe = T - R) / 128),
                                    (oe = []).push(z, R),
                                    O = oe,
                                    li = 25797
                                break;
                            default:
                                console.log('2-25');
                                break;
                        }
                        break;
                    case 26:
                        switch (mi) {
                            case 15:
                                Le = G ^ K[Ie],
                                    Le = (Ge = Le >> he) ^ K[Ie],
                                    Ge = 255 & Le,
                                    z.push(Ge),
                                    li = 7008
                                break;
                            default:
                                console.log('2-26');
                                break;
                        }
                        break;
                    case 27:
                        switch (mi) {
                            case 27:
                                li = Ie < K.length ? 16194 : 17156
                                break;
                            default:
                                console.log('2-27');
                                break;
                        }
                        break;
                }
                break;
            case 3:
                switch (Ci) {
                    case 4:
                        switch (mi) {
                            case 16:
                                Le = parseInt,
                                    O = R.length,
                                    R = void 0,
                                    li = (Ge = (O = 0 | (Ge = O)) < 16384) ? 6464 : 23074
                                break;
                            default:
                                console.log('3-4');
                                break;
                        }
                        break;
                    case 5:
                        switch (mi) {
                            case 1:
                                T = ve[z](2);
                                ve = T[K](2);
                                T = ve[Ie]('/0+$/', he);
                                R += T;
                                li = 25700
                                break;
                            default:
                                console.log('3-5');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 0:
                                de = 1,
                                    T = Q < O.length,
                                    li = T ? 9025 : 16864
                                break;
                            default:
                                console.log('3-15');
                                break;
                        }
                        break;
                    case 17:
                        switch (mi) {
                            case 8:
                                Q = 65535 & W,
                                    W = void 0,
                                    T = 255 & (de = (O = Q) >> 8),
                                    (Q = []).push(T, de = 255 & O),
                                    Q = W = Q,
                                    li = 18433
                                break;
                            default:
                                console.log('3-17');
                                break;
                        }
                        break;
                    case 20:
                        switch (mi) {
                            case 25:
                                R = O[T],
                                    W += T = 100 & R,
                                    li = qe ? 14852 : 28480
                                break;
                            default:
                                console.log('3-20');
                                break;
                        }
                        break;
                    case 26:
                        switch (mi) {
                            case 16:
                                z = K = Ie,
                                    W = W.concat(z),
                                    li = 17697
                                break;
                            default:
                                console.log('3-26');
                                break;
                        }
                        break;
                    case 27:
                        switch (mi) {
                            case 7:
                                Ge = z[Le],
                                    f = 255 & (Ge = (f = Ge >> G) + (k = Ge << he)),
                                    Ie.push(f),
                                    li = 28900
                                break;
                            default:
                                console.log('3-27');
                                break;
                        }
                        break;
                }
                break;
            case 4:
                switch (Ci) {
                    case 3:
                        switch (mi) {
                            case 25:
                                li = 9986
                                break;
                            default:
                                console.log('4-3');
                                break;
                        }
                        break;
                    case 6:
                        switch (mi) {
                            case 0:
                                W = [],
                                    de = 10,
                                    T = Pe.slice(8, de),
                                    Pe = T[0] << 8,
                                    de = Pe | T[1],
                                    Pe = de[co](),
                                    T = Pe.split(uo),
                                    Pe = void 0,
                                    de = T,
                                    T = 516727686,
                                    li = 15232
                                break;
                            case 22:
                                li = 8864
                                break;
                            default:
                                console.log('4-6');
                                break;
                        }
                        break;
                    case 7:
                        switch (mi) {
                            case 28:
                                Le++,
                                li = 27745
                                break;
                            default:
                                console.log('4-7');
                                break;
                        }
                        break;
                    case 9:
                        switch (mi) {
                            case 1:
                                li = Le < z.length ? 23648 : 17219
                                break;
                            default:
                                console.log('4-9');
                                break;
                        }
                        break;
                    case 11:
                        switch (mi) {
                            case 8:
                                Le++,
                                li = 1316
                                break;
                            default:
                                console.log('4-11');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 4:
                                b = S[z](2),
                                    j = b[K](2),
                                    b = ve[z](2),
                                    w = b[K](2),
                                    b = j.split(he),
                                    I = w.split(he),
                                    w = 0,
                                    m = b[G],
                                    li = m ? 8897 : 8578
                                break;
                            default:
                                console.log('4-15');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 9:
                                Q = 2 * Pe,
                                    oe = 2 + (R = 2 * Pe),
                                    R = O.slice(Q, oe),
                                    li = (oe = 0 == (Q = (K = (Q = 4 * de) + (oe = Pe % 4)) % 4)) ? 29408 : 17697
                                break;
                            case 14:
                                R = O[T = Q + 3],
                                    W += T = 100 & R,
                                    li = 22724
                                break;
                            default:
                                console.log('4-16');
                                break;
                        }
                        break;
                    case 20:
                        switch (mi) {
                            case 28:
                                w = b[G](anonymous, I);
                                li = (Oo = (bo = (Oo = 19 == Oo) * Oo) > -73) ? 2788 : 7875
                                break;
                            default:
                                console.log('4-20');
                                break;
                        }
                        break;
                    case 23:
                        switch (mi) {
                            case 2:
                                b = j[K](0, w),
                                    R += b,
                                    b = Math.pow(2, w),
                                    S = (j = S * b) - (w = 0 | j),
                                    ve = (j = ve * b) - w,
                                    li = 24898
                                break;
                            default:
                                console.log('4-23');
                                break;
                        }
                        break;
                    case 24:
                        switch (mi) {
                            case 16:
                                K = Q = z,
                                    W = W.concat(K),
                                    li = 13505
                                break;
                            default:
                                console.log('4-24');
                                break;
                        }
                        break;
                    case 27:
                        switch (mi) {
                            case 24:
                                z = K = G,
                                    bo >>= 18,
                                    Oo = 8,
                                    W = W.concat(z),
                                    li = (Oo = (fe = (Y = bo + Oo) * Y) >= (bo = 4 * (qe = bo * Oo))) ? 8421 : 10659
                                break;
                            default:
                                console.log('4-27');
                                break;
                        }
                        break;
                }
                break;
            case 5:
                switch (Ci) {
                    case 2:
                        switch (mi) {
                            case 27:
                                K = void 0,
                                    z = R,
                                    G = 7,
                                    he = 1,
                                    Ie = [],
                                    Le = 0,
                                    li = 27745
                                break;
                            default:
                                console.log('5-2');
                                break;
                        }
                        break;
                    case 3:
                        switch (mi) {
                            case 4:
                                ve = R[K](0, 8);
                                T = Le(ve, 2);
                                O.push(T);
                                R = R[K](8);
                                li = 25700
                                break;
                            default:
                                console.log('5-3');
                                break;
                        }
                        break;
                    case 5:
                        switch (mi) {
                            case 3:
                                Q += 4,
                                    li = 483
                                break;
                            default:
                                console.log('5-5');
                                break;
                        }
                        break;
                    case 6:
                        switch (mi) {
                            case 25:
                                Q = de = O,
                                    li = 25957
                                break;
                            default:
                                console.log('5-6');
                                break;
                        }
                        break;
                    case 7:
                        switch (mi) {
                            case 8:
                                li = (oe = 3 === Q) ? 1664 : 13505
                                break;
                            default:
                                console.log('5-7');
                                break;
                        }
                        break;
                    case 10:
                        switch (mi) {
                            case 1:
                                O = R,
                                    R = he,
                                    f = (Ge = vo + y) + vo,
                                    Ge = d,
                                    k = ee[K](0, ve),
                                    ve = 0,
                                    S = 1,
                                    C = 0,
                                    li = 23266
                                break;
                            case 11:
                                K = void 0,
                                    z = R,
                                    G = [],
                                    he = 6,
                                    Ie = 17961,
                                    Le = 0,
                                    li = 24005
                                break;
                            default:
                                console.log('5-10');
                                break;
                        }
                        break;
                    case 11:
                        switch (mi) {
                            case 1:
                                de = (ve = R + de)[K](0, 8);
                                ve = Le(de, 2),
                                    O.push(ve),
                                    W = Q = O,
                                    ve = void 0,
                                    Pe = be,
                                    O = W,
                                    li = 196
                                break;
                            case 25:
                                Q = (Pe = Q).concat(ve);
                                li = 'lxl'
                                break;
                            default:
                                console.log('5-11');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 23:
                                li = Le < z.length ? 7009 : 25444
                                break;
                            case 24:
                                w = 128 + (C = S % 128),
                                    C = 127 & (j = (b = S - C) / 128),
                                    (b = []).push(w, C),
                                    f = b,
                                    li = 5184
                                break;
                            default:
                                console.log('5-14');
                                break;
                        }
                        break;
                    case 16:
                        switch (mi) {
                            case 7:
                                w = I,
                                    I = (b = S - ve) / f.length,
                                    S = ve + (b = I * w),
                                    ve += b = I * j,
                                    b = f[K](0, w),
                                    j = b + k,
                                    b = f[K](w),
                                    f = j + b,
                                    li = 4580
                                break;
                            default:
                                console.log('5-16');
                                break;
                        }
                        break;
                }
                break;
        }
    };
    be_4 = Q;
    return be_4;
}



function deal_be(be) {
    be[1] = 4;
    be[4] = 255 & ((be.length - 12) >> 8);
    be[5] = 255 & (be.length - 12);
    var uo = '';
    var Pe = be.slice(12);
    var ve = void 0,
        Q = Pe,
        Pe = 0,
        W = 0,
        li = 5604;
    // var li = 8420;
    while (li != 'lxl') {
        var gi = li >> 5,
            Ci = 31 & gi,
            mi = 31 & gi >> 5;
        // console.log(li);
        switch (31 & li) {
            case 0:
                switch (Ci) {
                    case 12:
                        switch (mi) {
                            case 7:
                                W++,
                                li = 5604
                                break;
                            default:
                                console.log('0-12');
                                break;
                        }
                        break;
                }
                break;
            case 3:
                switch (Ci) {
                    case 15:
                        switch (mi) {
                            case 21:
                                Q = void 0,
                                    $ = 255 & (O = (W = Pe) >> 8),
                                    (Pe = []).push($, O = 255 & W),
                                    ve = Pe = Q = Pe,
                                    li = 11
                                break;
                            case 27:
                                li = ji < 2 ? 9380 : 6020
                                break;
                            default:
                                console.log('3-15');
                                break;
                        }
                        break;
                }
                break;
            case 4:
                switch (Ci) {
                    case 5:
                        switch (mi) {
                            case 9:
                                be[ve = 10 + ji] = Pe[ji],
                                    li = 20196
                                break;
                            default:
                                console.log('4-5');
                                break;
                        }
                        break;
                    case 7:
                        switch (mi) {
                            case 8:
                                O = 71 & Q[W],
                                    Pe = 65535 & ($ = Pe + O),
                                    li = 7552
                                break;
                            default:
                                console.log('4-7');
                                break;
                        }
                        break;
                    case 15:
                        switch (mi) {
                            case 5:
                                li = W < Q.length ? 8420 : 21987;
                                break;
                            default:
                                console.log('4-15');
                                break;
                        }
                        break;
                    case 23:
                        switch (mi) {
                            case 19:
                                ji++,
                                li = 28131
                                break;
                            default:
                                console.log('4-23');
                                break;
                        }
                        break;
                    case 28:
                        switch (mi) {
                            case 5:
                                // 停止点
                                li = 'lxl'
                                    // ve = Pe = Z = be,
                                    //     li = le[11] ? 11588 : 22144
                                break;
                            default:
                                console.log('4-28');
                                break;
                        }
                        break;
                }
                break;
            case 11:
                Pe = ve;
                var ji = 0;
                li = 28131;
                break;
        }

    };
    // console.log(be.toString());
    return be;

}

function lxl(Z) {
    var K = "S+6s3fdKZ9I21yLDiCGJgVomYrFq5O/XU7ea0EbQMBTNuP4lhRwx8ktApzcWvjnH=";
    var z = Z.length;
    var G = 'charAt';
    li = 18723;
    var Be = false;
    var W = '';
    var oe = 0;
    while (li != 'lxl') {
        // console.log(li);
        var gi = li >> 5,
            Ci = 31 & gi,
            mi = 31 & gi >> 5;
        switch (31 & li) {
            case 0:
                switch (Ci) {
                    case 22:
                        switch (mi) {
                            case 23:
                                qe = !Be,
                                    bo = (qe *= qe) > -183,
                                    he = oe++,
                                    U = Z[he],
                                    O = 255 & U,
                                    he = oe++,
                                    U = Z[he],
                                    be = 255 & U,
                                    he = oe++,
                                    li = 10244
                                break;
                            default:
                                console.log('0-22');
                                break;
                        }
                        break;
                }
                break;
            case 1:
                switch (Ci) {
                    case 26:
                        switch (mi) {
                            case 21:
                                O = 227,
                                    A = true,
                                    be = [],
                                    $ = "00",
                                    de = (de = "!").split("").reverse().join(""),
                                    be.push($, O, de),
                                    $ = be,
                                    li = 13476
                                break;
                            default:
                                console.log('1-26');
                                break;
                        }
                        break;
                }
                break;
            case 2:
                switch (Ci) {
                    case 4:
                        switch (mi) {
                            case 24:
                                he = K[G](de),
                                    U = W + he,
                                    he = K[G](T),
                                    Ie = U + he,
                                    he = K[G](R),
                                    U = Ie + he,
                                    he = K[G](pe),
                                    W = U + he,
                                    li = 18723
                                break;
                            default:
                                console.log('2-4');
                                break;
                        }
                        break;
                    case 14:
                        switch (mi) {
                            case 25:
                                R = pe = 64,
                                    li = 24706
                                break;
                            default:
                                console.log('2-14');
                                break;
                        }
                        break;
                    case 21:
                        switch (mi) {
                            case 3:
                                li = (U = oe === he) ? 26050 : 8805
                                break;
                            default:
                                console.log('2-21');
                                break;
                        }
                        break;
                }
                break;
            case 3:
                switch (Ci) {
                    case 9:
                        switch (mi) {
                            case 18:
                                li = 11429
                                break;
                            default:
                                console.log('3-9');
                                break;
                        }
                        break;
                    case 12:
                        switch (mi) {
                            case 13:
                                li = 22337
                                break;
                            default:
                                console.log('3-12');
                                break;
                        }
                        break;
                    case 20:
                        switch (mi) {
                            case 10:
                                T = (U = (he = 3 & O) << 4) | (he = be >> 4),
                                    R = (U = (he = 15 & be) << 2) | (he = $ >> 6),
                                    pe = 63 & $,
                                    he = z + 2,
                                    li = 3746
                                break;
                            default:
                                console.log('3-20');
                                break;
                        }
                        break;

                }
                break;
            case 4:
                switch (Ci) {
                    case 0:
                        switch (mi) {
                            case 10:
                                U = Z[he],
                                    $ = 255 & U,
                                    de = O >> 2,
                                    li = bo ? 10883 : 22753
                                break;
                            default:
                                console.log('4-0');
                                break;
                        }
                        break;
                    case 5:
                        switch (mi) {
                            case 13:
                                O = $.join(""),
                                    be = O.length - 4,
                                    $ = O["substring"](be),
                                    O = $ + W;
                                li = 'lxl'
                                break;
                            default:
                                console.log('4-5');
                                break;
                        }
                        break;
                    case 25:
                        switch (mi) {
                            case 19:
                                pe = 64,
                                    li = 24706
                                break;
                            default:
                                console.log('4-25');
                                break;
                        }
                        break;

                }
                break;
            case 5:
                switch (Ci) {
                    case 5:
                        switch (mi) {
                            case 11:
                                li = (he = oe < z) ? 24256 : 13699
                                break;
                            default:
                                console.log('5-5');
                                break;
                        }
                        break;
                    case 19:
                        switch (mi) {
                            case 8:
                                li = (Ie = oe === (he = z + 1)) ? 20260 : 24706
                                break;
                            default:
                                console.log('5-19');
                                break;
                        }
                        break;
                }
                break;
        }
    };
    // O是最后参数
    return O

}



function get_227_wg(pre_url, cs_trace) {
    track_list = get_track_list(cs_trace);
    ve = get_arr_90(track_list);
    ve[18] = [5, 6];
    // ve[48] = get_time_arr8();
    // ve[48] = [0, 0, 1, 140, 82, 120, 178, 180];
    track_enc();
    GD = S;
    var be_1 = get_be_1();
    // ve[18] = [5, 6, 3, 4, 7, 8, 9, 10, 11, 12, 13, 0, 1];
    ve[18] = [5, 6, 3, 4, 7, 8, 9, 10, 11, 12, 13];
    var be_2 = [50, 17, 94, 115, 115, 81, 81, 54, 79, 16, 176, 74, 124, 133, 130, 14, 127, 184, 192, 68, 125, 81, 88, 55, 78, 235, 231, 115, 113, 80, 82, 54, 76, 231, 239, 114, 115, 80, 81, 55, 174, 235, 235, 41, 150, 239, 121, 55, 79, 24, 28];
    var be_2 = [50, 17, 94, 115, 115, 81, 81, 54, 79, 16, 176, 74, 124, 133, 130, 14, 127, 184, 192, 68, 125, 81, 88, 55, 78, 235, 231, 115, 113, 80, 82, 54, 76, 231, 239, 114, 115, 80, 81, 55, 174, 235, 235, 41, 150, 239, 121, 55, 79, 20, 24];
    be_1 = be_1.concat(be_2);
    // var S = params.enc_track;
    var W = get_cs_be_3();
    var gd_3 = get_T(get_0000(W), W.length);
    var be_3 = get_be_3(gd_3);
    be_1 = be_1.concat(be_3);
    var be_4 = get_be_4(pre_url, ve[24] + 1200, ve[24] + 1588);
    be_1 = be_1.concat(be_4);
    var token = deal_be(be_1);
    data = lxl(token);
    console.log(data);
    return data

}
pre_url = 'https://login.taobao.com//newlogin/account/check.do/_____tmd_____/punish?x5secdata=xd8d65d78e35e23219ecc11bf970f47640f62bc47d0e8'

ljr = [[54.0, 807.0, 1288111.13861389], [65.0, 807.0, 1481888.3660496064], [75.0, 806.0, 1669975.6016780934], [85.0, 806.0, 1855091.4061427373], [95.0, 806.0, 2036609.2294889707], [105.0, 806.0, 2213804.3982779626], [115.0, 806.0, 2385985.7270856956], [125.0, 805.0, 2553577.0373469535], [134.0, 805.0, 2716778.5369782536], [143.0, 805.0, 2875469.417065942], [152.0, 805.0, 3029545.0725745014], [161.0, 804.0, 3178931.505793779], [170.0, 804.0, 3323687.950900515], [178.0, 804.0, 3463835.2928931946], [187.0, 803.0, 3599358.7682384057], [194.0, 803.0, 3730261.977797956], [202.0, 802.0, 3856568.6872597774], [209.0, 802.0, 3978341.191533146], [216.0, 801.0, 4095650.0675094957], [223.0, 801.0, 4208579.21526895], [229.0, 800.0, 4317238.821182828], [235.0, 799.0, 4421766.07808601], [240.0, 798.0, 4522326.625621658], [245.0, 798.0, 4619113.469982672], [249.0, 797.0, 4712346.983911692], [253.0, 796.0, 4802278.507562909], [256.0, 795.0, 4889191.788846781], [259.0, 793.0, 4973402.983430036], [261.0, 792.0, 5055262.815252761], [262.0, 791.0, 5135156.936614578], [263.0, 789.0, 5213509.16895027], [263.0, 788.0, 5290783.663346871], [263.0, 786.0, 5367487.4211469265], [261.0, 785.0, 5444178.936016835], [259.0, 783.0, 5521473.59523956], [256.0, 781.0, 5600051.961696786], [252.0, 779.0, 5680660.494041281], [247.0, 777.0, 5764107.94583509], [241.0, 775.0, 5851240.159516879], [235.0, 773.0, 5942891.454767528], [228.0, 771.0, 6039835.656789545], [220.0, 769.0, 6142800.139668117], [212.0, 766.0, 6252512.637574613], [203.0, 764.0, 6369694.763215326], [194.0, 762.0, 6495868.240790257], [185.0, 760.0, 6633025.067051512], [177.0, 759.0, 6780997.441838845], [169.0, 757.0, 6936357.344711175], [161.0, 755.0, 7100064.765426479], [154.0, 753.0, 7271326.074042304], [147.0, 750.0, 7452065.571108771], [141.0, 748.0, 7640436.014518445], [135.0, 745.0, 7831589.924105593], [131.0, 743.0, 8024709.184067469], [130.0, 740.0, 8213773.873633699], [134.0, 739.0, 8395128.397896945], [138.0, 736.0, 8568265.755514665], [142.0, 734.0, 8734105.60659258], [146.0, 731.0, 8892069.652724354], [151.0, 728.0, 9051452.438408421], [155.0, 725.0, 9214791.851046963], [160.0, 722.0, 9371595.699504245], [165.0, 718.0, 9521816.452404402], [170.0, 714.0, 9665168.921492256], [176.0, 710.0, 9805372.797015319], [181.0, 706.0, 9943234.672018552], [187.0, 701.0, 10074439.993883781], [194.0, 696.0, 10199277.551727997], [200.0, 691.0, 10318231.301378176], [207.0, 685.0, 10432901.465821728], [214.0, 680.0, 10543676.21796154], [221.0, 674.0, 10649336.305989474], [229.0, 668.0, 10750471.551069656], [236.0, 661.0, 10847755.314360155], [244.0, 655.0, 10941529.677732715], [252.0, 648.0, 11031767.994809961], [260.0, 641.0, 11118298.864569837], [268.0, 634.0, 11201196.464765588], [276.0, 627.0, 11280472.318154994], [284.0, 620.0, 11365123.538051171], [293.0, 613.0, 11457736.983576879], [301.0, 606.0, 11550940.970439075], [309.0, 599.0, 11646849.204518972], [317.0, 592.0, 11758126.636967162], [325.0, 586.0, 11888966.111272713], [332.0, 581.0, 12032738.440847361], [340.0, 575.0, 12181912.783306157], [347.0, 570.0, 12337346.143759368], [354.0, 564.0, 12499213.524090858], [360.0, 559.0, 12666366.969556281], [367.0, 554.0, 12838551.53913964], [374.0, 548.0, 13016406.745898012], [380.0, 543.0, 13200546.176683456], [387.0, 538.0, 13389829.078475242], [394.0, 533.0, 13583049.882740099], [401.0, 528.0, 13779698.707446037], [408.0, 523.0, 13979533.574679565], [415.0, 518.0, 14182429.174449772], [422.0, 513.0, 14388005.255749745], [429.0, 508.0, 14595926.218258997], [435.0, 504.0, 14806030.743368533], [442.0, 499.0, 15018158.952814084], [449.0, 494.0, 15232188.417294182], [456.0, 489.0, 15447986.6250943], [463.0, 484.0, 15665438.348636584], [470.0, 479.0, 15884471.570684882], [477.0, 475.0, 16105020.035381924], [484.0, 470.0, 16327024.688594064], [491.0, 465.0, 16550439.439290158], [498.0, 460.0, 16775221.077128518], [505.0, 455.0, 17001340.795214675], [513.0, 450.0, 17228772.667343613], [520.0, 445.0, 17457496.528689213], [527.0, 440.0, 17687492.214425348], [534.0, 435.0, 17918751.08248368], [541.0, 430.0, 18151260.1697617], [549.0, 425.0, 18385013.71488051], [556.0, 420.0, 18620004.516116504], [563.0, 415.0, 18856228.25243551], [571.0, 410.0, 19093687.804526966], [578.0, 404.0, 19332377.41101199], [586.0, 399.0, 19572299.952580024], [593.0, 394.0, 19813453.988886345], [601.0, 389.0, 20055843.840965122], [608.0, 383.0, 20299472.3895058], [616.0, 378.0, 20544341.074853107], [624.0, 373.0, 20790455.65838593], [631.0, 368.0, 21037819.020793717], [639.0, 362.0, 21286435.48311064], [647.0, 357.0, 21536310.80671559], [655.0, 351.0, 21787450.752987456], [663.0, 346.0, 22039859.642960414], [670.0, 340.0, 22293541.79766863], [678.0, 335.0, 22548504.41883572], [686.0, 329.0, 22804753.26784057], [694.0, 324.0, 23062294.106062084], [702.0, 318.0, 23321132.694879152], [711.0, 313.0, 23581276.236015383], [719.0, 307.0, 23842730.490849677], [727.0, 301.0, 24105499.780416198], [735.0, 296.0, 24369592.746783286], [743.0, 290.0, 24635013.710985113], [752.0, 284.0, 24901771.31509002], [760.0, 278.0, 25169874.201166335], [768.0, 273.0, 25439325.249903515], [777.0, 267.0, 25710130.22268045], [785.0, 261.0, 25982297.761565477], [794.0, 255.0, 26255836.508626938], [802.0, 249.0, 26530749.34455427], [811.0, 243.0, 26807047.792105272], [820.0, 237.0, 27084734.731969383], [828.0, 231.0, 27363818.80621494], [837.0, 225.0, 27644308.656910285], [846.0, 219.0, 27926210.04543431], [855.0, 213.0, 28209528.73316591], [863.0, 207.0, 28494270.48148397], [872.0, 200.0, 28780449.693835728], [881.0, 194.0, 29068066.370221183], [890.0, 188.0, 29357126.272019226], [899.0, 182.0, 29647643.80267709], [908.0, 175.0, 29939621.84288422], [918.0, 169.0, 30233069.034708954], [927.0, 163.0, 30527991.13953019], [936.0, 156.0, 30824396.79941626], [945.0, 150.0, 31122294.65643551], [955.0, 143.0, 31421693.352656268], [964.0, 137.0, 31722592.888078544], [973.0, 130.0, 32025007.666149564], [983.0, 124.0, 32328946.328937672], [992.0, 117.0, 32634411.75713231], [1002.0, 111.0, 32941415.473491263], [1011.0, 104.0, 33249963.239393428], [1021.0, 97.0, 33560060.81621769], [1031.0, 91.0, 33871719.726721846], [1041.0, 84.0, 34184942.85159533], [1050.0, 77.0, 34499744.59428538], [1060.0, 70.0, 34816130.71617088], [1070.0, 63.0, 35134104.09794129], [1080.0, 56.0, 35453679.14304383], [1090.0, 50.0, 35774861.6128574], [1100.0, 43.0, 36097663.03013978], [1110.0, 36.0, 36422086.27558042], [1120.0, 29.0, 36748142.87193711], [1131.0, 21.0, 37075838.58058873], [1141.0, 14.0, 37405182.04360362], [1151.0, 7.0, 37736181.90305013], [1161.0, 0.0, 38068846.800996594]]













get_227_wg(pre_url, ljr)