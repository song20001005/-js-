// 获取滑块元素
var slider = document.getElementById('nc_1_n1z');

// 创建 mousedown 事件
var mouseDownEvent = new MouseEvent('mousedown', {
    bubbles: true,
    cancelable: true,
    view: window
});

// 模拟按下鼠标
slider.dispatchEvent(mouseDownEvent);

// 创建 mousemove 事件，以模拟拖动
var mouseMoveEvent = new MouseEvent('mousemove', {
    bubbles: true,
    cancelable: true,
    clientX: slider.getBoundingClientRect().left + 420, // 假设您要向右拖动420px
    view: window
});

// 模拟拖动
document.dispatchEvent(mouseMoveEvent);

// 创建 mouseup 事件，以模拟释放鼠标
var mouseUpEvent = new MouseEvent('mouseup', {
    bubbles: true,
    cancelable: true,
    view: window
});

// 模拟释放鼠标
document.dispatchEvent(mouseUpEvent);