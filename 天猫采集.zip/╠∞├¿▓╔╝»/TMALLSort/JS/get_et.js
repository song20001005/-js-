function get_pre_1(parse_url) {
    var K = [];
    var Me = arr_131[4];
    var we = Me >> 8;
    var $ = 255 & we;
    K.push($);
    we = 255 & Me;
    K.push(we);

    var Me = arr_131[79];
    var we = Me >> 8;
    var $ = 255 & we;
    K.push($);
    we = 255 & Me;
    K.push(we);

    var ze = 0;
    // we = '/newlogin/login.do/_____tmd_____/slide?slidedata=%7B%22a%22%3A%22X82Y__c6ecc3ec0adcc6d4382d92be1710db07%22%2C%22t%22%3A%22fb51f1412aa384423f29699d8fb0a269%22%2C%22n%22%3A%22227!SSiSphodVE%2FOQu4BzhfSSludZ%2BP4JL9j4lPuOXwFJyaWntR3SCcTpsrUVgiE9O3aPEMwCSPE8mJMtS3Oe8xcJPWY6%2Bo1wHRenHEueEHU8n%2Bzntkk%2BVnL3SIb%2B%2BTfrYvCnX7eOsvHa7KzFoo2DwGbWlQAqYuHmpUinHEVOmv3ehuoXr%2By9En13DmWqAgHmppinHPkqfvHaRbgh70Ke8lnODlzqKiHDppinXPPOfnhH18hOoR8mxnD3Dlz6mVXmphd9DQ12snHanWWSd7kDWnZ3DuSFQgHmppinXPPOJnHaCszSdVhi2n3WllzqKGXDuSinXPPOYSw3Vzx5kfCy0viu3Bv7YZLXWaSCKkCosOLcnOx5V%2BGy0xQWA9xgf3AN4lNIrql%2FJODf%2Be1%2BLy%2FgklHXh%2FTzT1Lp1GlGew6yEMRChdwzKzFdMJjEK1Bz7YAo1wfjAzgsuUj%2FHipH94dkKbbTaKQmX1vfPN6a4sUq6SEXzZ%2Fw%2B5P81EwzFmFG3XrXJKpIEOEowaYyoZrFTpeIQOJ7QbW9zU%2FX8SJAti34yiR6hqegpQshwvLe%2B48x8XGJnNEtxJ5ORvrtScJMq9HpRYG1rqgKy2fm09frXKkwKYd80c%2Fn9LmoDt8S%2FqhF8M6VuVzR90if6367K0pRdXgqVObbeIS2CPluxsQ79emahFrAGjO0Yk%2BFXeWp2wwHAQJLCi3wvdIsMfc2YHT4UK5RQ4EjFqgZj4P%2Bw3Ket%2FHKA30AAq6C6DiAZS5aD0GR%2Bt3iN7ZLbpUwjYkawBsKpVGV1zZWrCiC5bkJ%2B6LgYAUFgNCCU1lTErsAFsMvWpxjntdpvxufYiLIPYszxrpD6fa73R3KsGEUTCvJhSU2kfjyaVTPqW%2BwKVac4Ji2nUxjbcPK32nQUE1jgoKD4kflo5TPN7oer2yoEd6M59%2BK7r1ZiS6ASbMK4vQQBwVanKDADJpEcoviZJpcPXuR7PMR0R4H8fz6%2BX4PtPzeZFumr3abozVUrFZBsghxCnuIFkYmrYI%2BGyqEyS3Fuu53512M63%2Baf%2BgOHtJFcjnOJD9XQeBx03a8jK4R5CgHufXqKGifOJvBnZAjP1quBLstUC8J24USl8P4ueYjL%2BVbuZEOsDaWHMD0mjkFzVIJtJsSxcfnxseM7A%2BoSsVtYdIsnP5shNUxjrBGLHtzIg964%2F7mTrz13OomDwC7LvzGK93TazbKhO1976Sse2xH3LIdJu93zPMqCao1JEYBMOFMTgaQIjRzlGRNWjUTIB6NEGuO3wgXuN0BgxA2ffiXxDHYt5cdLC3wYiCBOQ3tVL3McwpFrp%2FShGG9TazJao200cFfXPcwhGIyiWy9%2FVpugVWDi8heR%2FhInEQod38Y%2BbuAQS%2FrQnaXPbbfS0Up1qSh%2Bgotk1jmLhHn3uLvaq2VM1t2kppuz%2FKgWRZWj0%2BzUznhUdD2HzNP83j5T0c41EU44%2B%2FKEUyxC1Mw7VX%2Bov8L4GnTLcFJZ2US5BWS4hS9G99oRV9anN%2BiXe6azzXILztul3TvmKyNj%2B%2Bgn5Lnp9ljLkOfZQ%2BvqpbUX6m397udyLesg1SDhUMvjBxrdUA8X9%2FCllNJt1zSZrpssVXZk1oDlU3Wryn0Mh2vf5Cxi3RsdR7JeEWLXhMQKPyAUApzvwZYccTg8EuzfGXcY7IxBfMWBJ7vv%2B%2FVM0RbonQtXYGpU21FioZOY9U0NK%2FxTWxgcA4b0Y1uEaudCETaGSsP6%2BlzVVexP86aluAVR6prVhZ1JLEXEfZ%2BQvG6FrWOZ69X25QRNHb5KV%2F4wZQPc4OKzD4PpLjr0UqoibNqB6o5zBAb%2FaLI%2B%2FhTBqClrxf7CqZ0VkuSOypB2k5wgDooqlnRDUSCO3JYV3OCarNZuOjDrabhBHAlrpgCKVoDFG6IpFQbi%3D%3D%22%2C%22p%22%3A%22%7B%5C%22ncbtn%5C%22%3A%5C%220%7C0%7C42%7C34%7C0%7C34%7C0%7C42%5C%22%2C%5C%22umidToken%5C%22%3A%5C%22G8198384D4ADDEB9D2D5C503B907B83FA1F8909440C99A01F00%5C%22%2C%5C%22ncSessionID%5C%22%3A%5C%22b15890839%5C%22%2C%5C%22et%5C%22%3A%5C%221%5C%22%7D%22%2C%22scene%22%3A%22register%22%2C%22asyn%22%3A0%2C%22lang%22%3A%22cn%22%2C%22v%22%3A1%7D&x5secdata=xd7f7e7d703e562fe4fb51f1412aa384423f29699d8fb0a2691702734074a-717315356a1780105780abaac3daa__bx__login.taobao.com%3A443%2Fnewlogin%2Flogin.do&landscape=1&ts=1702734092638&v=07506175215339281'
    we = parse_url;
    Me = 0 | we.length / 20;
    for (var J = 0; J < we.length;) {
        je = 31 * ze,
            ze = 0 | je,
            je = we.charCodeAt(J),
            ze += je,
            J += Me;
    }
    Me = ze >> 8; //ze可尝试随机
    we = 255 & Me;
    K.push(we);
    Me = 255 & ze;
    K.push(Me);
    K = K.concat(arr_131[37]);



    K.push(31);

    var K_J = [];
    Me = arr_131[95] / 4294967296;
    we = Math['floor'](Me);
    Me = we * 4294967296;
    ze = arr_131[95] - Me;
    Me = we;
    var $ = Me >> 24;
    var je = 255 & $;
    K_J.push(je);
    $ = Me >> 16;
    je = 255 & $;
    K_J.push(je);

    $ = Me >> 8;
    je = 255 & $;
    K_J.push(je);

    $ = 255 & we;
    K_J.push($);


    $ = ze >> 24;
    je = 255 & $;
    K_J.push(je);
    $ = ze >> 16;
    je = 255 & $;
    K_J.push(je);
    $ = ze >> 8;
    je = 255 & $;
    K_J.push(je);
    $ = 255 & ze;
    K_J.push($);

    J = K_J["slice"](2);
    K = K.concat(J);

    K = K.concat([1, 2, 7, 0]); //先写死
    var ee = "https://login.taobao.com//newlogin/login.do/_____tmd_____/punish"
    var mm = [];
    for (var ye = 0; ye < ee.length; ye++) {
        $e = ee.charCodeAt(ye),
            mm.push($e)
    };
    K.push(mm.length);
    K = K.concat(mm);
    void mm;
    // var ie = 'Netscape';
    //K.push(8)
    // for (var H = 0; H < ie.length; H++) {
    //     ra = ie.charCodeAt(H),
    //         K.push(ra)
    // }
    K = K.concat([8, 78, 101, 116, 115, 99, 97, 112, 101]); //检测'Netscape',写死
    K = K.concat(arr_131[16], 0, 0, 0, 0, 0, 0);
    K.push(255 & 6); // 检测Navigator的'hardwareConcurrency'
    K = K.concat([0, 0, 0]);

    Z = arr_131[96];
    _ = arr_131[30];
    $ = Z ^ _;
    Z = void 0;
    _ = $;
    $ = [];
    E = _ >> 24;
    be = 255 & E;
    $.push(be);
    E = _ >> 16;
    be = 255 & E;
    $.push(be);
    E = _ >> 8;
    be = 255 & E;
    $.push(be);
    E = 255 & _;
    $.push(E);
    K = K.concat($);
    K.push(0);

    var Z = 'login.taobao.com//newlogin/login.do/_____tmd_____/punish'
    var _ = 0;
    for (var E = 0; E < Z.length; E++) {
        ie = _ << 5,
            ge = ie - _,
            ie = Z.charCodeAt(E),
            _ = ge + ie,
            _ >>>= 0
    }


    $ = _;
    Z = $;
    $ = Z;
    Z = void 0;
    _ = $;
    $ = [];
    E = _ >> 24;
    be = 255 & E;
    $.push(be);
    E = _ >> 16;
    be = 255 & E;
    $.push(be);
    E = _ >> 8;
    be = 255 & E;
    $.push(be);
    E = 255 & _;
    $.push(E);
    K = K.concat($);

    K = K.concat([0, 0, 0, 0]);
    _ = arr_131[42];
    Z = []
    E = _ >> 24;
    be = 255 & E;
    Z.push(be);
    E = _ >> 16;
    be = 255 & E;
    Z.push(be);
    E = _ >> 8;
    be = 255 & E;
    Z.push(be);
    E = 255 & _;
    Z.push(E);
    K = K.concat(Z);
    K.push(0);

    je = Date.now() - 5000;
    // je = 1702714868149;
    $ = je / 1e3;
    je = $ >>> 0;
    $ = void 0;
    Z = je;
    je = [];
    _ = Z >> 24;
    E = 255 & _;
    je.push(E);
    _ = Z >> 16;
    E = 255 & _;
    je.push(E);
    _ = Z >> 8;
    E = 255 & _;
    je.push(E);
    _ = 255 & Z;
    je.push(_);
    K = K.concat(je);
    // console.log(K.toString());
    return K
}


function get_ba_1() {
    var he = ba_1_pre;
    // pe=[0, 86],je为pe的第二位
    var Z = 0;
    // var je = 49;
    var je = d_pe[1];
    var K = [];
    var ge = 'JIN6KFJ2';
    for (var E = 0; E < he.length / 2;) {
        oe = 2 * E,
            Ee = 2 * E,
            le = Ee + 2,
            Ee = he["slice"](oe, le),
            oe = 4 * Z,
            le = E % 4,
            _e = oe + le,
            oe = _e + je,
            le = oe % 4,
            oe = 0 === le;
        if (!oe) {
            switch (le) {
                case 1:
                    _e = void 0,
                        Ue = je,
                        na = Ee,
                        ua = [],
                        Ca = 7,
                        Da = 5,
                        ya = 0;
                    for (var ya = 0; ya < na.length; ya++) {
                        fa = na[ya],
                            ga = fa - Ca,
                            fa = 255 & ga,
                            ga = Da,
                            cr = fa >> ga,
                            br = 8 - ga,
                            ga = fa << br,
                            fa = cr + ga,
                            ga = 255 & fa,
                            fa = ga ^ Ue,
                            ua.push(fa)
                    }
                    K = K.concat(ua);
                    E++;
                    break;
                case 2:
                    _e = void 0,
                        Ue = je,
                        na = Ee,
                        ua = [],
                        Ca = 4,
                        Da = 19506,
                        ya = 0;
                    for (var ya = 0; ya < na.length; ya++) {
                        fa = na[ya],
                            ga = fa >> Ca,
                            cr = 8 - Ca,
                            br = fa << cr,
                            fa = ga + br,
                            ga = fa + Da,
                            fa = 255 & ga,
                            ga = fa ^ Ue,
                            ua.push(ga);
                    }
                    K = K.concat(ua);
                    E++;
                    break;
                case 3:
                    le = void 0,
                        _e = je,
                        Ue = Ee,
                        na = [],
                        ua = ge,
                        Ca = 87,
                        Da = Ca,
                        Ca = 0;
                    for (var Ca = 0; Ca < Ue.length; Ca++) {
                        ya = Ue[Ca],
                            fa = Da + 1,
                            ga = ua.length,
                            Da = fa % ga,
                            fa = ua.charCodeAt(Da),
                            ya ^= fa,
                            fa = 255 & ya,
                            ya = fa ^ _e,
                            na.push(ya);
                    }
                    K = K.concat(na);
                    E++;
                    break;
                default:
                    E++;
                    break;
            }
        } else {
            _e = void 0,
                Ue = je,
                na = Ee,
                ua = [],
                Ca = 3,
                Da = 5,
                ya = 0;
            for (var ya = 0; ya < na.length; ya++) {
                fa = na[ya],
                    ga = fa - Ca,
                    fa = 255 & ga,
                    ga = Da,
                    cr = fa >> ga,
                    br = 8 - ga,
                    ga = fa << br,
                    fa = cr + ga,
                    ga = 255 & fa,
                    fa = ga ^ Ue,
                    ua.push(fa)
            }
            K = K.concat(ua);
            E++
        }
        // console.log(K);
    }
    // console.log(K.toString());
    return K
}

function get_pre_2() {
    var $ = he = ba_1;
    var je = 0;
    Ve = [];
    var K = [];
    for (var Z = 0; Z < $.length; Z++) {
        _ = $[Z],
            E = 98 & _,
            _ = je + E,
            je = 255 & _
    }
    K.push(je);

    K = K.concat(he);
    he = K.length;
    K = [he].concat(K);

    Ve = Ve.concat(K);
    K = [];
    he = void 0;
    je = arr_131[101];
    $ = void 0;
    Z = 0;

    _ = je;
    E = _ >>> 0;
    _ = 16384 > E;
    if (!_) {
        _ = [];
        while (E) {
            ge = 127 & E;
            E >>>= 7;
            if (E) {} else {
                _.push(ge);
                break;
            }
            ge = 128 | ge;
            _.push(ge);
        }
    } else {
        ge = void 0;
        oe = 0;
        Ee = E;
        le = 0 | Ee;
        Ee = 128 > le;
        if (Ee) {
            _e = [];
            _e.push(le);
            Ue = _e;
            ge = Ue;
            oe = 1;
            // $ = ge;
            _ = ge;
        } else {
            Ee = le % 128,
                _e = le - Ee,
                le = _e / 128,
                _e = [],
                Ue = Ee + 128,
                Ee = 127 & le,
                _e.push(Ue, Ee),
                _ = _e
        }
    }
    K = K.concat(_);
    K = K.concat(arr_131[38]);
    // K = K.concat(tm_arr);
    K = K.concat(tm_arr.slice(2));
    he = Date.now() - 5000;
    $ = he - arr_131[95]; //正常3000网上
    // $ = 432820;
    Z = $;
    _ = Z >>> 0;
    Z = 16384 > _;
    if (!Z) {
        Z = [];
        while (_) {
            E = 127 & _;
            _ >>>= 7;
            if (_) {} else {
                Z.push(E);
                break;
            }
            E = 128 | E;
            Z.push(E);
        }
    } else {
        E = void 0;
        ge = 0;
        oe = _;
        Ee = 0 | oe;
        oe = 128 > Ee;
        if (!oe) {
            oe = Ee % 128,
                le = Ee - oe,
                Ee = le / 128,
                le = [],
                _e = oe + 128,
                oe = 127 & Ee,
                le.push(_e, oe);
            Z = le
        } else {
            le = [],
                le.push(Ee);
            Z = le
        }
    }
    K = K.concat(Z);
    K = K.concat([0, 0, 5, 186, 1, 1]); //写死
    Y = arr_131[0] ^ arr_131[122]
    P = Y;
    F = P >>> 0;
    P = 16384 > F;
    if (P) {
        G = void 0,
            ke = 0;
        Z = F,
            _ = 0 | Z,
            Z = 128 > _;
        if (!Z) {
            Z = _ % 128,
                E = _ - Z,
                _ = E / 128,
                E = [],
                H = Z + 128,
                Z = 127 & _,
                E.push(H, Z)
        } else {
            E = [],
                E.push(_)
        }
    } else {
        P = [];
        while (F) {
            G = 127 & F,
                F >>>= 7;
            if (F) {
                G = 128 | G,
                    P.push(G)
            } else {
                P.push(G)
            }
        }
        E = P
    }
    K = K.concat(E);
    K = K.concat([255, 2, 0]); //中间的3代表mousedown的次数，正常输入验证码流程至少2次
    K = K.concat(E);
    K.push(2, 0); //3代表mousedown的次数，正常输入验证码流程至少2次
    K = K.concat([100, 0, false, 220, 0, 0, 0, 0, null]); //写死
    // console.log(K);
    // console.log(Ve);
    return K
}

function get_ba_2() {
    var Le = ba_2_pre;
    var K = [];
    // var re = pe[1];
    // var re = J = 49;
    var re = J = d_pe[1];
    var X = 628062015;
    while (X) {
        ce = 255 & X,
            re = ce ^ re,
            X >>= 8
    };
    ce = re % 4;
    Y = ce;
    ce = Le.length;
    X = ce / 2;
    ce = Math["ceil"](X);
    // X = 0;
    // re = "\u0239\u0256\u022c\u0257\u023b\u024f\u0253\u025c";
    // P = "";
    // F = 0;
    // for (var F = 0; F < re.length; F++) {
    //     G = re.charCodeAt(F) - 489,
    //         P += String.fromCharCode(G)
    // };
    re = "PmCnRfjs";
    P = F = "jm1d";
    for (var X = 0; X < ce;) {
        F = 2 * X;
        G = 2 * X;
        ke = G + 2;
        G = Le["slice"](F, ke);
        F = 4 * Y;
        ke = X % 4;
        Z = F + ke;
        F = Z + J;
        ke = F % 4;
        // F = 0 === ke;
        switch (ke) {
            case 0:
                Z = void 0,
                    _ = J,
                    E = G,
                    H = [],
                    aa = 27396,
                    oe = 3952,
                    Ee = aa;
                // aa = 0;
                for (var aa = 0; aa < E.length; aa++) {
                    le = E[aa],
                        _e = le ^ Ee,
                        le = Ee * aa,
                        Ue = le % 256,
                        Ee = Ue + oe,
                        le = 255 & _e,
                        _e = le ^ _,
                        H.push(_e)
                }
                K = K.concat(H);
                X++;
                break;
            case 1:
                Z = void 0,
                    _ = J,
                    E = G,
                    H = [],
                    aa = re,
                    oe = 0;
                // Ee = 0;
                for (var Ee = 0; Ee < E.length; Ee++) {
                    le = E[Ee],
                        _e = aa.charCodeAt(oe),
                        le ^= _e,
                        oe++,
                        _e = aa.length,
                        Ue = oe >= _e;
                    if (!Ue) {
                        _e = 255 & le,
                            le = _e ^ _,
                            H.push(le)
                    } else {
                        oe = 0,
                            _e = 255 & le,
                            le = _e ^ _,
                            H.push(le)
                    }
                }
                K = K.concat(H);
                X++;
                break;
            case 2:
                Z = void 0,
                    _ = J,
                    E = G,
                    H = [],
                    aa = P,
                    oe = 69,
                    Ee = oe;
                for (var oe = 0; oe < E.length; oe++) {
                    le = E[oe],
                        _e = Ee + 1,
                        Ue = aa.length,
                        Ee = _e % Ue,
                        _e = aa.charCodeAt(Ee),
                        le ^= _e,
                        _e = 255 & le,
                        le = _e ^ _,
                        H.push(le)
                }
                K = K.concat(H);
                X++;
                break;
            case 3:
                ke = void 0,
                    Z = J,
                    _ = G,
                    E = [],
                    H = 137,
                    aa = H,
                    H = 0;
                for (var H = 0; H < _.length; H++) {
                    oe = _[H],
                        Ee = oe ^ aa,
                        oe = 255 & Ee,
                        Ee = oe ^ Z,
                        E.push(Ee),
                        aa = oe
                }
                K = K.concat(E);
                X++;
                break;
        }
    }
    // console.log(K.toString());
    J = K;
    K = 0;
    for (var Y = 0; Y < J.length;) {
        ce = J[Y],
            X = 233 & ce,
            ce = K + X,
            K = 255 & ce;
        Y++;

    }
    Le = K,
        K = [],
        K.push(Le),
        J = K.concat(J),
        Le = [],
        D = J.length,
        Le.push(D),
        D = Le,
        Le = D.concat(J)
    K = Le;
    return K

}

function get_pre_3() {

    Ye = [251, 3, 57, 56, 254, 26, 15, 254, 0, 0, 0, 0, 0, 0]; //写死
    //251, 3, 57, 56, 254, 26, 15, 254, 0, 0, 0, 0, 0, 0, 210, 254, 8, 68, 188, 98, 241, 107, 0, 0, 4, 56, 0, 0, 7, 128, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 16
    Ae = arr_131[112] - 1;
    de = [];
    se = Ae >> 24;
    K = 255 & se;
    de.push(K);
    se = Ae >> 16;
    K = 255 & se;
    de.push(K);
    se = Ae >> 8;
    K = 255 & se;
    de.push(K);
    se = 255 & Ae;
    de.push(se);
    //
    Ye = Ye.concat(de);
    //
    Ae = arr_131[45];
    de = [];
    se = Ae >> 24;
    K = 255 & se;
    de.push(K);
    se = Ae >> 16;
    K = 255 & se;
    de.push(K);
    se = Ae >> 8;
    K = 255 & se;
    de.push(K);
    se = 255 & Ae;
    de.push(se);


    Ye = Ye.concat(de);
    Ye = Ye.concat([0, 0, 4, 56, 0, 0, 7, 128, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 16, 0, 0, 7, 128]);
    return Ye
}

function ge_ba_3() {
    var Ye = ba_3_pre;
    var Le = [];
    var J = 0;
    var D = d_pe[1]; //pe的第二位
    var se = "QvtkfsL";
    var K = "Gto2";
    for (var Ae = 0; Ae < Ye.length / 2;) {
        te = 2 * Ae,
            Be = 2 * Ae,
            Y = Be + 2,
            Be = Ye["slice"](te, Y),
            te = 4 * J,
            Y = Ae % 4,
            ce = te + Y,
            te = ce + D,
            Y = te % 4;
        te = 0 === Y;
        if (!te) {
            switch (Y) {
                case 1:
                    ce = void 0,
                        X = D,
                        re = Be,
                        P = [],
                        F = 244,
                        G = F,
                        F = 0;
                    for (var F = 0; F < re.length; F++) {
                        ha = re[F],
                            ke = ha ^ G,
                            ha = 255 & ke,
                            ke = ha ^ X,
                            P.push(ke),
                            G = ha;

                    }
                    Le = Le.concat(P);
                    Ae++;
                    break;
                case 2:
                    ce = void 0,
                        X = D,
                        re = Be,
                        P = [],
                        F = 155,
                        G = 256,
                        ha = 0;
                    for (var ha = 0; ha < re.length; ha++) {
                        ke = re[ha],
                            ze = F - 1,
                            ke += ze,
                            ze = ke >= G;
                        if (!ze) {
                            ze = ke ^ X,
                                P.push(ze)
                        } else {
                            ke %= G, ze = ke ^ X,
                                P.push(ze)
                        }
                    }
                    Le = Le.concat(P);
                    Ae++;
                    break;
                case 3:
                    Y = void 0,
                        ce = D,
                        X = Be,
                        re = [],
                        P = se,
                        F = 0,
                        G = 0;
                    for (var G = 0; G < X.length; G++) {
                        ha = X[G],
                            ke = P.charCodeAt(F),
                            ha ^= ke,
                            F++,
                            ke = P.length,
                            ze = F >= ke;
                        if (!ze) {
                            ke = 255 & ha,
                                ha = ke ^ ce,
                                re.push(ha)
                        } else {
                            F = 0, ke = 255 & ha,
                                ha = ke ^ ce,
                                re.push(ha)
                        }
                    }
                    Le = Le.concat(re);
                    Ae++
                    break;
                default:
                    Ae++

            }
        } else {
            ce = void 0,
                X = D,
                re = Be,
                P = [],
                F = K,
                G = 188,
                ha = G,
                G = 0;
            for (var G = 0; G < re.length; G++) {
                ke = re[G],
                    ze = ha + 1,
                    he = F.length,
                    ha = ze % he,
                    ze = F.charCodeAt(ha),
                    ke ^= ze,
                    ze = 255 & ke,
                    ke = ze ^ X,
                    P.push(ke)
            }
            Le = Le.concat(P)
            Ae++
        }
    }
    D = 0;
    for (var J = 0; J < Le.length; J++) {
        de = Le[J],
            Ae = 191 & de,
            de = D + Ae,
            D = 255 & de
    }

    K = [Le.length + 1],
        K.push(D),
        Le = K.concat(Le);
    return Le
}

function jm_bx_et() {
    ba = Ve;
    var Le = 0;
    var pe = Ze = d_pe;
    var Ga = "";
    var S = [
        "q45WS7R",
        "aCBIQdpK",
        "ZfeD0WV9",
        "YcDm0V2",
        "16s_O9t",
        "BKXmopA42",
        "+6nkG3lC",
        "LhHn3FeE",
        "587tdvqQO",
        "URsihuzJF",
        "UfXjbAvx",
        "J-8lkouPyrz.",
        "jgLTNPE",
        "TGMigNwZ",
        "Hy1wc=",
        "xarS/MIbY"
    ];
    for (var D = 0; D < ba.length; D++) {
        J = ba[D],
            de = 149 & J,
            J = Le + de,
            Le = 255 & J;
    }
    pe[0] = Le;
    Ie = Ve;
    Ye = Ie;
    ba = Ye;
    Ye = Ze.concat(ba);
    ba = void 0;
    Le = S;
    Ze = Ye;
    Ye = [];
    D = Ze.length;
    J = 0;
    pe = Le[4];
    de = Le[13];
    Ae = pe + de;
    pe = Le[1];
    de = Ae + pe;
    pe = Le[7];
    Ae = de + pe;
    pe = Le[10];
    de = Ae + pe;
    pe = Le[3];
    Ae = de + pe;
    pe = Le[0];
    de = Ae + pe;
    pe = Le[11];
    Le = de + pe;
    pe = Le.split(Ga);
    Le = D > J,
        de = !Le;
    while (!de) {
        Le = Ze[J],
            de = Le << 16,
            Le = J + 1,
            Ae = Ze[Le],
            Le = Ae << 8,
            Ae = de | Le,
            Le = J + 2,
            de = Ze[Le],
            Le = Ae | de,
            de = Le >> 18,
            Ae = Le >> 12,
            Ie = 63 & Ae,
            Ae = J + 1,
            se = Ze[Ae],
            Ae = isNaN(se);
        if (!Ae) {
            se = Le >> 6,
                Ae = 63 & se,
                se = Ae,
                Ae = J + 2,
                Ve = Ze[Ae],
                Ae = isNaN(Ve);
            if (!Ae) {
                Ae = 63 & Le,
                    Le = Ae,
                    J += 3,
                    Ae = pe[de],
                    de = pe[Ie],
                    Ie = pe[se],
                    se = pe[Le],
                    Ye.push(Ae, de, Ie, se);
            } else {
                Ae = 64,
                    Le = Ae,
                    J += 3,
                    Ae = pe[de],
                    de = pe[Ie],
                    Ie = pe[se],
                    se = pe[Le],
                    Ye.push(Ae, de, Ie, se)
            }
        } else {
            Ae = 64,
                se = Ae,
                Ae = J + 2,
                Ve = Ze[Ae],
                Ae = isNaN(Ve);
            if (!Ae) {
                Ae = 63 & Le,
                    Le = Ae,
                    J += 3,
                    Ae = pe[de],
                    de = pe[Ie],
                    Ie = pe[se],
                    se = pe[Le],
                    Ye.push(Ae, de, Ie, se)
            } else {
                Ae = 64,
                    Le = Ae,
                    J += 3,
                    Ae = pe[de],
                    de = pe[Ie],
                    Ie = pe[se],
                    se = pe[Le],
                    Ye.push(Ae, de, Ie, se)
            }
        }
        Le = D > J,
            de = !Le;

    }
    // console.log(Ye.join(""));
    // console.log(Ye.join(""));
    return "e" + Ye.join("")
}

function get_d_pe() {
    var Ae = Date.now() - 5000;
    // var Ae = 1702721007892;
    var Ie = 4294967296;
    var Ve = Ae / Ie;
    var K = Math["floor"](Ve);
    Ve = K * Ie;
    Ie = Ae - Ve;
    K = Ie;
    var Ie = [];
    te = K >> 24;
    Be = 255 & te;
    Ie.push(Be);
    te = K >> 16;
    Be = 255 & te;
    Ie.push(Be);
    te = K >> 8;
    Be = 255 & te;
    Ie.push(Be);
    te = 255 & K;
    Ie.push(te);
    // console.log(Ie);
    return [0, Ie[3]]


}

function get_tm_arr() {
    var tm_arr = [];
    he = arr_131[95];
    // var he = 1702722226683;
    var ze = 4294967296;
    var Me = he / ze;
    var we = Math["floor"](Me);
    Me = we * ze;
    ze = he - Me;
    he = void 0;
    Me = we;
    $ = Me >> 24;
    je = 255 & $;
    tm_arr.push(je);
    $ = Me >> 16;
    je = 255 & $;
    tm_arr.push(je);
    $ = Me >> 8;
    je = 255 & $;
    tm_arr.push(je);
    $ = 255 & Me;
    tm_arr.push($);

    we = ze
    $ = we >> 24;
    je = 255 & $;
    tm_arr.push(je);
    $ = we >> 16;
    je = 255 & $;
    tm_arr.push(je);
    $ = we >> 8;
    je = 255 & $;
    tm_arr.push(je);
    $ = 255 & we;
    tm_arr.push($);
    return tm_arr
}

function get_arr_131() {
    var arr_131 = [];
    arr_131[95] = Date.now() - 5000;
    arr_131[4] = -775475069; //1
    arr_131[79] = 83581723; //1
    arr_131[37] = [216, 237]; //1
    arr_131[42] = 4181197481; //1
    arr_131[30] = 0; //1
    arr_131[16] = 1; //1
    arr_131[111] = [57, 56]; //1
    arr_131[112] = -755103675; //1
    arr_131[45] = "3452885173"; //1
    arr_131[122] = 1; //1
    arr_131[38] = [128, 15]; //1
    var ae = Math['random']();
    var Pe = 4294967295 * ae;
    ae = Pe >>> 0;
    ue = ae;
    ae = ++arr_131[30];
    arr_131[96] = ue ^ ae;

    arr_131[0] = Math.floor(Math.random() * (1100 - 890 + 1)) + 890; //随机，和鼠标在页面移动相关


    var Oe = Math["pow"](2, 32);
    Pe = Oe - 1;
    ae = Math['random']();
    Oe = ae * Pe;
    ae = Math["floor"](Oe);

    arr_131[101] = ae + 1;
    return arr_131


}

function get_bx_et(parse_url) {
    // d_pe = [0, 178];
    // arr_131 = [];
    // arr_131[95] = 1702714857788;
    // // arr_131[95] = Date.now() - 10000;
    // arr_131[96] = 781537391;
    // arr_131[101] = 2461565275;
    // arr_131[0] = 1617;
    // arr_131[4] = -775475069; //1
    // arr_131[79] = 83581723; //1
    // arr_131[37] = [216, 237]; //1
    // arr_131[42] = 4181197481; //1
    // arr_131[30] = 1; //1
    // arr_131[16] = 1; //1
    // arr_131[111] = [57, 56]; //1
    // arr_131[112] = -755103675; //1
    // arr_131[45] = "2685949931"; //1
    // arr_131[122] = 1; //1
    // arr_131[38] = [128, 15]; //1
    d_pe = get_d_pe();
    arr_131 = get_arr_131();
    tm_arr = get_tm_arr();
    ba_1_pre = get_pre_1(parse_url);
    ba_1 = get_ba_1();
    ba_2_pre = get_pre_2(); //Ve
    ba_2 = get_ba_2();

    Ve = Ve.concat(ba_2);


    ba_3_pre = get_pre_3();
    ba_3 = ge_ba_3();
    Ve = Ve.concat(ba_3);
    // console.log(Ve.length);

    return jm_bx_et()
}

parse_url = '/newlogin/login.do/_____tmd_____/slide?slidedata=%7B%22a%22%3A%22X82Y__c6ecc3ec0adcc6d4382d92be1710db07%22%2C%22t%22%3A%22fb51f1412aa384423f29699d8fb0a269%22%2C%22n%22%3A%22227!SSiSphodVE%2FOQu4BzhfSSludZ%2BP4JL9j4lPuOXwFJyaWntR3SCcTpsrUVgiE9O3aPEMwCSPE8mJMtS3Oe8xcJPWY6%2Bo1wHRenHEueEHU8n%2Bzntkk%2BVnL3SIb%2B%2BTfrYvCnX7eOsvHa7KzFoo2DwGbWlQAqYuHmpUinHEVOmv3ehuoXr%2By9En13DmWqAgHmppinHPkqfvHaRbgh70Ke8lnODlzqKiHDppinXPPOfnhH18hOoR8mxnD3Dlz6mVXmphd9DQ12snHanWWSd7kDWnZ3DuSFQgHmppinXPPOJnHaCszSdVhi2n3WllzqKGXDuSinXPPOYSw3Vzx5kfCy0viu3Bv7YZLXWaSCKkCosOLcnOx5V%2BGy0xQWA9xgf3AN4lNIrql%2FJODf%2Be1%2BLy%2FgklHXh%2FTzT1Lp1GlGew6yEMRChdwzKzFdMJjEK1Bz7YAo1wfjAzgsuUj%2FHipH94dkKbbTaKQmX1vfPN6a4sUq6SEXzZ%2Fw%2B5P81EwzFmFG3XrXJKpIEOEowaYyoZrFTpeIQOJ7QbW9zU%2FX8SJAti34yiR6hqegpQshwvLe%2B48x8XGJnNEtxJ5ORvrtScJMq9HpRYG1rqgKy2fm09frXKkwKYd80c%2Fn9LmoDt8S%2FqhF8M6VuVzR90if6367K0pRdXgqVObbeIS2CPluxsQ79emahFrAGjO0Yk%2BFXeWp2wwHAQJLCi3wvdIsMfc2YHT4UK5RQ4EjFqgZj4P%2Bw3Ket%2FHKA30AAq6C6DiAZS5aD0GR%2Bt3iN7ZLbpUwjYkawBsKpVGV1zZWrCiC5bkJ%2B6LgYAUFgNCCU1lTErsAFsMvWpxjntdpvxufYiLIPYszxrpD6fa73R3KsGEUTCvJhSU2kfjyaVTPqW%2BwKVac4Ji2nUxjbcPK32nQUE1jgoKD4kflo5TPN7oer2yoEd6M59%2BK7r1ZiS6ASbMK4vQQBwVanKDADJpEcoviZJpcPXuR7PMR0R4H8fz6%2BX4PtPzeZFumr3abozVUrFZBsghxCnuIFkYmrYI%2BGyqEyS3Fuu53512M63%2Baf%2BgOHtJFcjnOJD9XQeBx03a8jK4R5CgHufXqKGifOJvBnZAjP1quBLstUC8J24USl8P4ueYjL%2BVbuZEOsDaWHMD0mjkFzVIJtJsSxcfnxseM7A%2BoSsVtYdIsnP5shNUxjrBGLHtzIg964%2F7mTrz13OomDwC7LvzGK93TazbKhO1976Sse2xH3LIdJu93zPMqCao1JEYBMOFMTgaQIjRzlGRNWjUTIB6NEGuO3wgXuN0BgxA2ffiXxDHYt5cdLC3wYiCBOQ3tVL3McwpFrp%2FShGG9TazJao200cFfXPcwhGIyiWy9%2FVpugVWDi8heR%2FhInEQod38Y%2BbuAQS%2FrQnaXPbbfS0Up1qSh%2Bgotk1jmLhHn3uLvaq2VM1t2kppuz%2FKgWRZWj0%2BzUznhUdD2HzNP83j5T0c41EU44%2B%2FKEUyxC1Mw7VX%2Bov8L4GnTLcFJZ2US5BWS4hS9G99oRV9anN%2BiXe6azzXILztul3TvmKyNj%2B%2Bgn5Lnp9ljLkOfZQ%2BvqpbUX6m397udyLesg1SDhUMvjBxrdUA8X9%2FCllNJt1zSZrpssVXZk1oDlU3Wryn0Mh2vf5Cxi3RsdR7JeEWLXhMQKPyAUApzvwZYccTg8EuzfGXcY7IxBfMWBJ7vv%2B%2FVM0RbonQtXYGpU21FioZOY9U0NK%2FxTWxgcA4b0Y1uEaudCETaGSsP6%2BlzVVexP86aluAVR6prVhZ1JLEXEfZ%2BQvG6FrWOZ69X25QRNHb5KV%2F4wZQPc4OKzD4PpLjr0UqoibNqB6o5zBAb%2FaLI%2B%2FhTBqClrxf7CqZ0VkuSOypB2k5wgDooqlnRDUSCO3JYV3OCarNZuOjDrabhBHAlrpgCKVoDFG6IpFQbi%3D%3D%22%2C%22p%22%3A%22%7B%5C%22ncbtn%5C%22%3A%5C%220%7C0%7C42%7C34%7C0%7C34%7C0%7C42%5C%22%2C%5C%22umidToken%5C%22%3A%5C%22G8198384D4ADDEB9D2D5C503B907B83FA1F8909440C99A01F00%5C%22%2C%5C%22ncSessionID%5C%22%3A%5C%22b15890839%5C%22%2C%5C%22et%5C%22%3A%5C%221%5C%22%7D%22%2C%22scene%22%3A%22register%22%2C%22asyn%22%3A0%2C%22lang%22%3A%22cn%22%2C%22v%22%3A1%7D&x5secdata=xd7f7e7d703e562fe4fb51f1412aa384423f29699d8fb0a2691702734074a-717315356a1780105780abaac3daa__bx__login.taobao.com%3A443%2Fnewlogin%2Flogin.do&landscape=1&ts=1702734092638&v=07506175215339281'
console.log(get_bx_et(parse_url));