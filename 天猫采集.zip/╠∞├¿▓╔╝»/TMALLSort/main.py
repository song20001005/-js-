import json
import time
import sqlite3
import requests
import TM_sign
import threading
import DrissionLogin
from skip import get_x5sec
import hk_drission
from datetime import datetime
import friut_drission


class TMALLSort:
    def __init__(self):
        self.cookies = None
        self.url = "https://h5api.m.taobao.com/h5/mtop.tmall.kangaroo.core.service.route.aldlampservice/1.0/"
        self.headers = {
            "authority": "h5api.m.tmall.com",
            "accept": "*/*",
            "accept-language": "zh-CN,zh;q=0.9",
            "referer": "https://pages.tmall.com/",
            "sec-fetch-dest": "script",
            "sec-fetch-mode": "no-cors",
            "sec-fetch-site": "same-site",
            "user-agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
            # "cookie": "",
            # "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        }

    def timestamp(self):
        timestamp_milliseconds = int(datetime.now().timestamp() * 1000)
        return timestamp_milliseconds

    def merge_dicts(self, a, b):
        try:
            result = b.copy()
            result.update(a)
            return result
        except:
            return b

    def get_cookie(self):
        cookie1 = DrissionLogin.get_m5()
        time.sleep(2)
        cookie2 = DrissionLogin.login()
        cookies = self.merge_dicts(cookie2, cookie1)
        return cookies

    def sql_insert_data(self, sql):
        try:
            db = sqlite3.connect("db.sqlite3")
            cursor = db.cursor()
        except:
            return False
        try:
            cursor.execute(sql)
            db.commit()
            cursor.close()
            db.close()
            return True
        except Exception as e:
            print(e)
            db.rollback()
            cursor.close()
            db.close()
            return False

    def sql_update_data(self, sql):
        try:
            db = sqlite3.connect("db.sqlite3")
            cursor = db.cursor()
        except:
            return False
        try:
            cursor.execute(sql)
            db.commit()
            cursor.close()
            db.close()
            return True
        except Exception as e:
            print(e)
            db.rollback()
            cursor.close()
            db.close()
            return False

    def get_rank_info_response(self, rank_info):
        data = r'{"curPageUrl":"<<detailUrl>>","appId":"16361998","tagId":"<<tagId>>","itemId":"","bizDate":"","channel":"1","rankType":"18","bizId":1111,"backupParams":"tagId","resId":"16361998","pvuuid":"v1-8a642871-a0b3-4c14-927f-e7c5255ae2db-1709049716084","__pvuuid":"v1-8a642871-a0b3-4c14-927f-e7c5255ae2db-1709049716084","_pvuuid":"v1-8a642871-a0b3-4c14-927f-e7c5255ae2db-1709049716084"}'.replace(
            "<<tagId>>", rank_info['tagId']).replace("<<detailUrl>>", rank_info['detailUrl'])
        _m_h5_tk_value = self.headers['cookie'].split("_m_h5_tk=")[1].split("_")[0]
        timestamp = self.timestamp()
        tm_sign = TM_sign._generate_sign_2(_m_h5_tk_value, str(timestamp), "12574478", data)
        params = {
            "jsv": "2.7.2",
            "appKey": "12574478",
            "t": str(timestamp),
            "sign": tm_sign,
            "timeout": "3000",
            "api": "mtop.tmall.kangaroo.core.service.route.AldLampService",
            "params": "[object Object]",
            "dataType": "jsonp",
            "v": "1.0",
            "preventFallback": "true",
            "type": "jsonp",
            "callback": "mtopjsonp4",
            "data": data
        }
        try:
            response = requests.get(self.url, headers=self.headers, params=params)
            print(response.text)
            resultValue = json.loads(response.text.split('mtopjsonp4(')[1][:-1])['data']['resultValue']
            for k, v in resultValue.items():
                resId = k
            data_list = resultValue[resId]['data']
            for data in data_list:
                item_list = data['itemList']
                for i, item in enumerate(item_list):
                    item_id = item['itemId']
                    price = item['wapFinalPrice']
                    sort = item['index']
                    item_url = "https:" + item['url']
                    item_name = item['title']
                    tag = rank_info["tag"]
                    rank_type = rank_info["rank_type"]
                    category = [rank_info['tabId_title'], rank_info['groupTitle'], rank_info['title']]
                    sql = f"insert into item_info(item_id,price,sort,item_url,item_name,tag,rank_type,category) values('{item_id}','{price}','{sort}','{item_url}','{item_name}','{tag}','{rank_type}','{json.dumps(category, ensure_ascii=False)}')"
                    if self.sql_insert_data(sql):
                        print(item_id, item_name, rank_info['tagId'], "写入数据库成功！")
                    else:
                        print(item_id, item_name, rank_info['tagId'], "写入数据库失败！")
        except Exception as e:
            print(e)
            with open("error.txt", "a") as f:
                f.write(rank_info['tagId'] + "\n")

    def get_rank_type_list(self, rank_info, rank_class):
        data = r'{"curPageUrl":"<<detailUrl>>","appId":"16354966","resId":"16354966","tagId":"<<tagId>>","bizId":1111,"extParam":"{\"rankOrder\":\"32,18,20,9,5\",\"launchPoolId\":\"1866,2120,2184\",\"disablePriceZone\":false}","backupParams":"tagId","pvuuid":"v1-d7175652-f6f3-49f7-b31d-3d9296ab5448-1709098326026","__pvuuid":"v1-d7175652-f6f3-49f7-b31d-3d9296ab5448-1709098326026","_pvuuid":"v1-d7175652-f6f3-49f7-b31d-3d9296ab5448-1709098326026"}'.replace(
            "<<tagId>>", rank_info['rankId']).replace("<<detailUrl>>", rank_info['detailUrl'])
        _m_h5_tk_value = self.headers['cookie'].split("_m_h5_tk=")[1].split("_")[0]
        timestamp = self.timestamp()
        tm_sign = TM_sign._generate_sign_2(_m_h5_tk_value, str(timestamp), "12574478", data)
        params = {
            "jsv": "2.7.2",
            "appKey": "12574478",
            "t": str(timestamp),
            "sign": tm_sign,
            "timeout": "3000",
            "api": "mtop.tmall.kangaroo.core.service.route.AldLampService",
            "params": "[object Object]",
            "dataType": "jsonp",
            "v": "1.0",
            "preventFallback": "true",
            "type": "jsonp",
            "callback": "mtopjsonp4",
            "data": data
        }
        tabId_title = rank_class['tabId_title']
        groupTitle = rank_class['groupTitle']
        title = rank_class['title']
        try:
            response = requests.get(self.url, headers=self.headers, params=params, verify=False)
            # print(response.text)
            resultValue = json.loads(response.text.split('mtopjsonp4(')[1][:-1])['data']['resultValue']
            for k, v in resultValue.items():
                resId = k
            data_list = resultValue[resId]['data']
            for data in data_list:
                tag = data['title']
                rank_type_list = data['children']
                for rank in rank_type_list:
                    tagId = rank['rankId']
                    rank_type = rank['title']
                    detailUrl = rank['detailUrl']
                    rank_info = {
                        "tabId_title": tabId_title,
                        "groupTitle": groupTitle,
                        "title": title,
                        "tag": tag,
                        "tagId": tagId,
                        "rank_type": rank_type,
                        "detailUrl": detailUrl,
                    }
                    sql = "INSERT INTO rank_list_info(data) values ('%s')" % json.dumps(rank_info)
                    if self.sql_insert_data(sql):
                        print(rank_info['tagId'], "写入数据库成功！")
                    else:
                        print(rank_info['tagId'], "写入数据库失败！")
        except Exception as e:
            print(e, rank_info['rankId'])
            with open("error.txt", "a") as f:
                f.write(rank_info['tagId'] + "\n")

    def get_BD_response(self, BD):
        tabId = BD['tabId']
        categoryId = BD['categoryId']
        _m_h5_tk_value = self.cookies['_m_h5_tk'].split('_')[0]
        timestamp = self.timestamp()
        data = r'{"curPageUrl":"https%3A%2F%2Fpages.tmall.com%2Fwow%2Fz%2Frank%2Fdefault%2FfMZG235a36aPN3FfEkPc","appId":"16881273","resId":"16881273","ind2Id":"<<tabId>>","categoryId":"<<categoryId>>","bizType":"tmallTab","page":0,"pageSize":5,"extParam":"{\"distinctId\":\"17065214017750001\",\"dataSetId\":38047370,\"currentAldResId\":\"33062754\",\"contentId\":\"17065214017750001\",\"launchPoolId\":\"1866,2094,2120,2184,1907,2185\",\"id\":\"17065214017750001\",\"rankOrder\":\"18,32,5,20,9\",\"importLaunchPoolIds\":\"1907,2185\",\"__pos__\":1,\"__track__\":\"33062754.33062754.42554935.2.1\"}","backupParams":"ind2Id,categoryId","bizId":1111,"pvuuid":"v1-7f8b863b-a61b-4e7d-9fc0-d93ea562aad5-1709005582660","__pvuuid":"v1-7f8b863b-a61b-4e7d-9fc0-d93ea562aad5-1709005582660","_pvuuid":"v1-7f8b863b-a61b-4e7d-9fc0-d93ea562aad5-1709005582660"}'.replace(
            "<<tabId>>", tabId).replace("<<categoryId>>", categoryId)
        tm_sign = TM_sign._generate_sign_2(_m_h5_tk_value, str(timestamp), "12574478", data)
        params = {
            "jsv": "2.7.2",
            "appKey": "12574478",
            "t": str(timestamp),
            "sign": tm_sign,
            "timeout": "3000",
            "api": "mtop.tmall.kangaroo.core.service.route.AldLampService",
            "params": "[object Object]",
            "dataType": "jsonp",
            "v": "1.0",
            "preventFallback": "true",
            "type": "jsonp",
            "callback": "mtopjsonp4",
            "data": data
        }

        try:
            response = requests.get(self.url, headers=self.headers, cookies=self.cookies, params=params)
            """这里更新cookie，保证账号不掉线"""
            resultValue = json.loads(response.text.split('mtopjsonp4(')[1][:-1])['data']['resultValue']
            for k, v in resultValue.items():
                resID = k
            data_list = resultValue[resID]['data']
            for data in data_list:
                rank_list = data['rankList']
                for rank_info in rank_list:
                    sql = "INSERT INTO rank_info(rank_list, rank_type) VALUES ('%s', '%s')" % (
                        json.dumps(rank_info, ensure_ascii=False), json.dumps(BD, ensure_ascii=False))
                    if self.sql_insert_data(sql):
                        print(rank_info['title'], "写入数据库成功！")
                    else:
                        print(rank_info['title'], "写入数据库失败！")
        except Exception as e:
            print(e)
            with open("error.txt", "a") as f:
                f.write(tabId + "  " + categoryId + "\n")

    def get_item_info(self, item_id):
        while True:
            token = self.cookies['_m_h5_tk'].split("_")[0]
            url = "https://h5api.m.tmall.com/h5/mtop.taobao.detail.data.get/1.0/"
            timestamp = self.timestamp()
            data = r'{"id":"%s","detail_v":"3.5.0","exParams":"{\"id\":\"%s\",\"detail_v\":\"3.5.0\",\"appReqFrom\":\"detail\",\"container_type\":\"xdetail\",\"dinamic_v3\":\"true\",\"supportV7\":\"true\",\"ultron2\":\"true\",\"itemNumId\":\"%s\",\"pageCode\":\"miniAppDetail\",\"_from_\":\"miniapp\",\"openFrom\":\"pagedetail\",\"pageSource\":\"1\"}"}' % (
                item_id, item_id, item_id)
            sign = TM_sign._generate_sign_2(token, str(timestamp), "12574478", data)
            params = {
                "jsv": "2.7.0",
                "appKey": "12574478",
                "t": str(timestamp),
                "sign": sign,
                "api": "mtop.taobao.detail.data.get",
                "v": "1.0",
                "ttid": "201200@taobao_h5_10.2.10",
                "isSec": "0",
                "ecode": "0",
                "AntiFlood": "true",
                "AntiCreep": "true",
                "H5Request": "true",
                "type": "jsonp",
                "dataType": "jsonp",
                "safariGoLogin": "true",
                "mainDomain": "tmall.com",
                "subDomain": "m",
                "prefix": "h5api",
                "getJSONP": "true",
                "token": token,
                "callback": "mtopjsonp1",
                "data": data
            }
            try:
                response = requests.get(url, headers=self.headers, cookies=self.cookies, params=params)
                if "哎哟喂,被挤爆啦,请稍后重试" in response.text:
                    print(response.text)
                    urllo = response.text.split('{"url":"')[1].split('"')[0]
                    if ('kcapslidev2' in urllo):
                        x5sec = friut_drission.diaoyong(urllo)
                    else:
                        # x5sec = get_x5sec(urllo)
                        x5sec = hk_drission.diaoyong(urllo)
                    # x5sec = input("请输入x5sec的值：")
                    if x5sec is not None:
                        self.cookies['x5sec'] = x5sec
                        print("执行成功x5sec", x5sec)
                        continue
                    else:
                        continue
                data = json.loads(response.text.split('mtopjsonp1(')[1][:-1])['data']
                images = data['item']['images']
                img1 = {}
                for i, img in enumerate(images):
                    extension = img.split(".")[-1]
                    url_path = f"https:{img}"
                    file_path = f"img/{item_id}/img1/img000{str(i + 1)}.{extension}"
                    img1[f'img000{str(i + 1)}'] = {
                        "img_url": url_path,
                        "img_path": file_path
                    }
                groupProps = data['props']['groupProps']
                item_info = []
                for group in groupProps:
                    for k, v in group.items():
                        for item in v:
                            for key, value in item.items():
                                item_info.append({
                                    "key": key,
                                    "value": value
                                })
                item_info_text = json.dumps(item_info, ensure_ascii=False).replace("'", " ")
                sql = f"update item_info set item_info='{item_info_text}',img1='{json.dumps(img1, ensure_ascii=False)}' where item_id='{item_id}'"
                if self.sql_insert_data(sql):
                    print(item_id, "写入数据库成功！")
                else:
                    print(item_id, "写入数据库失败！")
                break
            except Exception as e:
                print(item_id, e)
                with open("error.txt", "a") as f:
                    f.write(item_id + "\n")
                exit()

    def get_item_info_desc(self, item_id):
        while True:
            token = self.cookies['_m_h5_tk'].split("_")[0]
            url = "https://h5api.m.taobao.com/h5/mtop.taobao.detail.getdesc/7.0/"
            timestamp = self.timestamp()
            data = r'{"id":"%s","detail_v":"3.3.0","preferWireless":"true"}' % item_id
            sign = TM_sign._generate_sign_2(token, str(timestamp), "12574478", data)
            params = {
                "jsv": "2.7.2",
                "appKey": "12574478",
                "t": str(timestamp),
                "sign": sign,
                "api": "mtop.taobao.detail.getdesc",
                "v": "7.0",
                "ttid": "2022@tmall_litepc_9.17.0",
                "isSec": "0",
                "ecode": "0",
                "AntiFlood": "true",
                "AntiCreep": "true",
                "H5Request": "true",
                "type": "jsonp",
                "dataType": "jsonp",
                "timeout": "3000",
                "callback": "mtopjsonp1",
                "data": data
            }
            try:
                response = requests.get(url, headers=self.headers, cookies=self.cookies, params=params)
                if "哎哟喂,被挤爆啦,请稍后重试" in response.text:
                    print(response.text)
                    urllo = response.text.split('{"url":"')[1].split('"')[0]
                    if ('kcapslidev2' in urllo):
                        x5sec = friut_drission.diaoyong(urllo)
                    else:
                        # x5sec = get_x5sec(urllo)
                        x5sec = hk_drission.diaoyong(urllo)
                    # x5sec = input("请输入x5sec的值：")
                    if x5sec is not None:
                        self.cookies['x5sec'] = x5sec
                        print("执行成功x5sec", x5sec)
                        continue
                    else:
                        continue
                data = json.loads(response.text.split('mtopjsonp1(')[1][:-1])['data']['components']['componentData']
                index = 6
                detail_text = ""
                img2 = {}
                for k, v in data.items():
                    try:
                        text = v['model'].get("text", "")
                        if text != "已经到最底了":
                            detail_text = detail_text + "\n" + text
                        img = v['model']['picUrl']
                        extension_list = img.split(".")
                        img = ".".join(extension_list[:-1])
                        extension = extension_list[-1]
                        if "?" in extension:
                            extension = extension.split("?")[0]
                        if img.startswith("https:"):
                            url_path = f"{img}.{extension}"
                        else:
                            url_path = f"https:{img}.{extension}"
                        if len(str(index)) == 1:
                            index_str = "000" + str(index)
                        elif len(str(index)) == 2:
                            index_str = "00" + str(index)
                        elif len(str(index)) == 3:
                            index_str = "0" + str(index)
                        else:
                            index_str = str(index)
                        file_path = f"img/{item_id}/img2/img{index_str}.{extension}"
                        img2[f'img{index_str}'] = {
                            "img_url": url_path,
                            "img_path": file_path
                        }
                        index += 1
                    except:
                        continue
                detail_text = detail_text.replace("'", '"')
                sql = f"update item_info set img2='{json.dumps(img2, ensure_ascii=False)}',item_text_desc='{detail_text}' where item_id='{item_id}'"
                if self.sql_insert_data(sql):
                    print(item_id, "写入数据库成功！")
                else:
                    print(item_id, "写入数据库失败！")
                break
            except Exception as e:
                print(item_id, e)
                with open("error.txt", "a") as f:
                    f.write(item_id + "\n")
                exit()

    def run(self):
        self.cookies = self.get_cookie()
        with open("BD_info.json", mode="r", encoding="utf-8") as f:
            BD_list = json.loads(f.read())
        t_list = []
        for BD in BD_list:
            t = threading.Thread(target=self.get_BD_response, args=(BD,))
            t_list.append(t)
            t.start()
            time.sleep(0.1)
        for t in t_list:
            t.join()

    def run_spider_BD_LIST(self):
        db = sqlite3.connect("db.sqlite3")
        cursor = db.cursor()
        self.headers['cookie'] = open("cookie", mode="r", encoding="utf-8").read()
        sql = "SELECT * FROM rank_info where id>3195"
        result_list = cursor.execute(sql).fetchall()
        t_list = []
        for result in result_list:
            t = threading.Thread(target=self.get_rank_type_list, args=(json.loads(result[1]), json.loads(result[2])))
            t_list.append(t)
            t.start()
            time.sleep(0.5)
        for t in t_list:
            t.join()

    def run_spider_item(self):
        db = sqlite3.connect("db.sqlite3")
        cursor = db.cursor()
        self.headers['cookie'] = open("cookie", mode="r", encoding="utf-8").read()
        result_text = open(file="item_id", mode="r", encoding="utf8").read()
        result_list = result_text.split("\n")
        # sql = "SELECT DISTINCT data FROM rank_list_info where id>20200 ORDER BY id;"
        # result_list = cursor.execute(sql).fetchall()
        t_list = []
        for result in result_list:
            sql = f"SELECT data FROM rank_list_info WHERE data LIKE '%{result}%'"
            queryset = cursor.execute(sql).fetchone()
            t = threading.Thread(target=self.get_rank_info_response, args=(json.loads(queryset[0]),))
            t_list.append(t)
            t.start()
            time.sleep(0.5)
        for t in t_list:
            t.join()

    def set_self_cookie(self):
        cookie1 = open("cookie1", mode="r", encoding="utf-8").read()
        cookie2 = open("cookie1", mode="r", encoding="utf-8").read()
        cookie3 = open("cookie1", mode="r", encoding="utf-8").read()
        cookie4 = open("cookie1", mode="r", encoding="utf-8").read()
        if self.headers['cookie'] == "":
            self.headers['cookie'] = cookie1
            return False
        if self.headers['cookie'] == cookie1:
            self.headers['cookie'] = cookie2
            return False
        if self.headers['cookie'] == cookie2:
            self.headers['cookie'] = cookie3
            return False
        if self.headers['cookie'] == cookie3:
            self.headers['cookie'] = cookie4
            return False
        if self.headers['cookie'] == cookie4:
            self.headers['cookie'] = cookie1
            return False

    def run_spider_item_info(self):
        db = sqlite3.connect("db.sqlite3")
        cursor = db.cursor()
        sql = "SELECT DISTINCT item_id FROM item_info ORDER BY id;"
        result_list = cursor.execute(sql).fetchall()
        for i, result in enumerate(result_list):
            if i % 10 == 0:
                self.set_self_cookie()
            self.get_item_info(result[0])
            time.sleep(1.5)

    def run_spider_item_info_desc(self):
        self.cookies = self.get_cookie()
        db = sqlite3.connect("db.sqlite3")
        cursor = db.cursor()
        sql = "SELECT DISTINCT item_id FROM item_info WHERE img2 is NULL ORDER BY id;"
        result_list = cursor.execute(sql).fetchall()
        for i, result in enumerate(result_list):
            self.get_item_info_desc(result[0])
            self.get_item_info(result[0])
            time.sleep(1)


if __name__ == '__main__':
    spider = TMALLSort()
    spider.run_spider_item_info_desc()
