import json
import re
import time
import hk_drission
import TM_sign
import requests
from datetime import datetime
import hk_227
import drission_login
import agentip
import login
import video_url_get
from loguru import logger
import friut_drission
import python_connect_mysql
import urllib
from urllib import parse


call_counter = 0
def get_cookie_r():
    print('被调用啦')
    file_path = './cookies.txt'  # 将 'your_file.txt' 替换为你的文件路径
    with open(file_path, 'r', encoding='utf-8') as file:
        content= file.read()
        content_line = json.loads(content.strip()) # strip()用于移除行尾的换行符和空格
    return content_line

def write_file(new_cookie_dict):
    filepath = './cookies.txt'
    with open(filepath, 'w') as f:
        f.write(json.dumps(new_cookie_dict))
        f.write('\n')

def get_x5sec_r():
    #print('被调用啦')
    file_path = './x5sec.txt'  # 将 'your_file.txt' 替换为你的文件路径
    with open(file_path, 'r', encoding='utf-8') as file:
        content= file.read()
        content_line = content.strip()# strip()用于移除行尾的换行符和空格
    #print(content_line)
    new_x5sec_ = re.findall('x5sec=(.*?);Max-Age', "".join(str(content_line).split()))[0]
    return new_x5sec_

def write_catch(catch):
    filepath = './catch.txt'
    with open(filepath, 'w') as f:
        f.write(str(catch))

def write_url(url):
    filepath = './url.txt'
    with open(filepath, 'w') as f:
        f.write(str(url))

def read_catch():
    file_path = "./catch.txt"

    # 打开文件并读取整个内容
    with open(file_path, 'r') as file:
        # 读取文件中的字符串
        content_as_string = file.read()

    # 将字符串转换为列表
    my_list = eval(content_as_string)

    # 输出读取到的列表
    return my_list




information_lists = []




def merge_dicts(a, b):
    try:
        # 创建一个新的字典作为结果
        result = b.copy()  # 先拷贝字典b，这样在合并时任何重复的键将由字典a中的键值对替换
        result.update(a)  # 使用字典a的键值对更新结果字典，如果有重复的键，字典a的值将覆盖字典b的值
        #print(result)
        return result
    except:
        return b





def timestap():
    # Get the current timestamp in milliseconds
    timestamp_milliseconds = int(datetime.now().timestamp() * 1000)
    return timestamp_milliseconds




def create_dict(nick_name, goods_name, goods_url,video_url_, shop_url):
    # 创建字典
    result_dict = {
        "nick_name": nick_name,
        "goods": {
            "name": goods_name,
            "goods_url": goods_url,
            "goods_video_url": video_url_
        },
        "shop":shop_url
    }
    return result_dict



def itemarry_(index):
    #itemsArraysss = read_catch()
    #print(itemsArraysss)
    catch_list = read_catch()
    print(index)
    if index >= len(catch_list)-1:
        print('采集这一页完毕')
        return '1c'
    else:
        #for index in range(0, len(catch_list)+1):
        items = catch_list[index]
        #print(items)
        time.sleep(0.1)
        goods_url = str(items['auctionURL'])
        goods_name = str(items['title']).replace('<span class=H>', '').replace('</span>', '')
        nick_name = str(items['nick'])
        #print(goods_url)
        try:
            result = python_connect_mysql.diaoyong2(goods_url)
        except:
            print('ccc')
            result = 1
        if result == 1:
            infor = {'{:}'.format(goods_name):'{:}'.format('已经存在')}
            logger.info(infor)
            print(goods_name + '已经存在')
            index = index+1
            return itemarry_(index)
        elif result == 0:
            #print(goods_url)
            write_url(goods_url)
            time.sleep(2)
            video_url_, shop_url = video_url_get.get_url()
            # video_url_ = 'str(items[])'
            # shop_url = ''
            #print(video_url_)
            #print(shop_url)
            try:
                if video_url_ == 'haveontvideourl':
                    print('没有视频')
                    infor = create_dict(nick_name, goods_name, goods_url, '没有视频', shop_url)
                    inforssl = goods_name +  '没有视频'
                    logger.info(inforssl)
                    return itemarry_(index+1)

                else:
                    infor = create_dict(nick_name, goods_name, goods_url, video_url_, shop_url)
                    logger.info(infor)
                    python_connect_mysql.diaoyong(nick_name, goods_name, goods_url, video_url_, shop_url)
                    print(str(goods_name) + "：采集完毕")
                    return itemarry_(index+1)
            except Exception as e:
                print(e)
                index = index+2
                return itemarry_(index)





def get_infor_1(new_txt):
    global statesf
    global index
    cookies = get_cookie_r()
    print('第1页开始采集')
    headers = {
        "authority": "h5api.m.taobao.com",
        "accept": "*/*",
        "accept-language": "zh-CN,zh;q=0.9",
        "referer": "https://s.taobao.com/search?fromTmallRedirect=true&q=%E5%86%85%E8%A1%A3&spm=875.7931836.0.0.66144265xhFlfa&tab=mall",
        "sec-ch-ua": "\"Not_A Brand\";v=\"8\", \"Chromium\";v=\"120\", \"Google Chrome\";v=\"120\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Linux\"",
        "sec-fetch-dest": "script",
        "sec-fetch-mode": "no-cors",
        "sec-fetch-site": "same-site",
        "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    data_page_1 = r'{"appId":"34385","params":"{\"device\":\"HMA-AL00\",\"isBeta\":\"false\",\"grayHair\":\"false\",\"from\":\"nt_history\",\"brand\":\"HUAWEI\",\"info\":\"wifi\",\"index\":\"4\",\"rainbow\":\"\",\"schemaType\":\"auction\",\"elderHome\":\"false\",\"isEnterSrpSearch\":\"true\",\"newSearch\":\"false\",\"network\":\"wifi\",\"subtype\":\"\",\"hasPreposeFilter\":\"false\",\"prepositionVersion\":\"v2\",\"client_os\":\"Android\",\"gpsEnabled\":\"false\",\"searchDoorFrom\":\"srp\",\"debug_rerankNewOpenCard\":\"false\",\"homePageVersion\":\"v7\",\"searchElderHomeOpen\":\"false\",\"search_action\":\"initiative\",\"sugg\":\"_4_1\",\"sversion\":\"13.6\",\"style\":\"list\",\"ttid\":\"600000@taobao_pc_10.7.0\",\"needTabs\":\"true\",\"areaCode\":\"CN\",\"vm\":\"nw\",\"countryNum\":\"156\",\"m\":\"pc\",\"page\":\"1\",\"n\":48,\"q\":\"%E5%A5%B3%E8%A3%85\",\"tab\":\"mall\",\"pageSize\":48,\"totalPage\":100,\"totalResults\":4800,\"sourceS\":\"0\",\"sort\":\"_coefp\",\"bcoffset\":\"\",\"ntoffset\":\"\",\"filterTag\":\"\",\"service\":\"\",\"prop\":\"\",\"loc\":\"\",\"start_price\":null,\"end_price\":null,\"startPrice\":null,\"endPrice\":null,\"itemIds\":null,\"p4pIds\":null}"}'
    _m_h5_tk_value = cookies['_m_h5_tk'].split('_')[0]
    timesta = timestap()
    appid = "12574478"
    #data_page_1, sign_value = TM_sign._generate_sign_page_1(_m_h5_tk_value, str(timesta), appid, data_page_1,new_txt)
    url = 'http://127.0.0.1:5000/submit_data'  # 替换成你的Flask应用的地址
    # 准备要提交的数据，以JSON格式
    data_to_submit1 = {
        'functionname': '_generate_sign_page_1',
        'mh5tk': _m_h5_tk_value,
        'timesta': str(timesta),
        'appid': appid,
        'data_page_1': data_page_1,
        'new_txt': new_txt
    }
    # 发送POST请求并提交数据
    response = requests.post(url, json=data_to_submit1)
    # 打印服务器的响应
    res = response.json()
    data_page_1 = res['data_page_1']
    sign_value = res['sign_value']
    url = "https://h5api.m.taobao.com/h5/mtop.relationrecommend.wirelessrecommend.recommend/2.0/"
    params = {
        "jsv": "2.6.2",
        "appKey": "12574478",
        "t": str(timesta),
        "sign": sign_value,
        "api": "mtop.relationrecommend.WirelessRecommend.recommend",
        "v": "2.0",
        "type": "jsonp",
        "dataType": "jsonp",
        "callback": "mtopjsonp2",
        "data": data_page_1
    }
    # proxy = agentip.agentip()
    #
    # proxys = {
    #     'http': 'http://{:}'.format(proxy['http']),
    #     'https': 'http://{:}'.format(proxy['https'])
    # }
    # print(proxys)   ,proxies=proxys
    response = requests.get(url, headers=headers, params=params,cookies=cookies)
    try:
        response_text = response.text.replace(' mtopjsonp2(', '')
        resp_text = response_text[:-1]
        resp_json = json.loads(resp_text)
        itemsArrays = resp_json['data']['itemsArray']
        print('当前页面共有' + str(len(itemsArrays)) + '条数据')
        write_catch(itemsArrays)
        try:
            index = 0
            statesf = itemarry_(index)
            print(statesf)
        except Exception as e:
            print(e)
            print('看看是不是这里错了')
        #statesf = '1c'
        if statesf == '1c':
            print('当前页采集完毕。。。')
            data_mianinfo = resp_json['data']['mainInfo']
            print(data_mianinfo)
            input('输出data_mianinfo')
            sourceS = str(data_mianinfo['sourceS'])
            bcoffset = str(data_mianinfo['bcoffset'])
            ntoffset = str(data_mianinfo['ntoffset'])
            pageSize = str(data_mianinfo['pageSize'])
            totalResults = str(data_mianinfo['totalResults'])
            #paramValue
            paramValue = str(data_mianinfo['paramValue'])
            return sourceS, bcoffset, ntoffset, pageSize, totalResults,paramValue
        elif statesf == '0c':
            cookie1 = drission_login.get_m5()
            time.sleep(2)
            cookie2 = drission_login.login()
            cookiessj = merge_dicts(cookie2, cookie1)
            write_file(cookiessj)
            itemarry_(index)

    except Exception as e:
        global call_counter

        print('错误1')
        print(e)
        try:
            response_text1 = response.text.replace('mtopjsonp2(', '')

            resp_text1 = response_text1[:-1]
            resp_json1 = json.loads(resp_text1)
            print('resp_json1:')
            print(resp_json1)
            urllo = str(resp_json1['data']['url'])
            if ('kcapslidev2' not in urllo):
                if call_counter > 5:
                    cookie1 = drission_login.get_m5()
                    # print("cookie1:", cookie1)
                    time.sleep(2)
                    cookie2 = drission_login.login()
                    # print("cookie2:", cookie2)
                    cookies = merge_dicts(cookie2, cookie1)
                    print("cookies:", cookies)
                    write_file(cookies)
                    call_counter = 0
                else:
                    print('信息页面滑块')
                    hk_drission.diaoyong(urllo)
                    x5sec = get_x5sec_r()
                    cookies = get_cookie_r()
                    cookies['x5sec'] = x5sec
                    # cookiess = merge_dicts(cookieshk,cookies)
                    cookiess = cookies
                    write_file(cookiess)
                    call_counter += 1
                    time.sleep(5)
            else:
                if call_counter > 5:
                    cookie1 = drission_login.get_m5()
                    # print("cookie1:", cookie1)
                    time.sleep(2)
                    cookie2 = drission_login.login()
                    # print("cookie2:", cookie2)
                    cookies = merge_dicts(cookie2, cookie1)
                    print("cookies:", cookies)
                    write_file(cookies)
                else:
                    print('信息页面水果')
                    friut_drission.diaoyong(urllo)
                    x5sec = get_x5sec_r()
                    #cookiessj = merge_dicts(cookiessx,cookies)
                    cookies['x5sec'] = x5sec
                    cookiessj = cookies
                    write_file(cookiessj)
                    call_counter += 1
                    time.sleep(10)
            get_infor_1(new_txt)
        except Exception as e:
            print('错误2')
            print(e)
            cookie1 = drission_login.get_m5()
            time.sleep(2)
            cookie2 = drission_login.login()
            cookiessj = merge_dicts(cookie2, cookie1)
            write_file(cookiessj)
            get_infor_1(new_txt)







def get_more_infor(pageg,sourceS, bcoffset, ntoffset, pageSize, totalResults,new_txt):
    global index,statect
    cookies = get_cookie_r()
    #global cookiess
    print('***********************************************************************')
    headers = {
        "authority": "h5api.m.taobao.com",
        "accept": "*/*",
        "accept-language": "zh-CN,zh;q=0.9",
        "referer": "https://s.taobao.com/search?fromTmallRedirect=true&q=%E5%86%85%E8%A1%A3&spm=875.7931836.0.0.66144265xhFlfa&tab=mall",
        "sec-ch-ua": "\"Not_A Brand\";v=\"8\", \"Chromium\";v=\"120\", \"Google Chrome\";v=\"120\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Linux\"",
        "sec-fetch-dest": "script",
        "sec-fetch-mode": "no-cors",
        "sec-fetch-site": "same-site",
        "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    data_page_more = r'{"appId":"34385","params":"{\"device\":\"HMA-AL00\",\"isBeta\":\"false\",\"grayHair\":\"false\",\"from\":\"nt_history\",\"brand\":\"HUAWEI\",\"info\":\"wifi\",\"index\":\"4\",\"rainbow\":\"\",\"schemaType\":\"auction\",\"elderHome\":\"false\",\"isEnterSrpSearch\":\"true\",\"newSearch\":\"false\",\"network\":\"wifi\",\"subtype\":\"\",\"hasPreposeFilter\":\"false\",\"prepositionVersion\":\"v2\",\"client_os\":\"Android\",\"gpsEnabled\":\"false\",\"searchDoorFrom\":\"srp\",\"debug_rerankNewOpenCard\":\"false\",\"homePageVersion\":\"v7\",\"searchElderHomeOpen\":\"false\",\"search_action\":\"initiative\",\"sugg\":\"_4_1\",\"sversion\":\"13.6\",\"style\":\"list\",\"ttid\":\"600000@taobao_pc_10.7.0\",\"needTabs\":\"true\",\"areaCode\":\"CN\",\"vm\":\"nw\",\"countryNum\":\"156\",\"m\":\"pc\",\"page\":\"2\",\"n\":48,\"q\":\"%E5%A5%B3%E8%A3%85\",\"tab\":\"mall\",\"pageSize\":\"48\",\"totalPage\":\"100\",\"totalResults\":\"82305\",\"sourceS\":\"0\",\"sort\":\"_coefp\",\"bcoffset\":\"0\",\"ntoffset\":\"3\",\"filterTag\":\"\",\"service\":\"\",\"prop\":\"\",\"loc\":\"\",\"start_price\":null,\"end_price\":null,\"startPrice\":null,\"endPrice\":null}"}'
    _m_h5_tk_value = cookies['_m_h5_tk'].split('_')[0]
    timesta = timestap()
    appid = "12574478"
    data_page_data, tm_sign = TM_sign._generate_sign_(_m_h5_tk_value, str(timesta), appid, data_page_more, str(pageg),pageSize, sourceS, bcoffset, ntoffset, totalResults,new_txt)

    url = "https://h5api.m.taobao.com/h5/mtop.relationrecommend.wirelessrecommend.recommend/2.0/"
    params = {
        "jsv": "2.6.2",
        "appKey": "12574478",
        "t": str(timesta),
        "sign": tm_sign,
        "api": "mtop.relationrecommend.WirelessRecommend.recommend",
        "v": "2.0",
        "type": "jsonp",
        "dataType": "jsonp",
        "callback": "mtopjsonp2",
        "data": data_page_data
    }
    print(params)
    # proxy = agentip.agentip()
    # proxys = {
    #     'http': 'http://{:}'.format(proxy['http']),
    #     'https': 'http://{:}'.format(proxy['https'])
    # }
    # print(proxys),proxies=proxys
    response = requests.get(url, headers=headers, params=params,cookies=cookies)
    #print(response.text)

    try:
        response_text = response.text.replace(' mtopjsonp2(', '')
        resp_text = response_text[:-1]
        resp_json = json.loads(resp_text)
        data_mianinfo = resp_json['data']['mainInfo']
        itemsArrayss = resp_json['data']['itemsArray']
        # print(itemsArrays)
        print('当前页面共有' + str(len(itemsArrayss)) + '条数据')
        write_catch(itemsArrayss)

        try:
            index = 0
            statect = itemarry_(index)
        except:
            print()
        #statect = '1'
        if statect == '1c':
            sourceS = str(data_mianinfo['sourceS'])
            bcoffset = str(data_mianinfo['bcoffset'])
            ntoffset = str(data_mianinfo['ntoffset'])
            pageSize = str(data_mianinfo['pageSize'])
            totalResults = str(data_mianinfo['totalResults'])
            pageg = pageg + 1
            print("第" + str(pageg) + '页：开始采集')
            get_more_infor(pageg, sourceS, bcoffset, ntoffset, pageSize, totalResults,new_txt)
        elif statect == '0c':
            cookie1 = drission_login.get_m5()
            time.sleep(2)
            cookie2 = drission_login.login()
            cookiessj = merge_dicts(cookie2, cookie1)
            write_file(cookiessj)
            itemarry_(index)
    except:
        global call_counter
        try:
            response_text1 = response.text.replace('mtopjsonp2(', '')
            resp_text1 = response_text1[:-1]
            resp_json1 = json.loads(resp_text1)
            print('resp_json1:')
            print(resp_json1)
            urllo = resp_json1['data']['url']
            #print(urllo)
            if ('kcapslidev2' not in urllo):
                if call_counter > 5:
                    cookie1 = drission_login.get_m5()
                    # print("cookie1:", cookie1)
                    time.sleep(2)
                    cookie2 = drission_login.login()
                    # print("cookie2:", cookie2)
                    cookies = merge_dicts(cookie2, cookie1)
                    print("cookies:", cookies)
                    write_file(cookies)
                else:
                    print('信息页面滑块')
                    hk_drission.diaoyong(urllo)
                    x5sec = get_x5sec_r()
                    cookies = get_cookie_r()
                    cookies['x5sec'] = x5sec
                    # cookiess = merge_dicts(cookieshk,cookies)
                    cookiess = cookies
                    write_file(cookiess)
                    call_counter += 1
                    time.sleep(5)
            else:
                if call_counter > 5:
                    cookie1 = drission_login.get_m5()
                    #print("cookie1:", cookie1)
                    time.sleep(2)
                    cookie2 = drission_login.login()
                    #print("cookie2:", cookie2)
                    cookies = merge_dicts(cookie2,cookie1)
                    print("cookies:",cookies)
                    write_file(cookies)
                else:
                    print('信息页面水果')
                    friut_drission.diaoyong(urllo)
                    x5sec = get_x5sec_r()
                    # cookiessj = merge_dicts(cookiessx,cookies)
                    cookies['x5sec'] = x5sec
                    cookiess = cookies
                    write_file(cookiess)
                    call_counter += 1
                    time.sleep(10)
            get_more_infor(pageg, sourceS, bcoffset, ntoffset, pageSize, totalResults,new_txt)
        except Exception as e:
            print(e)
            cookie1 = drission_login.get_m5()
            # print("cookie1:", cookie1)
            time.sleep(2)
            cookie2 = drission_login.login()
            # print("cookie2:", cookie2)
            cookiess = merge_dicts(cookie2, cookie1)
            write_file(cookiess)
            get_more_infor(pageg, sourceS, bcoffset, ntoffset, pageSize, totalResults,new_txt)







def diaoyong(new_txt):
    sourceS, bcoffset, ntoffset, pageSize, totalResults,paramValue = get_infor_1(new_txt)
    pageg = 2
    print("第" + str(pageg) + '页：开始采集')
    new_txtparamValue = urllib.parse.quote(paramValue)
    #print(new_txtparamValue)
    get_more_infor(pageg, sourceS, bcoffset, ntoffset, pageSize, totalResults,new_txtparamValue)

#qmguq
if __name__ == '__main__':
    infor_list = []
    _page = drission_login.get_page()
    #print(_page)
    page_text = "".join(_page.split())
    lists_title1 = re.findall('"title1":"(.*?)","t',page_text)
    lists_title2 = re.findall('itle2":"(.*?)","ti',page_text)
    for kt1 in lists_title1:
        if kt1 == '':
            continue
        infor_list.append(kt1)
    for kt2 in lists_title2:
        if kt2 == '':
            continue
        infor_list.append(kt2)
    print(infor_list)
    #登陆部分
    for lb in infor_list:
        print(lb)
        txt = lb
        # URL编码
        new_txt = urllib.parse.quote(txt)
        print(new_txt)
        # cookie1 = drission_login.get_m5()
        # #print("cookie1:", cookie1)
        # time.sleep(2)
        # cookie2 = drission_login.login()
        # #print("cookie2:", cookie2)
        # cookies = merge_dicts(cookie2,cookie1)
        # print("cookies:",cookies)
        # write_file(cookies)
        diaoyong(new_txt)
        print(str(lb) + '采集完毕')
